Name:		Enable Direct IP
Author:		METROID4
Version:	1.0
Description:
A simple mod which enables the button for DirectIP connection type in MP. Good if you don't want passworded match with friends, and also don't want to play with Evolve/Tunngle over LAN.

Installation:
Place the EnableDirectIP.big file into the HWRM Data folder, on default in:
\Steam\SteamApps\common\Homeworld\HomeworldRM\Data\

In Steam, right-click Homeworld Remastered Collection => Properties => Set Launch Options => include the following text in the Text box:
-mod EnableDirectIP.big

This causes issues when using the HW Classics since the Launch parameter is for all of the HW games (since they use a universal launcher, so Steam sees it as one game).
When using Classic HW versions, remove the launch parameter.

Launch the game!

Steam workshop item:
http://steamcommunity.com/sharedfiles/filedetails/?id=406805571

_For other modders_
This mod affects the following files:
Homeworld2.big\UI\NewUI\Multiplayer\connectiontype.lua (complete override)