-- This file is generated automatically by the Relic Audio Tool

version = 4

maxPolyphony = 2
envelope = {
  {
    distance = 0.000000,
    volume = 0.245000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
    }
  },
  {
    distance = 1133.333374,
    volume = 0.225000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
    }
  },
  {
    distance = 2783.333252,
    volume = 0.140000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              0.770000,
              0.720000,
              0.690000,
              0.700000,
    }
  },
  {
    distance = 4500.000000,
    volume = 0.105000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              0.610000,
              0.610000,
              0.620000,
              0.590000,
    }
  },
  {
    distance = 6250.000000,
    volume = 0.000000,
    reverb = 0.550000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              0.610000,
              0.610000,
              0.620000,
              0.590000,
    }
  },
}
container = 1
playlist = 0
randContainer = 1
loopingPlaylist = 0
silenceBreak = 0.000000
silenceRandom = 0.000000
randSampContainer = 1

