-- This file is generated automatically by the Relic Audio Tool

version = 4

frequency = -1
maxPolyphony = 2
container = 1
playlist = 0
randContainer = 1
loopingPlaylist = 0
silenceBreak = 0.000000
silenceRandom = 0.000000
randSampContainer = 1

