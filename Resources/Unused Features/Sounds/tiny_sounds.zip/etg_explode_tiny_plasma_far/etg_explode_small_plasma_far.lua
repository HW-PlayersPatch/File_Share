-- This file is generated automatically by the Relic Audio Tool

version = 4

maxPolyphony = 5
container = 1
playlist = 0
randContainer = 1
loopingPlaylist = 0
silenceBreak = 0.000000
silenceRandom = 0.000000
randSampContainer = 1

