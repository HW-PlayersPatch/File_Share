-- This file is generated automatically by the Relic Audio Tool

version = 4

frequency = -1
maxPolyphony = 2
envelope = {
  {
    distance = 0.000000,
    volume = 0.225000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
    }
  },
  {
    distance = 1050.000000,
    volume = 0.205000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              1.000000,
    }
  },
  {
    distance = 2633.333252,
    volume = 0.200000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              0.890000,
              0.850000,
              0.820000,
              0.760000,
    }
  },
  {
    distance = 4266.666504,
    volume = 0.185000,
    reverb = 0.000000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              0.620000,
              0.450000,
              0.490000,
              0.440000,
    }
  },
  {
    distance = 5966.666504,
    volume = 0.000000,
    reverb = 0.550000,
    duration = 0,
    equalizer = {
              1.000000,
              1.000000,
              1.000000,
              1.000000,
              0.490000,
              0.540000,
              0.450000,
              0.450000,
    }
  },
}
randSampContainer = 0

