PersistantData =
{
	StrikeGroups = {},
	Squadrons = {},
	Research = {},
}
h