PersistantData =
{
	StrikeGroups = {},
	Squadrons = {},
	Research = {},
}
s