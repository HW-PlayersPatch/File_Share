
Level_Pass_Tags = "campaigns_hwat"
Race_Pass_Tags = "race_hwat"

objectives={};

--Spawns an endless stream of ships to fight each other, maintains force levels by replacing dead ships, 
--and records the replacement rate.

--Should set up a testing race with a bsaically empty build file, as the game preloads all hods in the build file but
--only loads other hods as needed, this would cut down on testing load times considerably.

--currently is going to primitively spam attack orders at each other's playersobs, but might want to use unitai at some point. Might push unitai's cleanliness to it's limits though for long runs.

--We're going to make the human, player 0, neutral and share vision with both players. Thus the combat will be
--between player 1 and 2.
player1={}
player2={}

test_set = {}

function HWAT_TableDump(label, table)
   for key,value in table do
      if type(value) == "table" then
        HWAT_TableDump("    "..label.."["..key.."]",value)
      elseif type(value) == "function" then
		print(label.."["..key.."]=function ")
	elseif type(value) == "userdata" then
		print(label.."["..key.."]=userdata ")
	  else 
        print(label.."["..key.."]="..value)
      end
   end
end

function array_expand(array)
	local i = 0
    while array[i] ~= nil do 
        i=i+1
    end
    array[i]={}
    return i
end
function array_find_last(array)
	local i = 0
    while array[i] ~= nil do 
        i=i+1
    end
    return i-1
end
function table_copy_deep(tin,tout)
	--tout = {}
	for key,value in tin do
		if type(value) == type({}) then
			tout[key]={}
			table_copy_deep(value,tout[key])
		else
			tout[key]=tin[key]
		end
	end
end


function add_test(tests,name,p1,p2,duration,itterations,type)
	local i = 0
    while tests[i] ~= nil do 
        i=i+1
    end
    tests[i]={}
    tests[i].name = name
    tests[i].p1 = {}
    tests[i].p2 = {}
    table_copy_deep(p1,tests[i].p1)
    table_copy_deep(p2,tests[i].p2)
    tests[i].duration = duration
    tests[i].i = 0
    tests[i].itterations = itterations
    tests[i].type = type
    tests[i].t1 = 0
    tests[i].t2 = 0
end

function add_ship_to_player(player,shipname,shipcost,shipbudget)
    local i = 0
    while player[i] ~= nil do 
        i=i+1
    end
    player[i] = {}
    player[i].name = shipname
    player[i].cost = shipcost
    player[i].budget = shipbudget
    player[i].targetcount = shipbudget/shipcost
    --print(i)
end
function count_ships(name,player)
     SobGroup_Clear("temp")
    Player_FillShipsByType("temp",player,name)
    local i=SobGroup_Count("temp")
    return i
end


total_spent = {}
total_spent[1] = 0
total_spent[2] = 0


test_pointer = 0
test_startime = 0
--function add_test(tests,name,p1,p2,duration,itterations,type)
common_cost = 575--575*3
common_duration_minutes = 2.5

dummy_scouts = {}
ints = {}
defs = {}
dogfighters = {}
snipers = {}
std_corvettes = {}
heavy_corvettes = {}

--add_ship_to_player(player1,"HWAT_UNH_FTScout_Dummy",60,common_cost)

ships = {}
ship_names ={
    "HWAT_UNH_FFAssault",
    "HWAT_UNH_CTStandard",
    "HWAT_UNH_FTInterceptor",
    "HWAT_UNH_CTHeavy"--,
    --"HWAT_UNH_FTBomber"--,
    --"HWAT_UNH_FFIon",
    --"HWAT_UNH_DDStandard",
    --"HWAT_UNH_DDMissile"--,
    --"HWAT_UNH_CAStandard"
}
ships.HWAT_UNH_FTInterceptor = 60
ships.HWAT_UNH_FTBomber = 85
ships.HWAT_UNH_CTStandard = 190
ships.HWAT_UNH_CTHeavy = 240
ships.HWAT_UNH_FFAssault = 575
ships.HWAT_UNH_FFIon = 650
ships.HWAT_UNH_DDStandard = 1500
ships.HWAT_UNH_DDMissile = 1500
ships.HWAT_UNH_CAStandard = 3700
l = 4
i = 1
j = 1
while i <= l do
    j = i+1
    while j <= l do
        player1={}
        player2={}
        i_name = ship_names[i]
        j_name = ship_names[j]
        add_ship_to_player(player1,i_name,ships[i_name],common_cost)
        add_ship_to_player(player2,j_name,ships[j_name],common_cost)
        add_test(test_set,""..common_duration_minutes.."m "..common_cost.." RU,".. i_name .. ",".. j_name,player1,player2,common_duration_minutes*60,"stream")
        j=j+1
    end
    i=i+1
end

player1={}
player2={}
--add_ship_to_player(player1,"HWAT_UNH_FTScout_Dummy",60,common_cost)
add_ship_to_player(player1,"HWAT_NUT_Targ_FT_Medium",180,common_cost)
add_ship_to_player(player2,"HWAT_UNH_FTDefender",18,common_cost)
--add_ship_to_player(player2,"HWAT_UNH_FTInterceptor",90,common_cost)
--add_test(test_set,""..common_duration_minutes.."m "..common_cost.." RU dummyscouts vs ints",player1,player2,common_duration_minutes*60,"stream")
player1={}
player2={}
add_ship_to_player(player1,"HWAT_UNH_FTInterceptor",90,common_cost)
add_ship_to_player(player2,"HWAT_UNH_FTSniper",60,common_cost)
--add_test(test_set,""..common_duration_minutes.."m "..common_cost.." RU ints vs bombers",player1,player2,common_duration_minutes*60,"stream")
player1={}
player2={}
add_ship_to_player(player1,"HWAT_UNH_FTDogfighter",60,common_cost)
add_ship_to_player(player2,"HWAT_UNH_FTBomber",85,common_cost)
--add_test(test_set,""..common_duration_minutes.."m "..common_cost.." RU df vs bombers",player1,player2,common_duration_minutes*60,"stream")
player1={}
player2={}
add_ship_to_player(player1,"HWAT_UNH_FTInterceptor",90,common_cost)
add_ship_to_player(player2,"HWAT_UNH_CTStandard",190,common_cost)
--add_test(test_set,""..common_duration_minutes.."m "..common_cost.." RU ints vs light vettes",player1,player2,common_duration_minutes*60,"stream")
player1={}
player2={}
add_ship_to_player(player1,"HWAT_UNH_FTDogfighter",60,common_cost)
add_ship_to_player(player2,"HWAT_UNH_CTStandard",190,common_cost)
--add_test(test_set,""..common_duration_minutes.."m "..common_cost.." RU df vs light vettes",player1,player2,common_duration_minutes*60,"stream")
player1={}
player2={}
add_ship_to_player(player1,"HWAT_UNH_FTInterceptor",90,common_cost)
add_ship_to_player(player2,"HWAT_UNH_FFAssault",575,common_cost)
--add_test(test_set,""..common_duration_minutes.."m "..common_cost.." RU df vs FFA",player1,player2,common_duration_minutes*60,"stream")
player1={}
player2={}
add_ship_to_player(player1,"HWAT_UNH_FTDogfighter",60,common_cost)
add_ship_to_player(player2,"HWAT_UNH_FFAssault",575,common_cost)
--add_test(test_set,""..common_duration_minutes.."m "..common_cost.." RU ints vs FFAs",player1,player2,common_duration_minutes*60,"stream")
player1={}
player2={}
add_ship_to_player(player1,"HWAT_UNH_FFAssault",575,common_cost)
add_ship_to_player(player2,"HWAT_UNH_CTStandard",190,common_cost)
--add_test(test_set,""..common_duration_minutes.."m "..common_cost.." RU FFA vs CTSs",player1,player2,common_duration_minutes*60,"stream")
--HWAT_TableDump("test table",test_set)
print("name, runtime, p1 spending, p2 spending")
next_test_start = 3
function clear_arena()
	SobGroup_SetHealth("Player_Ships1", 0)
	SobGroup_SetHealth("Player_Ships2", 0)
end

function write_test_results(test)
	print("run ".. test.i+1 .." of ".. test.name..","..test.duration..",".. total_spent[1]..","..total_spent[2])
end
function maintain_tests()
	if(array_find_last(test_set)<test_pointer)then
		--print("Advanced past last test, starting over")
		test_pointer=0
	end
	local test = test_set[test_pointer]
	local endtime = test.duration+next_test_start
	local now = Universe_GameTime()
	--print("test#:"..test_pointer.." ends at "..endtime.." it is currently "..now)

	if next_test_start > now then
		--print("waiting for next test")
		clear_arena()
	elseif endtime < now then
		--print("Ending test")
    	test.t1 = check_player(1,test.p1)
    	test.t2 = check_player(2,test.p2)
    	write_test_results(test)
    	test.i=test.i+1
    	test_pointer=test_pointer+1
    	next_test_start = now+3
    	test.t1 = 0
    	test.t2 = 0
    	total_spent[1] = 0
		total_spent[2] = 0
    else
    	--print("running test")
    	test.t1 = check_player(1,test.p1)
    	test.t2 = check_player(2,test.p2)
	end

end

function check_player(index, fleet_targets)
    for key,value in fleet_targets do
        local name = value.name
        local count = count_ships(value.name,index)
        local target = value.targetcount
        local cost  = value.cost
        if(count<target) then
            diff = target-count
            timestamp = Universe_GameTime()
            total_spent[index]=total_spent[index]+diff*cost
            accumulator=total_spent[index]
            --print(index..","..timestamp..",".. name..","..target..","..diff..","..diff*cost..","..total_spent[index])
            --spawn a bunch of ships here
            local i = 0
            while i< diff do
                --print("spawn"..i)
                SobGroup_SpawnNewShipInSobGroup(index, name, "wave_", "Player_Ships"..index, "spawn"..index.."_"..i)
                i=i+1
            end
            --Issue attack orders I guess
        end
    end
    return accumulator
end
function rule_watchfight()
    check_player(1,player1)
    check_player(2,player2)
    --SobGroup_Attack(1, "Player_Ships1", "Player_Ships2")
    --SobGroup_Attack(2, "Player_Ships2", "Player_Ships1")
end

function stayHostile()
    SobGroup_Attack(1, "Player_Ships1", "Player_Ships2")
    SobGroup_Attack(2, "Player_Ships2", "Player_Ships1")
end

function OnInit()
    print("BEGINNING TEST")
    SetAlliance(1, 0)
    SetAlliance(0, 1)

    SetAlliance(2, 0)
    SetAlliance(0, 2)

    BreakAlliance(1,2)
    BreakAlliance(2,1)
    Player_ShareVision(0,1,1)
    Player_ShareVision(0,2,1)
    Rule_AddInterval("stayHostile",2)
    Rule_AddInterval("maintain_tests",1)
    SobGroup_Create("temp")
    SobGroup_Clear("temp")
    --SobGroup_SpawnNewShipInSobGroup(1, "HWAT_UNH_FTInterceptor", "wave_", "Player_Ships1", "spawn1")

    --SobGroup_SpawnNewShipInSobGroup(2, "HWAT_UNH_FTInterceptor", "wave_", "Player_Ships2", "spawn2")
end
