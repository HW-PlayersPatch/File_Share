FORM_CLAW = "Movers"
FORM_X = "X"
FORM_WALL = "Wall"
function clear_arena()
	SobGroup_SetHealth("Player_Ships1", 0)
	SobGroup_SetHealth("Player_Ships2", 0)
end

function init_ship_container(ships)
	ships = {}
	ships.count = 0
end	
function add_ship(ships,name,cost,category)
	ships[name] = {}
	ships[name].cost = cost
	ships[name].category = category
end



function init_test_container(matchups)
	matchups = {}
	matchups.count = 0
	return matchups
end
function add_matchup(matchups,ships,caps,a,b,a_form,b_form)
	i = matchups.count
	matchups.count =matchups.count +1
	matchups[i] = {}
	matchups[i].a = a
	matchups[i].b = b
	if a_form == nil then
		matchups[i].a_form = "none"
	else
		matchups[i].a_form = a_form
	end
	if b_form == nil then
		matchups[i].b_form = "none"
	else
		matchups[i].b_form = b_form
	end
	
	

end


ships = {}
init_ship_container(ships)
add_ship(ships,"HWAT_UNH_FTInterceptor",90,"FT")
add_ship(ships,"HWAT_UNH_FTDefender",90,"FT")
add_ship(ships,"HWAT_UNH_CTStandard",160,"CT")
add_ship(ships,"HWAT_UNH_FFAssault",575,"FF")
add_ship(ships,"HWAT_REP_FFAssault",575,"FF")

caps = {}
caps.FT = 40--100
caps.CT = 30--40
caps.FF = 20
caps.DD = 10
caps.CA = 5


tests = {}
tests = init_test_container(tests)
--add_matchup(tests,ships,caps,"HWAT_UNH_FFAssault","HWAT_UNH_FFAssault",FORM_WALL,FORM_CLAW)
--add_matchup(tests,ships,caps,"HWAT_UNH_FTInterceptor","HWAT_UNH_FTInterceptor","none",FORM_X)
--add_matchup(tests,ships,caps,"HWAT_UNH_FTDefender","HWAT_UNH_FTInterceptor",FORM_WALL,FORM_X)
--add_matchup(tests,ships,caps,"HWAT_UNH_FTDefender","HWAT_UNH_CTStandard",FORM_WALL,FORM_WALL)
--add_matchup(tests,ships,caps,"HWAT_UNH_CTStandard","HWAT_UNH_FTInterceptor",FORM_WALL,FORM_CLAW)
--add_matchup(tests,ships,caps,"HWAT_UNH_FTInterceptor","HWAT_UNH_FFAssault")
add_matchup(tests,ships,caps,"HWAT_REP_FFAssault","HWAT_UNH_FFAssault",FORM_WALL,FORM_WALL)

start_count = 1

a_count = start_count
b_count = start_count

fight_index = 0
results_index = 0
results = {}
fight_scalestep =1.05
function spawn_team(player_index,ship_name,count)
	local i = 0
	while i < count do
		--print("SobGroup_SpawnNewShipInSobGroup(" .. player_index .." , ".. ship_name .. " , \"wave_\",  \"Player_Ships"..player_index.. ", \"spawn"..player_index.."_"..i..")")
		SobGroup_SpawnNewShipInSobGroup(player_index, ship_name, "wave_", "Player_Ships"..player_index, "spawn"..player_index.."_"..i)
		i=i+1
	end
end
t_start_time = 0
function do_test()
	i = fight_index
	a_current = SobGroup_Count("Player_Ships1")
	b_current = SobGroup_Count("Player_Ships2")
	a_name = tests[i].a
	b_name = tests[i].b
	a_cap = caps[ships[a_name].category]
	b_cap = caps[ships[b_name].category]
	duration = Universe_GameTime()- t_start_time 
	if ((a_current + b_current) > 0) then
		--Some ships are alive. Check and see if either side has lost all their ships

		--If either side has lost all ships, clear the feild and increment the losing side
		if a_current == 0 then
			clear_arena()
			print(a_name..","..b_name..","..a_count..","..b_count..","..a_current..","..b_current..","..duration)
			a_count=ceil(a_count*fight_scalestep)
			--print("All of team A died, increasing next count to "..a_count)

		elseif b_current == 0 then
			clear_arena()
			print(a_name..","..b_name..","..a_count..","..b_count..","..a_current..","..b_current..","..duration)
			b_count=ceil(b_count*fight_scalestep)
			--print("All of team B died, increasing next count to "..b_count)
		end
	else
		--Everything is dead, which means we're needing to advance to the next test
		if(a_count < a_cap and b_count<b_cap) then
			--print("Spawning next fight.")
			spawn_team(1,a_name,a_count)
			spawn_team(2,b_name,b_count)
			Rule_AddInterval("assume_formation",1)
			Rule_AddInterval("stayHostile",10)
			t_start_time = Universe_GameTime()
		else
			print("")
			fight_index = fight_index+1
			a_count = start_count
			b_count = start_count
			if fight_index>=tests.count then
				Rule_Remove("do_test")
			end
		end
	end
end
function assume_formation()
	a_form = tests[fight_index].a_form
	b_form = tests[fight_index].b_form

	if tests[fight_index].a_form ~= "none" then
		SobGroup_FormStrikeGroup("Player_Ships1", tests[fight_index].a_form)
	end
	if tests[fight_index].b_form ~= "none" then
		SobGroup_FormStrikeGroup("Player_Ships2", tests[fight_index].b_form)
	end

	SobGroup_SetStance( "Player_Ships0", 0)
	SobGroup_SetStance( "Player_Ships1", 0)
	SobGroup_SetStance( "Player_Ships2", 0)
	
		Rule_Remove("assume_formation")
end

function stayHostile()
    SobGroup_Attack(1, "Player_Ships1", "Player_Ships2")
    SobGroup_Attack(2, "Player_Ships2", "Player_Ships1")
    Rule_Remove("stayHostile")
    --SobGroup_FormStrikeGroup("Player_Ships1", "sg_x")
    --SobGroup_FormStrikeGroup("Player_Ships2", "X")
    
end
function OnInit()
    print("BEGINNING TEST")
    SetAlliance(1, 0)
    SetAlliance(0, 1)

    SetAlliance(2, 0)
    SetAlliance(0, 2)

    BreakAlliance(1,2)
    BreakAlliance(2,1)
    Player_ShareVision(0,1,1)
    Player_ShareVision(0,2,1)
    
    Rule_AddInterval("do_test",10) --This needs to be high to account for long die times I think
    print("a_name,b_name,a_starting,b_starting,a_final,b_final,duration")
end