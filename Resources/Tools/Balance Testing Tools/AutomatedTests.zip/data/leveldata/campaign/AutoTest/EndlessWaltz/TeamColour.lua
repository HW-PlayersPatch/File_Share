-- =============================================================================
-- Homeworld 2 Clean Data Resource Project
-- By S110
-- Version 1.0
-- 02/06/2010
-- Tools used: EditPad Lite, LuaDC version 0.9.19, and Cold Fusion LUA Decompiler v1.0.0
-- =============================================================================

teamcolours = {
	[0] = {--UNH player
		{0.556,0.621,0.628},
		{1.000,1.000,1.000}, 
		"DATA:Badges/hm3.tga", 
		{0.556,0.621,0.628},
		"data:/effect/trails/hgn_trail_clr.tga"
		},
	[1] = {--Freighters, reptai colors
		{0.000,0.501,0.270}, 
		{0.000,0.501,0.270}, 
		"DATA:Badges/Taiidan2.tga", 
		{0.0,0.592,0.270}, 
		"data:/effect/trails/hgn_trail_clr.tga"
		},
	[2] = {--Athicur's Pirates
		{0.925,0.125,0.141},
		{0.925,0.125,0.141}, 
		"DATA:Badges/Taiidan.tga",
		{0.925,0.125,0.141}, 
		"data:/effect/trails/hgn_trail_clr.tga"
		},
	[3] = {--Surrendered freights
		{1.000,1.000,1.000},
		{0.000,0.501,0.501}, 
		"DATA:Badges/Taiidan2.tga",
		{0.827,0.752,0.098}, 
		"data:/effect/trails/hgn_trail_clr.tga"
		},
	}