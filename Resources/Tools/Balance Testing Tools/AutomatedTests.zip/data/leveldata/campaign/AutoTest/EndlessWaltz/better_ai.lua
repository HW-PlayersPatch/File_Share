
dofilepath("data:scripts/HWATlib/Util.lua")
--newAI

--Okay, so we need to go through each of the AI groups
--Look at what it's doing, and what it should do next
--Things they can be doing include:
--	Idle: Haven't yet been given a state. Should have a countdown
--		Exits:
--			Comes under attack: Moves to fighting
--			Is stumbled upon by freighter: Fighting
--			Idles for enough time: Form strike group, start hunting
--			Is near freindly freighter: Start guarding
--	Hunting: Moving towards a target. Should be in a strike group already
--		Exits:
--			Hunt target enters HS: Chose new target and hunt
--			Stumbled upon: start fighting
--	Fighting: Engaged in combat with someone
--		Exits:
--			Destroyed: Die
--			Out of targets: Go to idle.

--This will be the gamerule that loops through all the enemy blobs and makes them do things

--make an AI unit and add it to the AI pile with the default state
function new_unit(units,sobname)
	print("Adding new unit, name: "..sobname)
	unit = {}
	unit.sob =sobname
	unit.state="spawn"
	unit.state_start = 0.0
	unit.alive = 0
	unit.target_sob = nil
	unit.stateFunction = nil_state
	tinsert(units,unit)
end
function wake_unit(units,sobname)
	print("trying to wake unit "..sobname)
	for key,unit in units do
		--Take a collection of enemies and process it
		if type(unit)=="table" then
			print("checking unit:"..unit.sob)
			if unit.sob==sobname then
				unit.alive = 1
				print("found it")
			end
		end
	end
	print("done")
end
units = {}

function do_logic()
	for key,unit in units do
		--Take a collection of enemies and process it
		if type(unit)=="table" then
			unit_logic(unit)
		end
	end
end
--This is the subfunction that makes all the blobs do whatever they should.
--The actual actions will be done via functions stored in the unit table
function unit_logic(unit)
	print("doing logic for "..unit.sob..", count = ".. SobGroup_Count(unit.sob)..", current state "..unit.state)
	unit.stateFunction(unit)
	print("did logic for "..unit.sob.." current state "..unit.state)
end

function check_for_something(unit,check_target)
	--Use engine functions to check for nearby hostiles
	tempname = HWAT_gensym()
	SobGroup_Create(tempname)
	--SobGroup_Clear(temp)
	radius = 4500
	SobGroup_FillProximitySobGroup(tempname,check_target,unit.sob,radius)
	if(SobGroup_Count(tempname)==0) then
		return 0 --return 0 for nothing nearby
	end
	return tempname
end

function check_for_enemy(unit)
	--Use engine functions to check for nearby hostiles
	return check_for_something(unit,"Player_Ships0")
end
function check_for_prey(unit)
	return check_for_something(unit,"Player_Ships1")
end
function check_for_booty(unit)
	return check_for_something(unit,"Player_Ships3")
end

function attack_nearest(owner,attacker,target)
	print("attack_nearest("..owner..","..attacker..","..target..")")
	temp = HWAT_gensym()
	SobGroup_Create(temp)
	i = 1
	step = 150
	if SobGroup_Count(target)==0 or SobGroup_Count(attacker)==0 then
		return
	end
	count = 0
	while count == 0 do
		i=i+1
		SobGroup_FillProximitySobGroup(temp,target,attacker,i*step)
		count = SobGroup_Count(temp)
		--print(attacker .. " is attempting to attack ".. target .. " current range band = " .. i*step .. "count: " .. count)
	end
	SobGroup_Attack(owner,attacker,temp)
end

function move_to_nearest(attacker,target)
	print("move_to_nearest("..attacker..","..target..")")
	temp = HWAT_gensym()
	SobGroup_Create(temp)
	i = 1
	step = 150
	if SobGroup_Count(target)==0 or SobGroup_Count(attacker)==0 then
		return
	end
	count = 0
	while count == 0 do
		i=i+1
		SobGroup_FillProximitySobGroup(temp,target,attacker,i*step)
		count = SobGroup_Count(temp)
		--print(attacker .. " is attempting to move to ".. target .. " current range band = " .. i*step .. "count: " .. count)
	end
	SobGroup_MoveToSobGroup(attacker,temp)
end

function guard_to_nearest(attacker,target)
	print("guard_to_nearest("..attacker..","..target..")")
	temp = HWAT_gensym()
	SobGroup_Create(temp)
	i = 1
	step = 150
	if SobGroup_Count(target)==0 or SobGroup_Count(attacker)==0 then
		return
	end
	count = 0
	while count == 0 do
		i=i+1
		SobGroup_FillProximitySobGroup(temp,target,attacker,i*step)
		count = SobGroup_Count(temp)
		--print(attacker .. " is attempting to guard to ".. target .. " current range band = " .. i*step .. "count: " .. count)
	end
	SobGroup_GuardSobGroup(attacker,temp)
end

--Default state that a unit sits in until it is spawned. Can't be reutrned to
function nil_state(unit)
	if unit.alive==1 then
		state_switch_idle(unit)
	end
end
--The idle behavior
--Sit around for a while then go hunting
--Enemies spawn in this state and pass
--through it often to try to keep them clumped up
max_idle_time=1
function idle_state(unit)
	now = 0
	now = Universe_GameTime()
	idle_time = now-unit.state_start

	if(check_for_enemy(unit)~=0 or check_for_prey(unit)~=0) then
		state_switch_fight(unit)
	elseif (check_for_booty(unit)~=0) then
		target = check_for_booty(unit)
		state_switch_guard(unit,target)
	elseif (idle_time>max_idle_time) then
		if(SobGroup_Count("Player_Ships1")==0) then
			print(unit.sob.." should be hunting but isn't because Player_Ships1 appears empty")
			return
		end
		state_switch_hunt(unit,"Player_Ships1")
	end
end
--Transition a unit into the idle state
function state_switch_idle(unit)
	print(unit.sob .. " switching to idle state")
	SobGroup_Stop(2,unit.sob)
	SobGroup_FormStrikeGroup(unit.sob,"wall")
	unit.state_start = Universe_GameTime()
	unit.target_sob = nil
	unit.state ="idle"
	unit.stateFunction = idle_state
end
--The hunting behavior. Pretty much the idle behavior,
--But has a target and checks to make sure it's still valid
--rather than checking a clock.
function hunt_state(unit)
	print("Doing hunt state for ".. unit.sob)
	target_count=0
	target_count = SobGroup_Count(unit.target_sob)
	print("  Target: " .. unit.target_sob)
	print("  Target count: " .. target_count)
	enemy = check_for_enemy(unit)
	prey = check_for_prey(unit)
	booty = check_for_booty(unit)
	print("  Enemy: " .. enemy)
	print("  Prey: " .. prey)
	print("  booty: " .. booty)

	if enemy~=0 then
		--Fight!
		print("    Switching to fight enemy. Enemy count: ".. SobGroup_Count(enemy))
		--SobGroup_AttackPlayer(unit.sob,0)
		attack_nearest(2,unit.sob,"Player_Ships0")
		state_switch_fight(unit)
	elseif prey~=0 then
		--Fight!
		print("    Switching to fight prey. Prey count: ".. SobGroup_Count(prey))
		--SobGroup_AttackPlayer(unit.sob,1)
		attack_nearest(2,unit.sob,"Player_Ships1")
		state_switch_fight(unit)
	elseif booty~=0 then 
		--Guard!
		print("    Switching to guard. Booty count: ".. SobGroup_Count(booty))
		state_switch_guard(unit,"Player_Ships3")
	elseif target_count>0 and SobGroup_AreAllInHyperspace(unit.target_sob) == 0 then
		print("    Nothing in range but targets still exist, continuing.")
		return
	else
		print("    Nothing in range and lost targets, idling.")
		state_switch_idle(unit)
	end
end
--enter the hunting state
function state_switch_hunt(unit,target)
	print(unit.sob .. " switching to hunt state, targeting ".. target)
	unit.state="hunt"
	unit.stateFunction=hunt_state
	unit.target_sob=target
	move_to_nearest(unit.sob,target)
end
--Guard behavior. Very similar to hunt behavior,
--but with a freindly instead of a hostile target
function guard_state(unit)

	target_count=0
	if unit.target_sob ~= nil then 
		target_count = SobGroup_Count(unit.target_sob)
	end
	
	if check_for_enemy(unit)~=0 then
		--Fight!
		--SobGroup_AttackPlayer(SobGroup_AttackPlayer(unit.sob,0))
		attack_nearest(2,unit.sob,"Player_Ships0")
		state_switch_fight(unit)
	elseif check_for_prey(unit)~=0 then
		--Fight!
		--SobGroup_AttackPlayer(SobGroup_AttackPlayer(unit.sob,1))
		attack_nearest(2,unit.sob,"Player_Ships1")
		state_switch_fight(unit)
	elseif target_count>0 and SobGroup_AreAllInRealSpace(unit.target_sob) ~= 0 then
		return
	else
		state_switch_idle(unit)
	end
end
function state_switch_guard(unit,target)
	print(unit.sob .. " switching to guard state")
	unit.state="guard"
	guard_to_nearest(unit.sob,target)
	unit.target=target
	unit.stateFunction=guard_state
end
--Fight behavior
--Keep fighting until out of nearby targets, then reevaluate
function fight_state(unit)

	radius = 3000
	prey = check_for_prey(unit)
	enemy = check_for_enemy(unit)
	target_count=0
	if prey~=0 then
		target_count=target_count+SobGroup_Count(prey)
	end
	if enemy~=0 then
		target_count=target_count+SobGroup_Count(enemy)
	end
	
	if target_count<1 then
		state_switch_idle(unit)
	end
end
function state_switch_fight(unit)
	print(unit.sob .. " switching to fight state")
	unit.state="fight"
	unit.stateFunction=fight_state
	SobGroup_SetTactics(unit.sob,AggressiveTactics)
end
--Dead behavior
--Don't do anything anymore!
function dead_state(unit)
end
function state_switch_dead(unit)
	print(unit.sob .. " switching to dead state")
	unit.state="dead"
	unit.stateFunction=dead_state
end
