Drop file in:

data\UI\NewUI\Developer