-- =============================================================================
--     Name    : debugFunctions.lua
--     Purpose : debug console function definitions.
--
--     Created 9/6/2000 by lmoloney
--     Copyright Relic Entertainment, Inc.  All rights reserved.
-- =============================================================================

function version()
    print("version OU812");
end


