Number_Properties_Priority = 2.0

Number_Properties = {
	SquadronSize = 7,
	buildBatch = 0,
}

String_Properties_Priority = 2.0

String_Properties = {
}
