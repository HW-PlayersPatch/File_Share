Number_Properties_Priority = 2.0

Number_Properties = {
	SquadronSize = 1,
	buildBatch = 5,
}

String_Properties_Priority = 2.0

String_Properties = {
}
