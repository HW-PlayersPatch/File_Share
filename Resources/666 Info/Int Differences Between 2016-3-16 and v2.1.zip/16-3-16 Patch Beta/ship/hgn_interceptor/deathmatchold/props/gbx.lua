Number_Properties_Priority = 2.0

Number_Properties = {
	SquadronSize = 5,
	buildBatch = 0,
}

String_Properties_Priority = 2.0

String_Properties = {
}
