Name = "Batch_Wedge"
Order = -1.0		-- Means invisible to UI
Hint = "$4950"
Title = "$5460"
Hotkey = 103

Tags = "sgf_vgr"

UIAlias = "Vgr_Wedge"

BatchRestrict = 1

DeathDamage = 0.85
FriendlyFire = { 0.7, 0.0, 0.0 }       -- Base, Pop, PopSqrt
SpacingScale = 1.33

LayoutMode = "Nodes"

StanceGrouping = "Batch"
StanceGroupingAg = "Shape"
StanceGroupingEv = "Subs"

DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{
	{
		familyname = "Fighter",
		filename = "follow_strikegroup_lead",
	},
	{
		shipname = "Hgn_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
	{
		shipname = "Vgr_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
}

reformAtPctChangeInCombat = 0.5
reformAtPctChangeIdle = 0.25



strikegroup =
{
	OffsetFromParent = {0,0,0},
	Children =
	{
		{
			OffsetFromParent                           = {0,-0.65,-0.25},
			
			Children =
			{
				{
					OffsetFromParent                           = {-0.8,-0.15,-0.65},
				},
				{
					OffsetFromParent                           = {0.8,-0.15,-0.65},
				},
			},
		},
		{
			OffsetFromParent                           = {0.8,0.15,-0.65},
		},
		{
			OffsetFromParent                           = {-0.8,0.15,-0.65},
		},
	},
}
