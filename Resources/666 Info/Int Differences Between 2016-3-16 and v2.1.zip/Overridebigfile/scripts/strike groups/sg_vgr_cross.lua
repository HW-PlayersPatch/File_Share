Name = "Vgr_Cross"
Order = 0.6                         -- Controls sort order for ID use.  In the next patch ONLY names will be allowed!
Hint = "$4952"
Title = "$5462"
Hotkey = 105
Icon = {
	texture = "DATA:UI\\NewUI\\Taskbar\\FormationIcons\\form_ico_x.dds",
	uvRect = { 0/128, 0/512, 128/128, 128/515 },
	patch_X = { 4,-120, 4,0 },
	patch_Y = { 4,-120,4, 0 },
	patch_Scale = 1,

	Surface = {
		surface = "ui_multistate";
		{ prop = "state0", float3 = { 0.0, 0.0, 1.0 } },
		{ prop = "state1", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "state2", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "decal", float3 = { 0.0, 0.0, 0.0 } },
	}
}

ExtFilter = "sgf_gbx,sgf_hwrm"
Tags = "sgf_vgr"

StanceGrouping = "Batch"
StanceGroupingAg = "Shape"
StanceGroupingEv = "Subs"
 
DeathDamage = 0.90
FriendlyFire = { 0.8, 0.0, 0.0 }       -- Base, Pop, PopSqrt

-- Decay rate 1% Set to 1 for instant
PopDecay = 0.01

	SpacingRange = 	 { 75, 1.45, 200, 1.1 }
	SpacingRangeAg = { 75, 1.45, 200, 1.1 }
	SpacingRangeEv = { 75, 2.0,  200, 2.0 }

DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{
                {
                                shipname = "Hgn_Destroyer",
                                filename = "follow_strikegroup_lead_broadside",
                },
                {
                                shipname = "Vgr_Destroyer",
                                filename = "follow_strikegroup_lead_broadside",
                },
}
 
reformAtPctChangeInCombat = 0.5
reformAtPctChangeIdle = 0.25
 
Multipliers = {
 
-- Leader //Const, PopRaw-1, PopSqrt-1
-- Node //Nodedepth, LoMult,Above&AtUse4th,HiMult
-- Accel/Brake// times_ so to 'accel faster' you mult _down_ (0.5 is twice as fast)
 
   MAXSPEED = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5
 
-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

   },

    FLIGHTPERF  = {
 
		{ "Fighter", "Graph", 5, 0.90, 6, 0.90, 10, 0.90, 15, 0.90, 20, 0.80, 25, 0.50 },
		{ "Fighter_hw1", "Graph", 5, 0.90, 6, 0.90, 10, 0.90, 15, 0.90, 20, 0.80, 25, 0.50 },

		{ "Vgr_Interceptor", "Graph", 7, 0.90, 8, 0.90, 14, 0.90, 21, 0.70, 28, 0.70, 35, 0.50 },
		{ "Vgr_Bomber", "Graph", 6, 0.90, 7, 0.90, 12, 0.90, 18, 0.90, 90, 0.80, 30, 0.50 },

		{ "Vgr_MissileCorvette", "Graph", 4, 0.965, 5, 0.965, 8, 0.965, 16, 0.95, 24, 0.95, 29, 0.50 },
		{ "Vgr_LaserCorvette", "Graph", 4, 0.965, 5, 0.965, 8, 0.965, 16, 0.95, 24, 0.95, 29, 0.50 },

   },
    ENGINEACCEL = {

		{ "Fighter", "Graph", 5, 0.90, 6, 0.85, 10, 0.85, 15, 0.85, 20, 0.80, 25, 0.50 },
		{ "Fighter_hw1", "Graph", 5, 0.90, 6, 0.85, 10, 0.85, 15, 0.85, 20, 0.80, 25, 0.50 },

		{ "Vgr_Interceptor", "Graph", 7, 0.90, 8, 0.85, 14, 0.85, 21, 0.70, 28, 0.70, 35, 0.50 },

   },
    ENGINEBRAKE = {

   },
    THRUSTER = {

   },
    THRUSTERACCEL = {

		{ "Fighter", "Graph", 5, 0.90, 6, 0.85, 10, 0.85, 15, 0.85, 20, 0.80, 25, 0.50 },
		{ "Fighter_hw1", "Graph", 5, 0.90, 6, 0.85, 10, 0.85, 15, 0.85, 20, 0.80, 25, 0.50 },

		{ "Vgr_Interceptor", "Graph", 7, 0.90, 8, 0.85, 14, 0.85, 21, 0.70, 28, 0.70, 35, 0.50 },

   },
    THRUSTERBRAKE = {

   },
    ROTATION = {

   },
    ROTATIONACCEL = {

    },
    ROTATIONBRAKE = {

    },
     WEAPONCONE = {

		{ "Vgr_Scout", "Graph", 3, 1.0, 4, 0.98, 6, 0.98, 9, 0.97 },
		{ "Vgr_Interceptor", "Graph", 8, 0.99},
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.98, 12, 0.98, 18, 0.97 },

		{ "Vgr_LaserCorvette", "Graph", 4, 1.0, 5, 0.98, 8, 0.98, 16, 0.97 },

   },
    WEAPONACCURACY = {
 
   },
    WEAPONDAMAGE = {

		{ "Vgr_Interceptor",Tactic_Aggressive, "Graph", 8, 1.02},

   },
    BULLETSPEED = {
 
   },
    TURRETSPEED = {

   },
    ACCURACYAPPLIED = {
 
   },
    DAMAGEAPPLIED = {

   },
    FIRERATE = {

		{ "Vgr_Interceptor",Tactic_Aggressive, "Graph", 8, 0.78},
		{ "Vgr_Bomber",Tactic_Aggressive, "Graph", 7, 0.79},

   },
}

 
strikegroup =
{
	OffsetFromParent = {0,0,0},
	Children =
	{
		{
			OffsetFromParent                           = {0,0.95,-0.2},
		},
		{
			OffsetFromParent                           = {0,-0.95,-0.2},
		},
		{
			OffsetFromParent                           = {0.95,0,-0.2},
		},
		{
			OffsetFromParent                           = {-0.95,0,-0.2},
		},
	},
}