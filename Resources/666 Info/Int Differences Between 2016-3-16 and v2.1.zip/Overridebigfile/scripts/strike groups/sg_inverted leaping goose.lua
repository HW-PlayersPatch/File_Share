Name = "inverted leaping goose"
Order = -1.0		-- Means invisible to UI

DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{
	{
		familyname = "Fighter",
		filename = "follow_strikegroup_lead",
	},
	{
		shipname = "Hgn_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
	{
		shipname = "Vgr_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
}

reformAtPctChangeInCombat = 0.5
reformAtPctChangeIdle = 0.25

StanceGrouping = "Batch"
StanceGroupingAg = "Shape"
StanceGroupingEv = "Subs"

strikegroup = 
{
	DesiredShipTypes 		= "BigCapitalShip, SmallCapitalShip",
	OffsetFromParent 		= {0,		0,		0},
	Children = 
	{
		{
			DesiredShipTypes 		= "BigCapitalShip, SmallCapitalShip",
			OffsetFromParent 		= {-1,		0,		0},
		},
		{
			DesiredShipTypes 		= "BigCapitalShip, SmallCapitalShip",
			OffsetFromParent 		= {1,		0,		0},
		},
		{
			DesiredShipTypes 		= "BigCapitalShip",
			OffsetFromParent 		= {-1,	1,		-0.5},
			Children = 
			{
				{
					DesiredShipTypes 		= "BigCapitalShip",
					OffsetFromParent 		= {-1,	0,		-0.5},
				},
			},
		},
		{
			DesiredShipTypes 		= "BigCapitalShip",
			OffsetFromParent 		= {1,		1,		-0.5},
			Children = 
			{
				{
					DesiredShipTypes 		= "BigCapitalShip",
					OffsetFromParent 		= {1,		0,		-0.5},
				}
			},
		},
		{
			DesiredShipTypes 		= "BigCapitalShip",
			OffsetFromParent 		= {0,		-1,		-0.3},
			Children = 
			{
				{
					DesiredShipTypes 		= "BigCapitalShip",
					OffsetFromParent 		= {-1,	-0.5,	-0.2},
				},
				{
					DesiredShipTypes 		= "BigCapitalShip",
					OffsetFromParent 		= {1,		-0.5,	-0.2},

				},
			},
		},
		{
			DesiredShipTypes 		= "BigCapitalShip",
			OffsetFromParent 		= {0,		0,		-1},
			Children = 
			{
				{
					DesiredShipTypes 		= "BigCapitalShip",
					OffsetFromParent 		= {-1,	0,		0},
				},
				{
					DesiredShipTypes 		= "BigCapitalShip",
					OffsetFromParent 		= {1,		0,		0},

				},
			},
		},
		{
			DesiredShipTypes 		= "BigCapitalShip",
			OffsetFromParent 		= {0,		0,		1},
			Children = 
			{
				{
					DesiredShipTypes 		= "BigCapitalShip",
					OffsetFromParent 		= {-1,	0,		-0.3},
				},
				{
					DesiredShipTypes 		= "BigCapitalShip",
					OffsetFromParent 		= {1,		0,		-0.3},
				},
			},
		},
	},
}
