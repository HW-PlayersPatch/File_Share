Name = "Movers"
Order = 0.7		-- Controls sort order for ID use.  In the next patch ONLY names will be allowed!
Hint = "$4953"
Title = "$5463"
Hotkey = 106
Icon = {
	texture = "DATA:UI\\NewUI\\Taskbar\\FormationIcons\\form_ico_claw.dds",
	uvRect = { 0/128, 0/512, 128/128, 128/512 },
	patch_X = { 4,-120, 4,0 },
	patch_Y = { 4,-120,4, 0 },
	patch_Scale = 1,
		
	Surface = {
		surface = "ui_multistate";
		{ prop = "state0", float3 = { 0.0, 0.0, 1.0 } },
		{ prop = "state1", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "state2", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "decal", float3 = { 0.0, 0.0, 0.0 } },
	}
}

ExtFilter = "sgf_gbx,sgf_hwrm"
Tags = "sgf_hgn,sgf_kus,sgf_tai"

StanceGrouping = "Batch"
StanceGroupingAg = "Shape"
StanceGroupingEv = "Subs"

DeathDamage = 0.90
FriendlyFire = { 0.8, 0.0, 0.0 }       -- Base, Pop, PopSqrt

PopDecay = 0.01

	SpacingRange = 	 { 75, 1.45, 200, 1.1 }
	SpacingRangeAg = { 75, 1.45, 200, 1.1 }
	SpacingRangeEv = { 75, 2.0,  200, 2.0 }


DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{
                {
                                shipname = "Hgn_Destroyer",
                                filename = "follow_strikegroup_lead_broadside",
                },
                {
                                shipname = "Vgr_Destroyer",
                                filename = "follow_strikegroup_lead_broadside",
                },
}

reformAtPctChangeInCombat = 0.5
reformAtPctChangeIdle = 0.25

Multipliers = {
 
-- Leader //Const, PopRaw-1, PopSqrt-1
-- Node //Nodedepth, LoMult,Above&AtUse4th,HiMult
-- Accel/Brake// times_ so to 'accel faster' you mult _down_ (0.5 is twice as fast)
 
   MAXSPEED = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5
 
-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

 
--		{ "Fighter", "Graph", 5, 1.05, 6, 1.05, 10, 1.05, 15, 1.05, 20, 0.70, 25, 0.50 }, 
--		{ "Fighter_hw1", "Graph", 5, 1.05, 6, 1.05, 10, 1.05, 15, 1.05, 20, 0.70, 25, 0.50 },
   },

    FLIGHTPERF  = {
		{ "Fighter", "Graph", 5, 0.94, 6, 0.94, 10, 0.94, 15, 0.94, 20, 0.90, 25, 0.50 },
 		{ "Fighter_hw1", "Graph", 5, 0.94, 6, 0.94, 10, 0.94, 15, 0.94, 20, 0.90, 25, 0.50 },

		{ "Vgr_Interceptor", "Graph", 7, 0.94, 8, 0.94, 14, 0.94, 21, 0.90, 28, 0.80, 35, 0.50 },
		{ "Vgr_Bomber", "Graph", 6, 0.94, 7, 0.94, 12, 0.94, 18, 0.90, 24, 0.80, 30, 0.50 },

		{ "Corvette", "Graph", 3, 0.97, 4, 0.97, 6, 0.97, 12, 0.97, 18, 0.87, 22, 0.50 },
		{ "Corvette_hw1", "Graph", 3, 0.97, 4, 0.97, 6, 0.97, 12, 0.97, 18, 0.87, 22, 0.50 },

		{ "Vgr_MissileCorvette", "Graph", 4, 0.97, 5, 0.97, 8, 0.97, 16, 0.97, 24, 0.87, 29, 0.50 },
		{ "Vgr_LaserCorvette", "Graph", 4, 0.97, 5, 0.97, 8, 0.97, 16, 0.97, 24, 0.87, 29, 0.50 },

   },

    ENGINEACCEL = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 0.90, 6, 0.90, 10, 0.90, 15, 0.86, 20, 0.80, 25, 1.10 },
		{ "Fighter_hw1", "Graph", 5, 0.90, 6, 0.90, 10, 0.90, 15, 0.86, 20, 0.80, 25, 1.10 },

		{ "Hgn_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.05, 15, 1.10 },
		{ "Vgr_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.05, 15, 1.10 },

		{ "Vgr_Interceptor", "Graph", 7, 0.90, 8, 0.90, 14, 0.90, 21, 0.86, 28, 1.05, 35, 1.10 },
		{ "Vgr_Bomber", "Graph", 6, 0.90, 7, 0.90, 12, 0.90, 18, 0.86, 24, 1.05, 30, 1.10 },

 		{ "Corvette", "Graph", 3, 0.95, 4, 0.95, 6, 0.95, 12, 0.90, 18, 1.05, 22, 1.10 },
		{ "Corvette_hw1", "Graph", 3, 0.95, 4, 0.95, 6, 0.95, 12, 0.90, 18, 1.05, 22, 1.10 },

		{ "Vgr_MissileCorvette", "Graph", 4, 0.95, 5, 0.95, 8, 0.95, 16, 0.90, 24, 1.05, 29, 1.10 },
		{ "Vgr_LaserCorvette", "Graph", 4, 0.95, 5, 0.95, 8, 0.95, 16, 0.90, 24, 1.05, 29, 1.10 },

   },
    ENGINEBRAKE = {

   },
    THRUSTER = {

   },
    THRUSTERACCEL = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 0.90, 6, 0.90, 10, 0.90, 15, 0.86, 20, 1.05, 25, 1.10 },
		{ "Fighter_hw1", "Graph", 5, 0.90, 6, 0.90, 10, 0.90, 15, 0.86, 20, 1.05, 25, 1.10 },

		{ "Hgn_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.05, 15, 1.10 },
		{ "Vgr_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.05, 15, 1.10 },

		{ "Vgr_Interceptor", "Graph", 7, 0.90, 8, 0.90, 14, 0.90, 21, 0.86, 28, 1.05, 35, 1.10 },
		{ "Vgr_Bomber", "Graph", 6, 0.90, 7, 0.90, 12, 0.90, 18, 0.86, 24, 1.05, 30, 1.10 },

 		{ "Corvette", "Graph", 3, 0.90, 4, 0.90, 6, 0.90, 12, 0.86, 18, 1.05, 22, 1.10 },
		{ "Corvette_hw1", "Graph", 3, 0.90, 4, 0.90, 6, 0.90, 12, 0.86, 18, 1.05, 22, 1.10 },

		{ "Vgr_MissileCorvette", "Graph", 4, 0.90, 5, 0.90, 8, 0.90, 16, 0.86, 24, 1.05, 29, 1.10 },
		{ "Vgr_LaserCorvette", "Graph", 4, 0.90, 5, 0.90, 8, 0.90, 16, 0.86, 24, 1.05, 29, 1.10 },

   },
    THRUSTERBRAKE = {

   },
    ROTATION = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 0.85, 6, 0.85, 10, 0.85, 15, 0.85, 20, 0.80, 25, 0.50 },
		{ "Fighter_hw1", "Graph", 5, 0.85, 6, 0.85, 10, 0.85, 15, 0.85, 20, 0.80, 25, 0.50 },

   },
    ROTATIONACCEL = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7



 
    },
    ROTATIONBRAKE = {

    },
     WEAPONCONE = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6

		{ "Fighter", "Graph", 6, 0.969, 7, 0.97, 10, 0.96 },
		{ "Fighter_hw1", "Graph", 6, 0.97, 7, 0.97, 10, 0.96 },

		{ "Hgn_Scout", "Graph", 3, 1.0, 4, 0.98, 6, 0.98, 9, 0.97 },
		{ "Vgr_Scout", "Graph", 3, 1.0, 4, 0.98, 6, 0.98, 9, 0.97 },

		{ "Vgr_Interceptor", "Graph", 8, 0.99},
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.98, 12, 0.98, 18, 0.97 },

		{ "Corvette", "Graph", 3, 1.0, 4, 0.98, 6, 0.98, 12, 0.97 },
		{ "Corvette_hw1", "Graph", 3, 1.0, 4, 0.98, 6, 0.98, 12, 0.97 },

		{ "Vgr_LaserCorvette", "Graph", 4, 1.0, 5, 0.98, 8, 0.98, 16, 0.97 },



   },
    WEAPONACCURACY = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6


 
   },
    WEAPONDAMAGE = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6

		{ "Fighter", "Graph", 6, 1.01},
		{ "Fighter_hw1", "Graph", 6, 1.01},

		{ "Hgn_AssaultCorvette", "Graph", 6, 1.01},

   },
    BULLETSPEED = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6


 
   },
    TURRETSPEED = {
 
		{ "Corvette",Tactic_Aggressive, "Graph", 4, 1.05},



   },
    ACCURACYAPPLIED = {
 
   },
    DAMAGEAPPLIED = {

   },
    FIRERATE = {
		{ "Fighter", "Graph", 6, 0.80},
		{ "Fighter_hw1", "Graph", 6, 0.80},

		{ "Vgr_Interceptor", "Graph", 8, 0.80},


		{ "Hgn_AttackBomber", "Graph", 6, 0.89},

		{ "Vgr_Bomber",Tactic_Aggressive, "Graph", 6, 0.98, 6, 0.98 },

		{ "Corvette",Tactic_Aggressive, "Graph", 5, 0.98, 6, 0.98 },
		{ "Corvette_hw1",Tactic_Aggressive, "Graph", 5, 0.98, 6, 0.98 },

		{ "Hgn_AssaultCorvette",Tactic_Aggressive, "Graph", 6, 0.80},
   },
}

strikegroup =
{
	OffsetFromParent 		= {0,0,0},
	FacingLimit             = 0.0,
	Children =
	{
		{
			OffsetFromParent 		= {-1,1,1},
			FacingLimit             = 34.0,
			Children =
			{
				{
					OffsetFromParent 		= {-1,1,1},
					FacingLimit             = 34.0,
					Children =
					{
						{
							OffsetFromParent 		= {-1,1,1},
							FacingLimit             = 34.0,
							Children =
							{
								{
									OffsetFromParent 		= {-1,1,1},
									FacingLimit             = 34.0,
								},
							},
						},
					},
				},
			},
		},
		{
			OffsetFromParent 		= {-1,-1,1},
			FacingLimit             = 34.0,
			Children =
			{
				{
					OffsetFromParent 		= {-1,-1,1},
					FacingLimit             = 34.0,
					Children =
					{
						{
							OffsetFromParent 		= {-1,-1,1},
							FacingLimit             = 34.0,
							Children =
							{
								{
									OffsetFromParent 		= {-1,-1,1},
									FacingLimit             = 34.0,
								},
							},
						},
					},
				},
			},
		},
		{
			OffsetFromParent 		= {1,1,1},
			FacingLimit             = 34.0,
			Children =
			{
				{
					OffsetFromParent 		= {1,1,1},
					FacingLimit             = 34.0,
					Children =
					{
						{
							OffsetFromParent 		= {1,1,1},
							FacingLimit             = 34.0,
							Children =
							{
								{
									OffsetFromParent 		= {1,1,1},
									FacingLimit             = 34.0,
								},
							},
						},
					},
				},
			},
		},
		{
			OffsetFromParent 		= {1,-1,1},
			FacingLimit             = 34.0,
			Children =
			{
				{
					OffsetFromParent 		= {1,-1,1},
					FacingLimit             = 34.0,
					Children =
					{
						{
							OffsetFromParent 		= {1,-1,1},
							FacingLimit             = 34.0,
							Children =
							{
								{
									OffsetFromParent 		= {1,-1,1},
									FacingLimit             = 34.0,
								},
							},
						},
					},
				},
			},
		},
	},
}
