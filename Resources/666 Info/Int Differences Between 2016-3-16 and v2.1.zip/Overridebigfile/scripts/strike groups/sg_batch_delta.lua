Name = "Batch_delta"
Order = -1.0		-- Means invisible to UI
Hint = "$4950"
Title = "$5460"
Hotkey = 103

UIAlias = "Delta"

BatchRestrict = 1
SpacingScale = 1.45

DeathDamage = 0.1
FriendlyFire = { 0.0, 0.0, 0.0 }	-- Base, Pop, PopSqrt

LayoutMode = "Nodes"

StanceGrouping = "Batch"
StanceGroupingAg = "Shape"
StanceGroupingEv = "Subs"

DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{
	{
		shipname = "Hgn_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
	{
		shipname = "Vgr_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
}

reformAtPctChangeInCombat = 0.5
reformAtPctChangeIdle = 0.25



strikegroup =
{
	OffsetFromParent 		= {0,0,0},
	Children =
	{
		{
			OffsetFromParent 		= {-1,-0.1,-1},
			Children =
			{
				{
					Name = "ArmL",
					OffsetFromParent 		= {-1,0.25,-1},
					Children =
					{
						{
							OffsetFromParent 		= {-1,-0.25,-1},
							Proxies = { "ArmL" },
						},
					},
				},
			},
		},
		{
			OffsetFromParent 		= {1,-0.1,-1},
			Children =
			{
				{
					Name = "ArmR",
					OffsetFromParent 		= {1,0.25,-1},
					Children =
					{
						{
							OffsetFromParent 		= {1,-0.25,-1},
							Proxies = { "ArmR" },
						},
					},
				},
			},
		},
	},
}

