Name = "Sphere"
Order = 0.9		-- Controls sort order for ID use.  In the next patch ONLY names will be allowed!
Hint = "$4955"
Title = "$5465"
Hotkey = 108
Icon = {
	texture = "DATA:UI\\NewUI\\Taskbar\\FormationIcons\\form_ico_sphere.dds",
	uvRect = { 0/128, 0/512, 128/128, 128/512 },
	patch_X = { 4,-120, 4,0 },
	patch_Y = { 4,-120,4, 0 },
	patch_Scale = 1,
		
	Surface = {
		surface = "ui_multistate";
		{ prop = "state0", float3 = { 0.0, 0.0, 1.0 } },
		{ prop = "state1", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "state2", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "decal", float3 = { 0.0, 0.0, 0.0 } },
	}
}

ExtFilter = "sgf_gbx,sgf_hwrm"
Tags = "sgf_common"

StanceGrouping = "None"
LayoutMode = "Sphere"

DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{
	{
		familyname = "Fighter",
		filename = "follow_strikegroup_lead",
	},
	{
		shipname = "Hgn_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
	{
		shipname = "Vgr_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
}
LeaderAttackStyles =
{
	{
		familyname = "Fighter",
		filename = "frontal",
	},
	{
		familyname = "Fighter_hw1",
		filename = "frontal",
	},
	{
		familyname = "Corvette",
		filename = "frontal",
	},
	{
		familyname = "Corvette_hw1",
		filename = "frontal",
	},
	{
		familyname = "Frigate",
		filename = "frontal",
	}
}

reformAtPctChangeInCombat = 0.5
reformAtPctChangeIdle = 0.25
targetIsCenter = 1
parentSpacingOnly = 1
dontPerformActions = 1
howToBreakFormation = "BreakImmediately"

strikegroup = 
{
    OffsetFromParent         = {0,0,0},
    NumberOfPlaces           = -1,
    CalculateChildren        = "CalcSphere",
    CalculateOffsetDist      = 1.0,
}
