Name = "Batch_Dart"
Order = -1.0		-- Means invisible to UI
Hint = "$4953"
Title = "$5463"
Hotkey = 106

Tags = "sgf_vgr"

UIAlias = "Vgr_Dart"

BatchRestrict = 1
SpacingScale = 1.30

DeathDamage = 0.1
FriendlyFire = { 0.0, 0.0, 0.0 }	-- Base, Pop, PopSqrt

LayoutMode = "Nodes"

StanceGrouping = "Batch"
StanceGroupingAg = "Shape"
StanceGroupingEv = "Subs"

DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{

	{
		shipname = "Hgn_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
	{
		shipname = "Vgr_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
}

Multipliers = {
     BULLETSPEED = {
--		{ "Vgr_Interceptor", "Graph", 1, 1.10 },
   },
}

strikegroup =
{
	OffsetFromParent 		= {0,0,0},
	Children =
	{
		-- 'Near' nodes...
		{
			OffsetFromParent 		= {0.377974,0.654651,-0.854651},	
			Children = {{ OffsetFromParent 		= {0.377974,0.654651,-1.854651}, }},
		},
		{
			OffsetFromParent 		= {-0.755881,0.0,-0.854651},
			Children = {{ OffsetFromParent 		= {-0.755881,0.0,-1.854651}, }},
		},
		{
			OffsetFromParent 		= {0.377974,-0.654651,-0.854651},
			Children = {{ OffsetFromParent 		= {0.377974,-0.654651,-1.854651}, }},
		},
		-- 'Far' nodes...
		{
			OffsetFromParent 		= {-0.377974,0.654651,-1.804651},
			Children = {{ OffsetFromParent 		= {-0.377974,0.654651,-1.854651}, }},
		},
		{
			OffsetFromParent 		= {0.755881,0.0,-1.804651},
			Children = {{ OffsetFromParent 		= {0.755881,0.0,-1.854651}, }},
		},
		{
			OffsetFromParent 		= {-0.377974,-0.654651,-1.804651},
			Children = {{ OffsetFromParent 		= {-0.377974,-0.654651,-1.854651}, }},
		},
	},
}
