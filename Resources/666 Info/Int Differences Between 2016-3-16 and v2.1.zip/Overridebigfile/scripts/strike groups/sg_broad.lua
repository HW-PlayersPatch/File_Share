Name = "Broad"
Order = 0.5		-- Controls sort order for ID use.  In the next patch ONLY names will be allowed!
Hint = "$4951"
Title = "$5461"
Hotkey = 104
Icon = {
	texture = "DATA:UI\\NewUI\\Taskbar\\FormationIcons\\form_ico_broad.dds",
	uvRect = { 0/128, 0/512, 128/128, 128/512 },
	patch_X = { 4,-120, 4,0 },
	patch_Y = { 4,-120,4, 0 },
	patch_Scale = 1,
		
	Surface = {
		surface = "ui_multistate";
		{ prop = "state0", float3 = { 0.0, 0.0, 1.0 } },
		{ prop = "state1", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "state2", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "decal", float3 = { 0.0, 0.0, 0.0 } },
	}
}

ExtFilter = "sgf_gbx,sgf_hwrm"
Tags = "sgf_common"

StanceGrouping = "Batch"
StanceGroupingAg = "Shape"
StanceGroupingEv = "Subs"

DeathDamage = 0.85
FriendlyFire = { 0.7, 0.0, 0.0 }       -- Base, Pop, PopSqrt

PopDecay = 0.01

	SpacingRange = 	 { 75, 1.45, 200, 1.1 }
	SpacingRangeAg = { 75, 1.45, 200, 1.1 }
	SpacingRangeEv = { 75, 2.0,  200, 2.0 }


DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{
	{
		shipname = "Hgn_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
	{
		shipname = "Vgr_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
}

reformAtPctChangeInCombat = 0.5
reformAtPctChangeIdle = 0.25
 
Multipliers = {
 
-- Leader //Const, PopRaw-1, PopSqrt-1
-- Node //Nodedepth, LoMult,Above&AtUse4th,HiMult
-- Accel/Brake// times_ so to 'accel faster' you mult _down_ (0.5 is twice as fast)
 
   MAXSPEED = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5
 
-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

   },

    FLIGHTPERF  = {
 
		{ "Fighter", "Graph", 5, 1.0, 6, 0.95, 10, 0.95, 15, 0.90, 20, 0.86, 25, 0.50 },
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.95, 10, 0.95, 15, 0.90, 20, 0.86, 25, 0.50 },

		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 0.95, 14, 0.95, 21, 0.86, 28, 0.70, 35, 0.50 },
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.95, 12, 0.95, 18, 0.86, 24, 0.70, 30, 0.50 },

		{ "Corvette", "Graph", 3, 1.0, 4, 0.97, 6, 0.97, 12, 0.90, 18, 0.84, 22, 0.50 },
		{ "Corvette_hw1", "Graph", 3, 1.0, 4, 0.97, 6, 0.97, 12, 0.90, 18, 0.84, 22, 0.50 },

		{ "Vgr_MissileCorvette", "Graph", 4, 1.0, 5, 0.97, 8, 0.97, 16, 0.90, 24, 0.84, 29, 0.50 },
		{ "Vgr_LaserCorvette", "Graph", 4, 1.0, 5, 0.97, 8, 0.97, 16, 0.90, 24, 0.84, 29, 0.50 },

   },

    ENGINEACCEL = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 1.0, 6, 0.90, 10, 0.90, 15, 0.86, 20, 1.05, 25, 1.10 },
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.90, 10, 0.90, 15, 0.86, 20, 1.05, 25, 1.10 },

		{ "Hgn_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.05, 15, 1.10 },
		{ "Vgr_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.05, 15, 1.10 },

		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 0.90, 14, 0.90, 21, 0.86, 28, 1.05, 35, 1.10 },
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.90, 12, 0.90, 18, 0.86, 24, 1.05, 30, 1.10 },

 		{ "Corvette", "Graph", 3, 1.0, 4, 0.95, 6, 0.95, 12, 0.90, 18, 1.05, 22, 1.10 },
		{ "Corvette_hw1", "Graph", 3, 1.0, 4, 0.95, 6, 0.95, 12, 0.90, 18, 1.05, 22, 1.10 },

		{ "Vgr_MissileCorvette", "Graph", 4, 1.0, 5, 0.95, 8, 0.95, 16, 0.90, 24, 1.05, 29, 1.10 },
		{ "Vgr_LaserCorvette", "Graph", 4, 1.0, 5, 0.95, 8, 0.95, 16, 0.90, 24, 1.05, 29, 1.10 },

   },
    ENGINEBRAKE = {

   },
    THRUSTER = {

   },
    THRUSTERACCEL = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 1.0, 6, 0.90, 10, 0.90, 15, 0.86, 20, 1.05, 25, 1.10 },
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.90, 10, 0.90, 15, 0.86, 20, 1.05, 25, 1.10 },

		{ "Hgn_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.05, 15, 1.10 },
		{ "Vgr_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.05, 15, 1.10 },

		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 0.90, 14, 0.90, 21, 0.86, 28, 1.05, 35, 1.10 },
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.90, 12, 0.90, 18, 0.86, 24, 1.05, 30, 1.10 },

 		{ "Corvette", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 12, 0.86, 18, 1.05, 22, 1.10 },
		{ "Corvette_hw1", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 12, 0.86, 18, 1.05, 22, 1.10 },

		{ "Vgr_MissileCorvette", "Graph", 4, 1.0, 5, 0.90, 8, 0.90, 16, 0.86, 24, 1.05, 29, 1.10 },
		{ "Vgr_LaserCorvette", "Graph", 4, 1.0, 5, 0.90, 8, 0.90, 16, 0.86, 24, 1.05, 29, 1.10 },

   },
    THRUSTERBRAKE = {

   },
    ROTATION = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 1.0, 6, 1.05, 10, 1.05, 15, 1.07, 20, 0.70, 25, 0.50 }, 
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 1.05, 10, 1.05, 15, 1.07, 20, 0.70, 25, 0.50 }, 

		{ "Hgn_Scout", "Graph", 3, 1.0, 4, 1.05, 6, 1.05, 9, 1.07, 12, 0.70, 15, 0.50 }, 
		{ "Vgr_Scout", "Graph", 3, 1.0, 4, 1.05, 6, 1.05, 9, 1.07, 12, 0.70, 15, 0.50 }, 

		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 1.05, 14, 1.05, 21, 1.07, 28, 0.70, 35, 0.50 }, 
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 1.05, 12, 1.05, 18, 1.07, 24, 0.70, 30, 0.50 }, 

		{ "Corvette", "Graph", 3, 1.0, 4, 1.05, 6, 1.05, 12, 1.07, 18, 0.70, 22, 0.50 }, 
		{ "Corvette_hw1", "Graph", 3, 1.0, 4, 1.05, 6, 1.05, 12, 1.07, 18, 0.70, 22, 0.50 }, 

		{ "Vgr_MissileCorvette", "Graph", 4, 1.0, 5, 1.05, 8, 1.05, 16, 1.07, 24, 0.70, 29, 0.50 }, 
		{ "Vgr_LaserCorvette", "Graph", 4, 1.0, 5, 1.05, 8, 1.05, 16, 1.07, 24, 0.70, 29, 0.50 }, 

   },
    ROTATIONACCEL = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 1.0, 6, 0.90, 10, 0.90, 15, 0.86, 20, 1.70, 25, 1.50 }, 
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.90, 10, 0.90, 15, 0.86, 20, 1.70, 25, 1.50 }, 

		{ "Hgn_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.70, 15, 1.50 }, 
		{ "Vgr_Scout", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 9, 0.86, 12, 1.70, 15, 1.50 }, 

		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 0.90, 14, 0.90, 21, 0.86, 28, 1.70, 35, 1.50 }, 
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.90, 12, 0.90, 18, 0.86, 24, 1.70, 30, 1.50 }, 

		{ "Corvette", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 12, 0.86, 18, 1.70, 22, 1.50 }, 
		{ "Corvette_hw1", "Graph", 3, 1.0, 4, 0.90, 6, 0.90, 12, 0.86, 18, 1.70, 22, 1.50 }, 

		{ "Vgr_MissileCorvette", "Graph", 4, 1.0, 5, 0.90, 8, 0.90, 16, 0.86, 24, 1.70, 29, 1.50 }, 
		{ "Vgr_LaserCorvette", "Graph", 4, 1.0, 5, 0.90, 8, 0.90, 16, 0.86, 24, 1.70, 29, 1.50 }, 


 
    },
    ROTATIONBRAKE = {

    },
     WEAPONCONE = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6

		{ "Fighter", "Graph", 5, 1.0, 6, 0.98, 10, 0.98, 15, 0.97 },
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.98, 10, 0.98, 15, 0.97 },

		{ "Hgn_Scout", "Graph", 3, 1.0, 4, 0.98, 6, 0.98, 9, 0.97 },
		{ "Vgr_Scout", "Graph", 3, 1.0, 4, 0.98, 6, 0.98, 9, 0.97 },

		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 0.98, 21, 0.97, 28, 0.97 },
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.98, 12, 0.98, 18, 0.97 },

		{ "Corvette", "Graph", 3, 1.0, 4, 0.98, 6, 0.98, 12, 0.97 },
		{ "Corvette_hw1", "Graph", 3, 1.0, 4, 0.98, 6, 0.98, 12, 0.97 },

		{ "Vgr_LaserCorvette", "Graph", 4, 1.0, 5, 0.98, 8, 0.98, 16, 0.97 },



   },
    WEAPONACCURACY = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6

		{ "Fighter",Tactic_Aggressive, "Graph", 5, 1.02, 6, 1.05, 10, 1.05, 15, 1.09, 20, 1.09 },
		{ "Fighter_hw1",Tactic_Aggressive, "Graph", 5, 1.02, 6, 1.05, 10, 1.05, 15, 1.09, 20, 1.09 },

		{ "Hgn_Scout",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.05, 6, 1.05, 9, 1.09, 12, 1.09 },
		{ "Vgr_Scout",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.05, 6, 1.05, 9, 1.09, 12, 1.09 },

		{ "Vgr_Interceptor",Tactic_Aggressive, "Graph", 7, 1.0, 8, 1.049, 14, 1.049, 21, 1.00, 28, 1.00 },
		{ "Vgr_Bomber",Tactic_Aggressive, "Graph", 6, 1.0, 7, 1.05, 12, 1.05, 18, 1.09, 24, 1.09 },

		{ "Corvette",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.05, 6, 1.05, 12, 1.09, 18, 1.09 },
		{ "Corvette_hw1",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.05, 6, 1.05, 12, 1.09, 18, 1.09 },

		{ "Vgr_MissileCorvette",Tactic_Aggressive, "Graph", 4, 1.0, 5, 1.05, 8, 1.05, 16, 1.09, 24, 1.09 },
		{ "Vgr_LaserCorvette",Tactic_Aggressive, "Graph", 4, 1.0, 5, 1.05, 8, 1.05, 16, 1.09, 24, 1.09 },

 
   },
    WEAPONDAMAGE = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6


		{ "Hgn_PulsarCorvette",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.06, 6, 1.06, 12, 1.09, 18, 1.09 },
		{ "Vgr_MissileCorvette",Tactic_Aggressive, "Graph", 4, 1.0, 5, 1.06, 8, 1.06, 16, 1.09, 24, 1.09 }, 

 
   },
    BULLETSPEED = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6

		{ "Fighter",Tactic_Aggressive, "Graph", 5, 1.40, 6, 1.40, 10, 1.40, 15, 1.50, 20, 1.50 },
		{ "Fighter_hw1",Tactic_Aggressive, "Graph", 5, 1.40, 6, 1.40, 10, 1.40, 15, 1.50, 20, 1.50 },

		{ "Hgn_Scout",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.40, 6, 1.40, 9, 1.50, 12, 1.50 },
		{ "Vgr_Scout",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.40, 6, 1.40, 9, 1.50, 12, 1.50 },

		{ "Vgr_Interceptor",Tactic_Aggressive, "Graph", 7, 1.0, 8, 1.40, 14, 1.40, 21, 1.50, 28, 1.50 },
		{ "Vgr_Bomber",Tactic_Aggressive, "Graph", 6, 1.0, 7, 1.40, 12, 1.40, 18, 1.50, 24, 1.50 },

		{ "Corvette",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.20, 6, 1.20, 12, 1.30, 18, 1.30 },
		{ "Corvette_hw1",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.20, 6, 1.20, 12, 1.30, 18, 1.30 },

		{ "Hgn_AssaultCorvette",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.30, 6, 1.30, 12, 1.40, 18, 1.40 },

		{ "Kus_LightCorvette",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.40, 6, 1.40, 12, 1.50, 18, 1.50 },
		{ "Tai_LightCorvette",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.40, 6, 1.40, 12, 1.50, 18, 1.50 },

		{ "Kus_MultiGunCorvette",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.40, 6, 1.40, 12, 1.50, 18, 1.50 },

		{ "Vgr_LaserCorvette",Tactic_Aggressive, "Graph", 4, 1.0, 5, 1.50, 8, 1.50, 16, 1.60, 24, 1.60 },
 
   },
    TURRETSPEED = {
 
		{ "Corvette",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.40, 6, 1.40, 12, 1.50, 18, 1.50 },
		{ "Corvette_hw1",Tactic_Aggressive, "Graph", 3, 1.0, 4, 1.40, 6, 1.40, 12, 1.50, 18, 1.50 },
   },
    ACCURACYAPPLIED = {
 
		{ "Fighter",Tactic_Aggressive, "Graph", 5, 1.15, 6, 1.15 },
		{ "Fighter_hw1",Tactic_Aggressive, "Graph", 5, 1.15, 6, 1.15 },

		{ "Fighter",Tactic_Evasive, "Graph", 5, 0.5, 6, 0.5 },
		{ "Fighter_hw1",Tactic_Evasive, "Graph", 5, 0.5, 6, 0.5 },

		{ "Vgr_Interceptor",Tactic_Aggressive, "Graph", 7, 1.15, 8, 1.15 },
		{ "Vgr_Bomber",Tactic_Aggressive, "Graph", 6, 1.15, 7, 1.15 },

		{ "Vgr_Interceptor",Tactic_Evasive, "Graph", 7, 0.5, 8, 0.5 },
		{ "Vgr_Bomber",Tactic_Evasive, "Graph", 6, 0.5, 7, 0.5 },

		{ "Corvette",Tactic_Aggressive, "Graph", 5, 1.01, 6, 1.01 },
		{ "Corvette_hw1",Tactic_Aggressive, "Graph", 5, 1.01, 6, 1.01 },

		{ "Kus_HeavyCorvette",Tactic_Aggressive, "Graph", 5, 1.03, 6, 1.03 },
		{ "Tai_HeavyCorvette",Tactic_Aggressive, "Graph", 5, 1.03, 6, 1.03 },
   },
 
}

strikegroup =
{
	OffsetFromParent 		= {0,0,0},
	Children =
	{
		{
			OffsetFromParent 		= {-1,0,0},
			Children =
			{
				{
					OffsetFromParent 		= {-1,0,0},
					Children =
					{
						{
							OffsetFromParent 		= {-1,0,0},
							Children =
							{
								{
									OffsetFromParent 		= {-1,0,0},
								},
							},
						},
					},
				},
			},
		},
		{
			OffsetFromParent 		= {1,0,0},
			Children =
			{
				{
					OffsetFromParent 		= {1,0,0},
					Children =
					{
						{
							OffsetFromParent 		= {1,0,0},
							Children =
							{
								{
									OffsetFromParent 		= {1,0,0},
								},
							},
						},
					},
				},
			},
		},
	},
}
