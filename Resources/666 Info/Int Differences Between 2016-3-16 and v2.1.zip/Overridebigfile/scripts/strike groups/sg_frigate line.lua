Name = "Frigate Line"
Order = 0.2		-- Controls sort order for ID use.  In the next patch ONLY names will be allowed!
AI = 1
Hint = "$2736"
Title = "$3166"
Hotkey = 29
Icon = {
	texture = "DATA:UI\\NewUI\\Taskbar\\FormationIcons\\form_ico_frigate_line.dds",
	uvRect = { 0/128, 0/512, 128/128, 128/512 },
	patch_X = { 4,-120, 4,0 },
	patch_Y = { 4,-120,4, 0 },
	patch_Scale = 1,
		
	Surface = {
		surface = "ui_multistate";
		{ prop = "state0", float3 = { 0.0, 0.0, 1.0 } },
		{ prop = "state1", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "state2", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "decal", float3 = { 0.0, 0.0, 0.0 } },
	}
}

ExtFilter = "sgf_gbx,sgf_hwrm"
Tags = "sgf_common"

StanceGrouping = "Batch"
StanceGroupingAg = "Shape"
StanceGroupingEv = "Subs"

DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{
	{
		familyname = "Fighter",
		filename = "follow_strikegroup_lead",
	},
	{
		shipname = "Hgn_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
	{
		shipname = "Vgr_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
}

reformAtPctChangeInCombat = 0.5
reformAtPctChangeIdle = 0.25

strikegroup =
{
	DesiredShipTypes 		= "BigCapitalShip, SmallCapitalShip, Mothership, Capturer",
	OffsetFromParent 		= {0,0,0},
	Children =
	{
		{
			DesiredShipTypes 		= "BigCapitalShip, SmallCapitalShip, Mothership, Capturer",
			OffsetFromParent 		= {-1,0,0},
		},
		{
			DesiredShipTypes 		= "BigCapitalShip, SmallCapitalShip, Mothership, Capturer",
			OffsetFromParent 		= {1,0,0},
		},
		{
			DesiredShipTypes 		= "BigCapitalShip, SmallCapitalShip, Mothership, Capturer",
			OffsetFromParent 		= {0,-1,0},
		},
		{
			DesiredShipTypes 		= "BigCapitalShip, SmallCapitalShip, Mothership, Capturer",
			OffsetFromParent 		= {0,1,0},
		},
		{
			DesiredShipTypes 		= "Frigate",
			OffsetFromParent 		= {0,0,1},
			Children =
			{
				{
					DesiredShipTypes 		= "Frigate",
					OffsetFromParent 		= {0,1,0},
					Children =
					{
						{
							DesiredShipTypes 		= "Frigate",
							OffsetFromParent 		= {-1,0,0},
						},
						{
							DesiredShipTypes 		= "Frigate",
							OffsetFromParent 		= {1,0,0},
						},	
					},
				},
				{
					DesiredShipTypes 		= "Frigate",
					OffsetFromParent 		= {1,0,0},
				},
				{
					DesiredShipTypes 		= "Frigate",
					OffsetFromParent 		= {-1,0,0},
				},
				{
					DesiredShipTypes 		= "Frigate",
					OffsetFromParent 		= {0,-1,0},
					Children =
					{
						{
							DesiredShipTypes 		= "Frigate",
							OffsetFromParent 		= {-1,0,0},
						},
						{
							DesiredShipTypes 		= "Frigate",
							OffsetFromParent 		= {1,0,0},
						},	
					},
				},
			},
		},
		
		{
			DesiredShipTypes 		= "Fighter, Corvette, Utility",
			OffsetFromParent 		= {0,0.75,0},
			Children =
			{
				{
					DesiredShipTypes 		= "Fighter, Corvette, Utility",
					OffsetFromParent 		= {-1,0,0},
				},
				{
					DesiredShipTypes 		= "Fighter, Corvette, Utility",
					OffsetFromParent 		= {1,0,0},
				},	
				{
					DesiredShipTypes 		= "Fighter, Corvette, Utility",
					OffsetFromParent 		= {0,0,-1},
				},
			},
		},
		
		{
			DesiredShipTypes 		= "Fighter, Corvette, Utility",
			OffsetFromParent 		= {0,-0.75,0},
			Children =
			{
				{
					DesiredShipTypes 		= "Fighter, Corvette, Utility",
					OffsetFromParent 		= {-1,0,0},
				},
				{
					DesiredShipTypes 		= "Fighter, Corvette, Utility",
					OffsetFromParent 		= {1,0,0},
				},	
				{
					DesiredShipTypes 		= "Fighter, Corvette, Utility",
					OffsetFromParent 		= {0,0,-1},
				},
			},
		},
	},
}

	
	
		
	
	
	
	
	