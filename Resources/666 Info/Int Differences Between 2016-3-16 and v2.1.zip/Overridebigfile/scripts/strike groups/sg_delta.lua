Name = "Delta"
Order = 0.4		-- Controls sort order for ID use.  In the next patch ONLY names will be allowed!
Hint = "$4950"
Title = "$5460"
Hotkey = 103
Icon = {
	texture = "DATA:UI\\NewUI\\Taskbar\\FormationIcons\\form_ico_delta.dds",
	uvRect = { 0/128, 0/512, 128/128, 128/512 },
	patch_X = { 4,-120, 4,0 },
	patch_Y = { 4,-120,4, 0 },
	patch_Scale = 1,
		
	Surface = {
		surface = "ui_multistate";
		{ prop = "state0", float3 = { 0.0, 0.0, 1.0 } },
		{ prop = "state1", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "state2", float3 = { 0.0, 0.0, 0.0 } },
		{ prop = "decal", float3 = { 0.0, 0.0, 0.0 } },
	}
}

ExtFilter = "sgf_gbx,sgf_hwrm"
Tags = "sgf_hgn,sgf_kus,sgf_tai"

StanceGrouping = "Batch"
StanceGroupingAg = "Shape"
StanceGroupingEv = "Subs"

DeathDamage = 0.85
FriendlyFire = { 0.7, 0.0, 0.0 }       -- Base, Pop, PopSqrt

PopDecay = 0.01

	SpacingRange = 	 { 75, 1.45, 200, 1.1 }
	SpacingRangeAg = { 75, 1.45, 200, 1.1 }
	SpacingRangeEv = { 75, 2.0,  200, 2.0 }

DefaultFollowAttackStyle = "follow_strikegroup_lead"
FollowAttackStyles =
{
	{
		shipname = "Hgn_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
	{
		shipname = "Vgr_Destroyer",
		filename = "follow_strikegroup_lead_broadside",
	},
}

reformAtPctChangeInCombat = 0.5
reformAtPctChangeIdle = 0.25

Multipliers = {
 
-- Leader //Const, PopRaw-1, PopSqrt-1
-- Node //Nodedepth, LoMult,Above&AtUse4th,HiMult
-- Accel/Brake// times_ so to 'accel faster' you mult _down_ (0.5 is twice as fast)
 
   MAXSPEED = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5
 
-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7


   },

    FLIGHTPERF  = {
 
		{ "Fighter", "Graph", 5, 1.0, 6, 0.80, 10, 0.80, 15, 0.60, 20, 0.60, 25, 1.10 },
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.80, 10, 0.80, 15, 0.60, 20, 0.60, 25, 1.10 },

		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 0.92, 14, 0.92, 21, 0.70, 28, 0.70, 35, 0.50 },
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.92, 12, 0.92, 18, 0.90, 90, 0.80, 30, 0.50 },



   },
    ENGINEACCEL = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7


		{ "Fighter", "Graph", 5, 1.0, 6, 0.80, 10, 0.80, 15, 0.60, 20, 0.60, 25, 1.10 },
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.80, 10, 0.80, 15, 0.60, 20, 0.60, 25, 1.10 },


		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 0.85, 14, 0.80, 21, 0.60, 28, 0.60, 35, 1.10 },
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.85, 12, 0.80, 18, 0.60, 24, 0.60, 30, 1.10 },



   },
    ENGINEBRAKE = {

   },
    THRUSTER = {

   },
    THRUSTERACCEL = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 1.0, 6, 0.85, 10, 0.85, 15, 0.60, 20, 0.60, 25, 1.10 },
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.85, 10, 0.85, 15, 0.60, 20, 0.60, 25, 1.10 },


		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 0.95, 14, 0.90, 21, 0.80, 28, 0.80, 35, 1.10 },
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.95, 12, 0.90, 18, 0.80, 24, 0.80, 30, 1.10 },


   },
    THRUSTERBRAKE = {

   },
    ROTATION = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 1.0, 6, 0.85, 10, 0.85, 15, 0.60, 20, 0.60, 25, 1.10 },
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.85, 10, 0.85, 15, 0.60, 20, 0.60, 25, 1.10 }, 


   },
    ROTATIONACCEL = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20,25
-- Hig Fighter - 1,1+,2,3,4,5

-- Hig Pop - 3,4,6,12,18,21
-- Hig Vette - 1,1+,2,4,6,7

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24,28
-- Vay Vette - 1,1+,2,4,6,7

		{ "Fighter", "Graph", 5, 1.0, 6, 0.85, 10, 0.85, 15, 0.60, 20, 0.60, 25, 1.10 },
		{ "Fighter_hw1", "Graph", 5, 1.0, 6, 0.85, 10, 0.85, 15, 0.60, 20, 0.60, 25, 1.10 },

		{ "Vgr_Interceptor", "Graph", 7, 1.0, 8, 0.94, 14, 0.94, 21, 1.05, 28, 1.05, 35, 1.50 }, 
		{ "Vgr_Bomber", "Graph", 6, 1.0, 7, 0.94, 12, 0.94, 18, 1.06, 24, 1.05, 30, 1.50 }, 


 
    },
    ROTATIONBRAKE = {

    },
     WEAPONCONE = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6


   },
    WEAPONACCURACY = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6


 
   },
    WEAPONDAMAGE = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6



   },
    BULLETSPEED = {

-- HW2 Pop - 3,4,6,9,12,15
-- HW2 Scout - 1,1+,2,3,4,5

-- Hig Pop - 5,6,10,15,20
-- Hig Fighter - 1,1+,2,3,4

-- Hig Pop - 3,4,6,12,18
-- Hig Vette - 1,1+,2,4,6

-- Vay Pop - 7,8,14,21,28,35
-- Vay Fighter -1,1+,2,3,4,5

-- Vay Pop - 6,7,12,18,24,30
-- Vay Bomber - 1,1+,2,3,4,5

-- Vaygr Pop 4,5,8,16,24
-- Vay Vette - 1,1+,2,4,6


 
   },
    TURRETSPEED = {
 
		{ "Corvette",Tactic_Aggressive, "Graph", 4, 1.05},

   },
    ACCURACYAPPLIED = {
 
   },
    DAMAGEAPPLIED = {

   },
    FIRERATE = {
		{ "Fighter",Tactic_Aggressive, "Graph", 6, 0.89},
		{ "Fighter_hw1",Tactic_Aggressive, "Graph", 6, 0.89},

		{ "Vgr_Interceptor",Tactic_Aggressive, "Graph", 8, 0.89},


		{ "Hgn_AttackBomber",Tactic_Aggressive, "Graph", 6, 0.89},

		{ "Vgr_Bomber",Tactic_Aggressive, "Graph", 6, 0.89},

		{ "Corvette",Tactic_Aggressive, "Graph", 5, 0.98, 6, 0.98 },
		{ "Corvette_hw1",Tactic_Aggressive, "Graph", 5, 0.98, 6, 0.98 },

		{ "Hgn_AssaultCorvette",Tactic_Aggressive, "Graph", 6, 0.80},

   },
}


strikegroup =
{
	OffsetFromParent 		= {0,0,0},
	Children =
	{
		{
			OffsetFromParent 		= {-1,-0.1,-1},
			Children =
			{
				{
					Name = "ArmL",
					OffsetFromParent 		= {-1,0.25,-1},
					Children =
					{
						{
							OffsetFromParent 		= {-1,-0.25,-1},
							Proxies = { "ArmL" },
						},
					},
				},
			},
		},
		{
			OffsetFromParent 		= {1,-0.1,-1},
			Children =
			{
				{
					Name = "ArmR",
					OffsetFromParent 		= {1,0.25,-1},
					Children =
					{
						{
							OffsetFromParent 		= {1,-0.25,-1},
							Proxies = { "ArmR" },
						},
					},
				},
			},
		},
	},
}
