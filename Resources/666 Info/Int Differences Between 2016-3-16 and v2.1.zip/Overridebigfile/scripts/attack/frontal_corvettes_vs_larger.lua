--===========================================================================
-- Tactics supported AttackStyle for formations
-- gbx_cole
--===========================================================================

function DegToRad(angle)
	return angle * ((2.0*3.141592653589)/360.0)
end

AttackStyleName = FaceTarget

Data = 
{

-- when approaching the target use this method to split the formation and transition in to the attack style
	howToBreakFormation = None,
	

-- Once past this amount * the weapon range the ship will stop and face the target
	inRangeFactor		= 0.78,
	inRangeFactorAg		= 0.75,
	inRangeFactorEv		= 0.95,
    
-- once in range and facing the target we will slide around maintaining heading until we are more 
-- then this multiplied by our range from the target, then we will fly normally to catch up

        slideDistanceMultiplier = 1.5,

	tooSlowSpeed		= 3.0,
	tooFastMultiplier	= 1.4,
	facingAngle		= 0,
		
-- when doing a move attack we will break off if after we get further than this multipled by our max weapon range from the target.
	moveAttackMaxDistanceMultiplier = 1.2,
	
    	tryToMatchHeight = 0,
    	tryToGetAboveTarget = 0,
	
-- delays for the things the attack style can do (in seconds)
   	flyToTargetBecauseItsFarOutOfRangeDelay = 2.0,
    	flyToTargetBecauseItsMovingAwayDelay = 2.0,
    	stopAndFaceTheTargetDelay = 2.0,
    	flyToAboveTheTargetDelay = 4.0,

	safeDistanceFromTargetToDoActions   = 500.0,
	safeDistanceFromTargetToDoActionsAg = 500.0,
	safeDistanceFromTargetToDoActionsEv = 500.0,
    

-- done at the end of every strafing run

	RandomActions = 
                {
                {
                	Type = PickNewTarget,
			heatCost = 5,
 			heatThresh = 0,
                        Weighting = 10,
                },
                {
                        Type = NoAction,
			heatCost = 5,
 			heatThresh = 0,
                        Weighting = 10,
                },
		{
                        Type = MoveRoundTarget,
			minParam = DegToRad(-35),
			maxParam = DegToRad(75),
			heatCost = 5,
 			heatThresh = 0,
                        tactics = "Ev",
                        Weighting = 10,
                },
		{
                        Type = MoveRoundTarget,
			minParam = DegToRad(-45),
			maxParam = DegToRad(35),
			heatCost = 5,
 			heatThresh = 0,
                        tactics = "Ev",
                        Weighting = 10,
                },
		{
                        Type = MoveRoundTarget,
			minParam = DegToRad(-55),
			maxParam = DegToRad(45),
			heatCost = 5,
 			heatThresh = 0,
                        tactics = "Ev",
                        Weighting = 10,
                },
		{
			Type = InterpolateTarget,
			minParam = 3,
			maxParam = 6,
			heatCost = 5,
 			heatThresh = 0,
			tactics = "Ev",
			Weighting = 10,
		},		{
			Type = InterpolateTarget,
			minParam = 1,
			maxParam = 3,
			heatCost = 10,
 			heatThresh = 0,
			tactics = "Ag",
			Weighting = 10,
		},
		{
                        Type = MoveRoundTarget,
			minParam = DegToRad(1),
			maxParam = DegToRad(5),
			heatCost = 7,
 			heatThresh = 0,
			tactics = "Ag,Pa",
                        Weighting = 10,
                },
		{
                        Type = MoveRoundTarget,
			minParam = DegToRad(-2),
			maxParam = DegToRad(-7),
			heatCost = 8,
 			heatThresh = 0,
			tactics = "Ag,Pa",
                        Weighting = 10,
                },
		{
                        Type = MoveRoundTarget,
			minParam = DegToRad(3),
			maxParam = DegToRad(4),
			heatCost = 9,
 			heatThresh = 0,
			tactics = "Ag,Pa",
                        Weighting = 10,
                },
		{
			Type = FlightManeuver,
			Weighting = 10,
			FlightManeuverName = "RollCCW_Evasive_Static",
			heatCost = 5,
 			heatThresh = 0,
			tactics = "Ev",
		},
		{
			Type = FlightManeuver,
			Weighting = 10,
			FlightManeuverName = "DodgeRoll_Right_Static_Evasive",
			heatCost = 5,
 			heatThresh = 0,
			tactics = "Ev",
		},
		{
			Type = FlightManeuver,
			Weighting = 10,
			FlightManeuverName = "DodgeRoll_Left_Static_Evasive",
			heatCost = 5,
 			heatThresh = 0,
			tactics = "Ev",
		},
                },

                BeingAttackedActions =
                {

                },

                FiringActions =
                {
		{
                        Type = NoAction,
                        Weighting = 10,
                        tactics = "Ev",
                },
		{
			Type = NoAction,
			Weighting = 20,
			tactics = "Ag,Pa",
		},
		{
			Type = PickNewTarget,
			Weighting = 10,
			tactics = "Ag,Pa",
		},
		{
			Type = PickNewTarget,
			Weighting = 20,
                        tactics = "Ev",
		},
		{
                        Type = MoveRoundTarget,
			minParam = DegToRad(-75),
			maxParam = DegToRad(75),
			heatCost = 5,
 			heatThresh = 0,
                        tactics = "Ev",
                        Weighting = 10,
                },
		{
			Type = InterpolateTarget,
			minParam = 3,
			maxParam = 6,
			heatCost = 5,
 			heatThresh = 0,
			tactics = "Ev",
			Weighting = 10,
		},		{
			Type = InterpolateTarget,
			minParam = 1,
			maxParam = 3,
			heatCost = 10,
 			heatThresh = 0,
			tactics = "Ag",
			Weighting = 10,
		},

         },
}