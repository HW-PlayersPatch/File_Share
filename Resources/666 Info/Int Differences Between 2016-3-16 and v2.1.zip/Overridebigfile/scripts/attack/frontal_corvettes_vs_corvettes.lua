--===========================================================================
-- Tactics supported AttackStyle for formations
-- gbx_cole
--===========================================================================

function DegToRad(angle)
	return angle * ((2.0*3.141592653589)/360.0)
end

AttackStyleName = FaceTarget

Data = 
{

-- when approaching the target use this method to split the formation and transition in to the attack style
	howToBreakFormation = StraightAndScatter,
	

-- Once past this amount * the weapon range the ship will stop and face the target
	inRangeFactor		= 0.85,
	inRangeFactorAg		= 0.65,
	inRangeFactorEv		= 0.95,
    
-- once in range and facing the target we will slide around maintaining heading until we are more 
-- then this multiplied by our range from the target, then we will fly normally to catch up

        slideDistanceMultiplier = 1.5,

	tooSlowSpeed		= 3.0,
	tooFastMultiplier	= 1.4,
	facingAngle		= 0,
		
-- when doing a move attack we will break off if after we get further than this multipled by our max weapon range from the target.
	moveAttackMaxDistanceMultiplier = 1.2,
	
    	tryToMatchHeight = 0,
    	tryToGetAboveTarget = 0,
	
-- delays for the things the attack style can do (in seconds)
   	flyToTargetBecauseItsFarOutOfRangeDelay = 0.5,
    	flyToTargetBecauseItsMovingAwayDelay = 1.0,
    	stopAndFaceTheTargetDelay = 0.5,
    	flyToAboveTheTargetDelay = 1.0,

	safeDistanceFromTargetToDoActions = 600.0,
	safeDistanceFromTargetToDoActionsAg = 500.0,
	safeDistanceFromTargetToDoActionsEv = 800.0,
    
	budgetInit = 50,
	budgetRate = -10.0,

-- done at the end of every strafing run

	RandomActions = 
                {
                {
                	Type = PickNewTarget,
			budgetCost = -1.0,
                        Weighting = 10,
			heatCost = 10,
 			heatThresh = 0,
                },
                {
                        Type = NoAction,
                        Weighting = 50,
			budgetCost = -2.0,
                        tactics = "Ev"
                },
                {
                        Type = NoAction,
                        Weighting = 100,
			budgetCost = -1.0,
                        tactics = "Ag"
                },
		{
                        Type = MoveRoundTarget,
                        minParam = 3.1415926536*0.15,
                        maxParam = 6.2831853072*0.15,
                        Weighting = 10,
			budgetCost = 10.0,
                        tactics = "Ev"
                },
		{
			Type = MoveRoundTarget,
                        minParam = 3.1415926536*5,
                        maxParam = 6.2831853072*5,
			Weighting = 10,
			budgetCost = 10.0,
			heatCost = 15,
 			heatThresh = 0,
			tactics = "Ag"
		},
                },

                BeingAttackedActions =
                {
		{
			Type = PickNewTarget,
			Weighting = 9,
			heatCost = 10,
 			heatThresh = 0,
		},
		{
                        Type = NoAction,
                        Weighting = 5,
			budgetCost = -5.0,
                        tactics = "Ev"
                },
		{
			Type = MoveRoundTarget,
                        minParam = 3.1415926536*25,
                        maxParam = 6.2831853072*25,
			Weighting = 10,
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = MoveRoundTarget,
                        minParam = 3.1415926536*5,
                        maxParam = 6.2831853072*5,
			Weighting = 10,
			budgetCost = 10.0,
			heatCost = 15,
 			heatThresh = 0,
			tactics = "Ag"
		},
 
                },

                FiringActions =
                {
		{
                        Type = NoAction,
                        Weighting = 5,
			budgetCost = -5.0,
                        tactics = "Ev"
                },
		{
                        Type = NoAction,
                        Weighting = 10,
			budgetCost = -1.0,
                        tactics = "Ev"
                },
		{
			Type = InterpolateTarget,
			Weighting = 1,
			minParam = 0.25,
			maxParam = 0.75,
			budgetCost = 15.0,
			heatCost = 10,
 			heatThresh = 0,
			tactics = "Ag"
		},
		{
			Type = InterpolateTarget,
			Weighting = 1,
			minParam = 3,
			maxParam = 6,
			budgetCost = 10.0,
			tactics = "Ev"
		},

		{
			Type = MoveRoundTarget,
                        minParam = 3.1415926536*25,
                        maxParam = 6.2831853072*25,
                        Weighting = 2,
			budgetCost = 10.0,
                        tactics = "Ev"
                },
		{
			Type = MoveRoundTarget,
                        minParam = 3.1415926536*100,
                        maxParam = 6.2831853072*100,
                        Weighting = 2,
			budgetCost = 10.0,
                        tactics = "Ev"
                },
		{
			Type = MoveRoundTarget,
                        minParam = 3.1415926536*300,
                        maxParam = 6.2831853072*300,
                        Weighting = 2,
			budgetCost = 10.0,
                        tactics = "Ev"
                },
		{
			Type = NoAction,
			Weighting = 40,
			budgetCost = -1.0,
			tactics = "Ag"
		},
		{
			Type = NoAction,
			Weighting = 20,
			budgetCost = -5.0,
			tactics = "Ev"
		},
		{
			Type = PickNewTarget,
			Weighting = 20,
			budgetCost = -1.0,
			tactics = "Ag"
		},
		{
			Type = FlightManeuver,
			Weighting = 10,
			budgetCost = 5.0,
			FlightManeuverName = "RollCCW_Evasive_Static",
			heatCost = 5,
 			heatThresh = 0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 10,
			budgetCost = 5.0,
			FlightManeuverName = "RollCCW_Evasive_Static",
			heatCost = 5,
 			heatThresh = 0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 8,
			budgetCost = 5.0,
			FlightManeuverName = "DodgeRoll_Right_Static_Evasive",
			heatCost = 5,
 			heatThresh = 0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 8,
			budgetCost = 5.0,
			FlightManeuverName = "DodgeRoll_Left_Static_Evasive",
			heatCost = 5,
 			heatThresh = 0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 8,
			budgetCost = 5.0,
			FlightManeuverName = "Dodge_Evasive_Static",
			heatCost = 2,
 			heatThresh = 0,
			tactics = "Ev"
		},
         },
}