--===========================================================================
-- Tactics supported AttackStyle for formations
-- gbx_cole
--===========================================================================

AttackStyleName = AttackRun

Data = 
{
	-- when approaching the target use this method to split the formation and transition in to the attack style
	howToBreakFormation = StraightAndScatter,
	
	-- Maximum distance to get from the target when breaking away.

	maxBreakDistance = 1600.0,
	maxBreakDistanceAg = {1660.0,1500,1},
	maxBreakDistanceEv = {1700.0,1800,1},

	-- break off the attack run when this distance from the target
	distanceFromTargetToBreak = 350.0,
	distanceFromTargetToBreakAg = {250.0,500,1},
	distanceFromTargetToBreakEv = {700.0,800,1},


	safeDistanceFromTargetToDoActions = 600.0,
	safeDistanceFromTargetToDoActionsAg = 500.0,
	safeDistanceFromTargetToDoActionsEv = 800.0,

	attackEngineMult = 1,
	attackEngineMultAg = 0.9,
	attackEngineMultEv = 1.05,

	breakEngineMult = 1,
	breakEngineMultAg = 1.02,
	breakEngineMultEv = 1.05,

	-- data for picking the position in space to fly to when we break off the attack run
	-- how to orient the choice of break point, options are Attacker,Target and TargetAttackPoint
	coordSysToUse = Attacker,
	horizontalMin = 0.6,
	horizontalMax = 0.9,
	horizontalFlip = 1,
	verticalMin = 0.2,
	verticalMax = 0.2,
	verticalFlip = 1,

	budgetInit = 150,
	budgetRate = -5.0,

	--	Make sure strike group members face their flight direction while following the leader rather than face their target as the follow
	strikeGroupFaceFlightDir  = 1,

	-- done while flying towards target	
	RandomActions = 
	{
		{
			Type = PickNewTarget,
			budgetCost = -5.0,
			Weighting = 1,
		},
		{
			Type = PickNewTarget,
			Weighting = 5,
			budgetCost = -5.0,
			tactics = "Ev"
		},
		{
			Type = NoAction,
			Weighting = 30,
			budgetCost = -2.0,
			tactics = "Ag,Pa"
		},
		{
			Type = NoAction,
			Weighting = 10,
			budgetCost = -2.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 1,
			FlightManeuverName = "Serpentine_Evasive",
			budgetCost = 20.0,
			tactics = "Ev"
		},

	},
	BeingAttackedActions = 
	{
		{
			Type = NoAction,
			Weighting = 25,
			budgetCost = -10.0,
			tactics = "Ag,Pa"
		},
		{
			Type = PickNewTarget,
			Weighting = 9,
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "WingWaggle_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"

		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "JinkLeft_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"

		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "JinkLeftAndBack_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "JinkRight_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "JinkRightAndBack_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "RollCW_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "RollCCW_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 10,
			FlightManeuverName = "Dodge_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 10,
			FlightManeuverName = "Dodge_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "Serpentine_Evasive",
			budgetCost = 20.0,
			tactics = "Ev"

		},
	},
	FiringActions = 
	{
		{
			Type = NoAction,
			Weighting = 25,
			budgetCost = -10.0,
			tactics = "Ag,Pa"
		},
		{
			Type = NoAction,
			Weighting = 5,
			budgetCost = -50.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 10,
			FlightManeuverName = "Dodge_Evasive",
			budgetCost = -5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 10,
			FlightManeuverName = "Dodge_Evasive",
			budgetCost = -5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "JinkLeft_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "JinkLeftAndBack_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "JinkRight_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "JinkRightAndBack_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "RollCW_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "RollCCW_Evasive",
			budgetCost = 5.0,
			tactics = "Ev"
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "Serpentine_Evasive",
			budgetCost = 20.0,
			tactics = "Ev"

		},
	},
}