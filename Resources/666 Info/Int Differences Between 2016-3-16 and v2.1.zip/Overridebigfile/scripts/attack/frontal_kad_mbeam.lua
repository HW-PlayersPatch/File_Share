--===========================================================================
--  Purpose : Lua definition file for the homeworld .
--            -contains frontal attack data
--
--  Copyright Relic Entertainment, Inc.  All rights reserved.
--===========================================================================

function DegToRad(angle)
	return angle * ((2.0*3.141592653589)/360.0)
end

AttackStyleName = FaceTarget

Data = 
{
	-- when approaching the target use this method to split the formation and transition in to the attack style
	howToBreakFormation = StraightAndScatter,
	
	--	Once past this amount * the weapon range the ship will stop and face the target
	inRangeFactor		= 0.95,
    -- once in range and facing the target we will slide around maintaining heading until we are more 
    -- then this multiplied by our range from the target, then we will fly normally to catch up
    slideDistanceMultiplier = 1.5,

	tooSlowSpeed		= 3.0,
	tooFastMultiplier	= 1.4,
	facingAngle			= 0,

	-- when doing a move attack we will break off if after we get further than this multiplied by our max weapon range from the target.
	moveAttackMaxDistanceMultiplier = 1.2,
	
    tryToMatchHeight = 0,
	
	safeDistanceFromTargetToDoActions = 1000.0,
	useTargetUp = 0,
    
	tryToGetAboveTarget = 0,
	
	-- delays for the things the attack style can do (in seconds)
    flyToTargetBecauseItsFarOutOfRangeDelay = 0,
    flyToTargetBecauseItsMovingAwayDelay = 1.0,
    stopAndFaceTheTargetDelay = 1.0,
    flyToAboveTheTargetDelay = 2.0,
    
	-- done at the end of every strafing run
	RandomActions = 
	{
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "HalfRollCW",
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "HalfRollCW",
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "HalfRollCW",
		},
	},
	BeingAttackedActions = 
	{
	},
	FiringActions = 
	{
		{
			Type = InterpolateTarget,
			Weighting = 4,
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "HalfRollCW",
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "HalfRollCW",
		},
		{
			Type = FlightManeuver,
			Weighting = 5,
			FlightManeuverName = "HalfRollCW",
		},
	},
}
