paradeSlot("Tai_Scout",							{-700, -50, 2000},	{0,0,1},	{-1,0,0},	70);
paradeSlot("Tai_Interceptor",				{-700, -50, 1800},	{0,0,1},	{-1,0,0},	70);
paradeSlot("Tai_AttackBomber",			{-700, -50, 1600},	{0,0,1},	{-1,0,0},	70);
paradeSlot("tai_defender",					{-700, -50, 1400},	{0,0,1},	{-1,0,0},	70);
paradeSlot("tai_defensefighter",		{-700, -50, 1200},	{0,0,1},	{-1,0,0},	70);

paradeSlot("Tai_LightCorvette",			{-700, -250, 2000},	{0,0,1},	{-1,0,0},	105);
paradeSlot("Tai_HeavyCorvette",			{-700, -250, 1800},	{0,0,1},	{-1,0,0},	105);
paradeSlot("Tai_RepairCorvette",		{-700, -250, 1600},	{0,0,1},	{-1,0,0},	123);
paradeSlot("Tai_SalvageCorvette",		{-700, -250, 1400},	{0,0,1},	{-1,0,0},	123);
paradeSlot("Tai_MultiGunCorvette",	{-700, -250, 1200},	{0,0,1},	{-1,0,0},	105);
paradeSlot("Tai_MinelayerCorvette",	{-700, -250, 1000},	{0,0,1},	{-1,0,0},	105);

paradeSlot("Tai_AssaultFrigate",		{-700, -525, 2000},	{0,0,1},	{-1,0,0},	350);
paradeSlot("Tai_IonCannonFrigate",	{-700, -525, 1700},	{0,0,1},	{-1,0,0},	350);
paradeSlot("tai_supportfrigate",		{-700, -525, 1400},	{0,0,1},	{-1,0,0},	350);
paradeSlot("tai_fieldfrigate",			{-700, -525, 1100},	{0,0,1},	{-1,0,0},	350);

paradeSlot("Tai_ResourceCollector",	{-2100, -300, -200},{0,0,1},	{-1,0,0},	210);
paradeSlot("Tai_ResourceController",{-2100, -350, -600},{0,0,1},	{-1,0,0},	455);

paradeSlot("Tai_Destroyer",					{700, 150, 1700},		{0,0,1},	{1,0,0},	525);
paradeSlot("tai_MissileDestroyer",	{700, -250, 1700},	{0,0,1},	{1,0,0},	525);
paradeSlot("Tai_HeavyCruiser",			{700, -600, 1700},	{0,0,1},	{1,0,0},	700);
paradeSlot("Tai_Carrier",						{100, -550, 1700},		{0,0,1},	{0,-1,0},	770);

paradeSlot("Tai_ResearchShip",			{-400, -250, -1200},{0,0,1},	{-1,0,0},	350);
paradeSlot("Tai_sensorarray",				{400, -250, -1200}, {0,0,1},  {1,0,0},	350);
paradeSlot("Tai_cloakgenerator",		{-400, -250, -1600},{0,0,1},  {-1,0,0},	350);
paradeSlot("Tai_GravWellGenerator",	{400, -250, -1600},	{0,0,1},	{1,0,0},	350);

paradeSlot("misc",									{2100, 350, -600},	{0,0,1},	{1,0,0},	525); 
