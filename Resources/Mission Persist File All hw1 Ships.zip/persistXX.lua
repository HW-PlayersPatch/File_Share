PersistantData = {
  Research = {
    [1] = {
      name = "FighterDrive",
      progress = 1,
    },
    [2] = {
      name = "FighterChassis",
      progress = 1,
    },
    [3] = {
      name = "CorvetteDrive",
      progress = 1,
    },
    [4] = {
      name = "CorvetteChassis",
      progress = 1,
    },
    [5] = {
      name = "HeavyCorvetteUpgrade",
      progress = 1,
    },
    [6] = {
      name = "CapitalShipDrive",
      progress = 1,
    },
    [7] = {
      name = "CapitalShipChassis",
      progress = 1,
    },
    [8] = {
      name = "IonCannons",
      progress = 1,
    },
    [9] = {
      name = "PlasmaBombLauncher",
      progress = 1,
    },
    [10] = {
      name = "DefenderSubSystems",
      progress = 1,
    },
    [11] = {
      name = "SuperCapitalShipDrive",
      progress = 1,
    },
    [12] = {
      name = "DroneTechnology",
      progress = 1,
    },
    [13] = {
      name = "FastTrackingTurrets",
      progress = 1,
    },
    [14] = {
      name = "GuidedMissiles",
      progress = 1,
    },
    [15] = {
      name = "SuperHeavyChassis",
      progress = 1,
    },
    [16] = {
      name = "GravityGenerator",
      progress = 1,
    },
    [17] = {
      name = "ProximitySensor",
      progress = 1,
    },
    [18] = {
      name = "MinelayingTech",
      progress = 1,
    },
    [19] = {
      name = "CloakedFighter",
      progress = 1,
    },
    [20] = {
      name = "HeavyGuns",
      progress = 1,
    },
    [21] = {
      name = "CloakGenerator",
      progress = 1,
    },
    [22] = {
      name = "SensorArray",
      progress = 1,
    },
  },
  TeamColours = {
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Red.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Tri.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Red.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Tri.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Kushan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Kushan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.17647,
        1,
        0.58431,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.17647,
        1,
        0.58431,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.50196,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.50196,
        0,
      },
      stripeColour = {
        1,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
  },
  Squadrons = {
    {
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates0",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates1",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates2",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates3",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_Carrier",
      subsystems = {
        {
          index = 0,
          name = "TAI_CARRIERENGINE",
        },
        {
          index = 0,
          name = "TAI_CARRIERRESOURCE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "EliteCarrier0",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates4",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates5",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates6",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates7",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates8",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates9",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates10",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates11",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates12",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates13",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates14",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates15",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates16",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates17",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates18",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON",
        },
        {
          index = 0,
          name = "TAI_ASSAULTCANNON2",
        },
      },
      stance = 2,
      name = "CapturedFrigates19",
      teamColourHandle = 339,
      hotkey = 0,
    },	
	{
      tactic = 2,
      type = "Tai_Carrier",
      subsystems = {
        {
          index = 0,
          name = "TAI_CARRIERENGINE",
        },
        {
          index = 0,
          name = "TAI_CARRIERRESOURCE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "EliteCarrier1",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_ResourceController",
      stance = 2,
      name = "",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_ResourceController",
      stance = 2,
      name = "",
      teamColourHandle = 341,
      hotkey = 0,
    },	
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates0",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates1",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates2",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates3",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates4",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates5",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates6",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates7",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates8",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates9",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates10",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 1,
      type = "Tai_FieldFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 1,
      type = "Tai_FieldFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 1,
      type = "Tai_FieldFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 1,
      type = "Tai_FieldFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 1,
      type = "Tai_FieldFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_Carrier",
      subsystems = {
        {
          index = 0,
          name = "TAI_CARRIERENGINE",
        },
        {
          index = 0,
          name = "TAI_CARRIERRESOURCE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "EliteCarrier2",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_SupportFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedSupportFrigates11",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates0",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates1",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates2",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates3",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates4",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates5",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates6",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates7",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates8",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates9",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates10",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates11",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates12",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates13",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates14",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates15",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates16",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates17",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates18",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_IonCannonFrigate",
      stance = 2,
      name = "CapturedIonCannonFrigates19",
      teamColourHandle = 339,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_Carrier",
      subsystems = {
        {
          index = 0,
          name = "TAI_CARRIERENGINE",
        },
        {
          index = 0,
          name = "TAI_CARRIERRESOURCE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "EliteCarrier3",
      teamColourHandle = 341,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Tur_IonArrayFrigate",
      stance = 0,
      name = "CapturedIonArray0",
      teamColourHandle = 340,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tur_IonArrayFrigate",
      stance = 0,
      name = "CapturedIonArray1",
      teamColourHandle = 340,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tur_IonArrayFrigate",
      stance = 0,
      name = "CapturedIonArray2",
      teamColourHandle = 340,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tur_IonArrayFrigate",
      stance = 0,
      name = "CapturedIonArray3",
      teamColourHandle = 340,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tur_IonArrayFrigate",
      stance = 0,
      name = "CapturedIonArray4",
      teamColourHandle = 340,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tur_IonArrayFrigate",
      stance = 0,
      name = "CapturedIonArray5",
      teamColourHandle = 340,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam0",
      teamColourHandle = 342,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam1",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam3",
      teamColourHandle = 342,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam4",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam5",
      teamColourHandle = 342,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam6",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam7",
      teamColourHandle = 342,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam8",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam9",
      teamColourHandle = 342,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam10",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam11",
      teamColourHandle = 342,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam12",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam13",
      teamColourHandle = 342,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam14",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam15",
      teamColourHandle = 342,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam16",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam17",
      teamColourHandle = 342,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam18",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kad_MultiBeamFrigate",
      stance = 0,
      name = "CapturedMultiBeam19",
      teamColourHandle = 342,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer0",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer1",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer2",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer3",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer4",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer5",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer6",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer7",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer8",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer9",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer10",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "TAI_DESTROYER",
      subsystems = {
        {
          index = 0,
          name = "TAI_DESTROYERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedDestroyer11",
      teamColourHandle = 341,
      hotkey = 0,
    },	
    {
      tactic = 2,
      type = "Tai_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "TAI_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "CapturedMissileDestroyer0",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "TAI_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "CapturedMissileDestroyer1",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "TAI_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "CapturedMissileDestroyer2",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "TAI_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "CapturedMissileDestroyer3",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "TAI_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "CapturedMissileDestroyer4",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "TAI_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "CapturedMissileDestroyer5",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "TAI_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "CapturedMissileDestroyer6",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "TAI_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "CapturedMissileDestroyer7",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser0",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser1",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser2",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser3",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser4",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser5",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser6",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser7",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser8",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "TAI_HEAVYCRUISERENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "CapturedHeavyCruiser9",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_GravWellGenerator",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 341,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_GravWellGenerator",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 341,
      hotkey = 0,
    },	
    {
      tactic = 2,
      type = "Kus_Mothership",
      subsystems = {
        {
          index = 0,
          name = "KUS_MOTHERSHIPENGINE",
        },
        {
          index = 0,
          name = "KUS_MOTHERSHIPRESOURCE",
        },
      },
      stance = 2,
      shiphold = {
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 67110912,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 67110912,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 67110912,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 67110912,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 67110912,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 67110912,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_AttackBomber",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Interceptor",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 67109888,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 67109888,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 67109888,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 67109888,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 67109888,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 67109888,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_CloakedFighter",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
        {
          index = 0,
          type = "Kus_ResearchShip",
          stance = 2,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_ResourceCollector",
          stance = 2,
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_ResourceCollector",
          stance = 2,
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Tai_ResourceCollector",
          hotkey = 0,
          teamColourHandle = 341,
          size = 1,
          tactic = 2,
        },{
          index = 0,
          type = "Tai_ResourceCollector",
          hotkey = 0,
          teamColourHandle = 341,
          size = 1,
          tactic = 2,
        },{
          index = 0,
          type = "Tai_ResourceCollector",
          hotkey = 0,
          teamColourHandle = 341,
          size = 1,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_MultiGunCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_HeavyCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_MinelayerCorvette",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Defender",
          stance = 0,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_ProximitySensor",
          stance = 2,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_ProximitySensor",
          stance = 2,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Probe",
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Probe",
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Probe",
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
		{
          index = 0,
          type = "Kus_Probe",
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 0,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
		{
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
      },
      name = "NIS_Squad",
      teamColourHandle = 0,
      buildjobs = {
        [0] = {
          [0] = {
            name = "Kus_MissileDestroyer",
            rusSpent = 0,
          },
        },
      },
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108896,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },
    {
      tactic = 2,
      type = "Kus_ResourceController",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 64,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67109376,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108928,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67109376,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108928,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67109376,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108928,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67109376,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108928,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108928,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67109376,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108928,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67109376,
    },
	{
      tactic = 2,
      type = "Kus_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_AssaultFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
        {
          index = 0,
          name = "KUS_ASSAULTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kus_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION1",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION2",
        },
        {
          index = 0,
          name = "KUS_DESTROYERENGINE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 2,
      type = "Kus_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION1",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION2",
        },
        {
          index = 0,
          name = "KUS_DESTROYERENGINE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 2,
      type = "Kus_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION1",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION2",
        },
        {
          index = 0,
          name = "KUS_DESTROYERENGINE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
	{
      tactic = 2,
      type = "Kus_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION1",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION2",
        },
        {
          index = 0,
          name = "KUS_DESTROYERENGINE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
	{
      tactic = 2,
      type = "Kus_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION1",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION2",
        },
        {
          index = 0,
          name = "KUS_DESTROYERENGINE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
	{
      tactic = 2,
      type = "Kus_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION1",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION2",
        },
        {
          index = 0,
          name = "KUS_DESTROYERENGINE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108896,
    },
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108896,
    },
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108896,
    },
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 67108896,
    },
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 32,
    },
    {
      tactic = 2,
      type = "Kus_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
	{
      tactic = 2,
      type = "Kus_MissileDestroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_MISSILEDESTROYERENGINE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
	{
      tactic = 2,
      type = "Kus_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "KUS_CRUISERION",
        },
        {
          index = 0,
          name = "KUS_CRUISERION",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN1",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN2",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN1",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN2",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN3",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN3",
        },
        {
          index = 0,
          name = "KUS_HEAVYCRUISERENGINE",
        },
      },
      stance = 0,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "KUS_CRUISERION",
        },
        {
          index = 0,
          name = "KUS_CRUISERION",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN1",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN2",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN1",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN2",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN3",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN3",
        },
        {
          index = 0,
          name = "KUS_HEAVYCRUISERENGINE",
        },
      },
      stance = 0,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_HeavyCruiser",
      subsystems = {
        {
          index = 0,
          name = "KUS_CRUISERION",
        },
        {
          index = 0,
          name = "KUS_CRUISERION",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN1",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN2",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN1",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN2",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN3",
        },
        {
          index = 0,
          name = "KUS_CRUISERGUN3",
        },
        {
          index = 0,
          name = "KUS_HEAVYCRUISERENGINE",
        },
      },
      stance = 0,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_Carrier",
      subsystems = {
        {
          index = 0,
          name = "KUS_CARRIERENGINE",
        },
        {
          index = 0,
          name = "KUS_CARRIERRESOURCE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_Carrier",
      subsystems = {
        {
          index = 0,
          name = "KUS_CARRIERENGINE",
        },
        {
          index = 0,
          name = "KUS_CARRIERRESOURCE",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_GravWellGenerator",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kus_GravWellGenerator",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_CloakGenerator",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_CloakGenerator",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_SensorArray",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Tai_Mothership",
      subsystems = {
        {
          index = 0,
          name = "TAI_MOTHERSHIPENGINE",
        },
        {
          index = 0,
          name = "TAI_MOTHERSHIPRESOURCE",
        },
      },
      stance = 2,
      shiphold = {        
      },
      name = "Tai_Mother",
      teamColourHandle = 339,
      hotkey = 0,
    },
  },
  PendingResearch = {
  },
  RUs = 50946,
}
