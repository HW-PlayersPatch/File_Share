--Kushan

supplyLimit("Research", 6);
supplyLimit("Frigate", 39);
supplyLimit("Carrier", 4);

supplyDesc("Battlecruiser", "HeavyCruiser");
