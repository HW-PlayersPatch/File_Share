--Kushan

supplyLimit("Research", 6);
supplyLimit("Frigate", 24);
supplyLimit("Carrier", 3);

supplyDesc("Battlecruiser", "HeavyCruiser");
