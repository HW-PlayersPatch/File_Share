--Kushan

supplyLimit("Research", 6);
supplyLimit("Frigate", 14);
supplyLimit("Carrier", 2);
supplyLimit("Capital", 11);

supplyDesc("Battlecruiser", "HeavyCruiser");
