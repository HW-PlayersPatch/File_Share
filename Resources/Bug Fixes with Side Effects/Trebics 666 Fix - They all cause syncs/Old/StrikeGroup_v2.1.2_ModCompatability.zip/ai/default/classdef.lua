
function addClassType(Class, ClassName)
  local ClassTag = rawget(globals(), Class)

  if (not ClassTag) then
    sg_maxClasses = sg_maxClasses + 1
    ClassTag = sg_maxClasses

    rawset(globals(), Class, ClassTag)
  end

  if (ClassName) then AddClassName(ClassTag, ClassName) end
end

function addSquadClass(Class, ShipTable)
  local ClassTag = rawget(globals(), Class)

  if (not ClassTag) then
    addClassType(Class)
    ClassTag = rawget(globals(), Class)
  end

  for key,val in ShipTable do
    if (val) then AddToClass(val, ClassTag) end
  end
end


function ClassInitialize()
  AddClassName(eMotherShip, "Motherships")
	AddClassName(eCollector, "Collectors")
	AddClassName(eDropOff, "DropOffs")
	AddClassName(eFighter, "Fighters")
	AddClassName(eFrigate, "Frigates")
	AddClassName(eCorvette, "Corvettes")
	AddClassName(eCapital, "Capital")
	AddClassName(eAntiFighter, "AntiFighter")
	AddClassName(eAntiCorvette, "AntiCorvette")
	AddClassName(eAntiFrigate, "AntiFrigate")
	AddClassName(ePlatform, "Platform")
	AddClassName(eRefinery, "Refinery")
	AddClassName(eHyperspaceGate, "HypGates")
	AddClassName(eShield, "Shields")
	AddClassName(eCapture, "Capture")
	AddClassName(eSubSystemAttackers, "SubSysKillas")

  sg_maxClasses = eMaxCount
  eUselessShips = eMaxCount

  doscanpath("DATA:AI\\Default\\ClassDef", "*.lua")
end
