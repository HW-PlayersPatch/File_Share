function oninit()
  dofilepath(SelfRace_GetString("path_ai", ""))

  if (InitAI) then InitAI(); return end

  dofilepath("DATA:AI\\Default\\Original.lua")
  DefaultAI_Init()
end
