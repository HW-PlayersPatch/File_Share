-- Variables
l_TargetFix__ProximityToScan = 200
l_TargetFix__JoinStrikeGroupDelay = 2

l_TargetFix__Prefix = "l_TargetFix"
l_TargetFix__Storage = { Ships = { nil }}
l_TargetFix__Interval = 0.25
l_TargetFix__ScriptFlag = 17 ^ 2
-- --- --

function addTargetFix(ShipType, UniqueDetails)
  ShipType = strlower(ShipType)
  UniqueDetails = UniqueDetials or { nil }

  l_TargetFix__Storage.Ships[ShipType]=
  {
    ProximityToScan = UniqueDetails.ProximityToScan or l_TargetFix__ProximityToScan,
    JoinStrikeGroupDelay = UniqueDetails.JoinStrikeGroupDelay or l_TargetFix__JoinStrikeGroupDelay,
  }
end

function TargetFix()
  if (Rule_Exists("TargetFix_RULE")~= 1) then
    doscanpath("DATA:Scripts\\SCaR\\TargetFix", "*.lua")

    SobGroup_CreateIfNotExist("Player_Ships")
    SobGroup_CreateIfNotExist("Player_Avoid")
    SobGroup_CreateIfNotExist("StrikeGroup")
    SobGroup_CreateIfNotExist("StrikeTargets")
    SobGroup_CreateIfNotExist("SetScriptFlags")
    SobGroup_CreateIfNotExist("ProxyShips")

    for player = 0, Universe_PlayerCount()- 1 do
      l_TargetFix__Storage[player + 1]= {Count = 0; nil}
    end

    Rule_AddInterval("TargetFix_RULE", l_TargetFix__Interval)
  end
end

function TargetFix_RULE()
  for player = 0, Universe_PlayerCount()- 1 do
    TargetFix_SetScriptFlags(player)

    SobGroup_Copy("Player_Ships", "Player_Ships"..player)
    SobGroup_Clear("Player_Avoid")

    while (SobGroup_Empty("Player_Ships")~= 1) do
      SobGroup_FillShipsByIndexRange("StrikeGroup", "Player_Ships", 0, 1)
      SobGroup_SobGroupAdd("Player_Avoid", "StrikeGroup")

      if (SobGroup_CountByScriptFlag("StrikeGroup", l_TargetFix__ScriptFlag) > 0) then
        local SobName,ShipID = TargetFix_GetShipID("StrikeGroup")
        local InStrikeGroup = SobGroup_InStrikeGroup("StrikeGroup")

        l_TargetFix__Storage[player + 1][ShipID].Parent = nil
        l_TargetFix__Storage[player + 1][ShipID].Potential = { nil }

        SobGroup_GetCommandTargets("StrikeTargets", SobName, COMMAND_Attack)

        if (InStrikeGroup ~= 1 or SobGroup_Empty("StrikeTargets")== 1) then
          SobGroup_Clear(SobName.."PRIMARY")
          SobGroup_Clear(SobName.."TARGETS")

        else
          if (SobGroup_Equal(SobName.."PRIMARY", "StrikeTargets")~= 1) then
            if (SobGroup_IsAlive(SobName.."PRIMARY")== 1 or SobGroup_IsAlive(SobName.."TARGETS")~= 1) then
              SobGroup_Copy(SobName.."TARGETS", "StrikeTargets")
            end

            TargetFix_GetPrimaryTarget(SobName)
          end

          TargetFix_ScanProximity(SobName)
          SobGroup_Attack(player, "StrikeGroup", SobName.."PRIMARY")
        end
      end

      SobGroup_FillSubstract("Player_Ships", "Player_Ships", "Player_Avoid")
    end
  end
end

function TargetFix_SetScriptFlags(player)
  for ShipType,ShipDetails in l_TargetFix__Storage.Ships do
    SobGroup_FillShipsByType("SetScriptFlags", "Player_Ships"..player, ShipType)

    if (SobGroup_Empty("SetScriptFlags")~= 1) then
      SobGroup_SetScriptFlag("SetScriptFlags", l_TargetFix__ScriptFlag)
    end
  end
end

function TargetFix_GetPrimaryTarget(SobName)
  SobGroup_CreateIfNotExist("temp0"); SobGroup_CreateIfNotExist("temp1")
  SobGroup_CreateIfNotExist("temp2"); SobGroup_Clear("temp2")

  SobGroup_Copy("temp0", SobName.."TARGETS")

  while (SobGroup_Empty("temp0")~= 1) do
    SobGroup_FillShipsByIndexRange("temp1", "temp0", 0, 1)

    if (SobGroup_HealthPercentage("temp1") > 0) then
      SobGroup_SobGroupAdd("temp2", "temp1")
    end

    SobGroup_FillSubstract("temp0", "temp0", "temp1")
  end

  if (SobGroup_Count("temp2") > 0) then
    local rand = nrandom(0, SobGroup_Count("temp2")- 1)
    SobGroup_FillShipsByIndexRange(SobName.."PRIMARY", "temp2", rand, 1)
  end

  -- --- --
  dofilepath("PLAYER:PLAYERCFG.lua")

  if (Options.GameplayOptions.enableMilitary ~= 1) then
    SobGroup_Copy(SobName.."TARGETS", SobName.."PRIMARY")
  end
end

function TargetFix_GetShipID(SobName)
  local player = SobGroup_OwnedBy(SobName)
  local ShipID,Limit = -1, l_TargetFix__Storage[player + 1].Count or 0

  if (Limit > 0) then
    for l = 1, Limit do
      local SName = l_TargetFix__Prefix..player.."_"..l

      if (SobGroup_Empty(SName)== 1) then ShipID = l end
      if (SobGroup_GroupInGroup(SName, SobName)== 1) then ShipID = l; break end
    end
  end
  if (ShipID == -1) then
    l_TargetFix__Storage[player + 1].Count = Limit + 1
    ShipID = l_TargetFix__Storage[player + 1].Count

    SobGroup_CreateIfNotExist(l_TargetFix__Prefix..player.."_"..ShipID)
  end

  local SName = l_TargetFix__Prefix..player.."_"..ShipID

  if (SobGroup_GroupInGroup(SName, SobName)~= 1) then
    SobGroup_CreateIfNotExist(SName.."PRIMARY"); SobGroup_Clear(SName.."PRIMARY")
    SobGroup_CreateIfNotExist(SName.."TARGETS"); SobGroup_Clear(SName.."PRIMARY")
    SobGroup_Copy(SName, SobName)

    l_TargetFix__Storage[player + 1][ShipID]= {Parent = nil, Potential = { nil }}
  end

  return SName, ShipID
end

function TargetFix_ScanProximity(ProxyName, ParentName, Depth)
  ParentName = ParentName or ProxyName
  Depth = Depth or 0

  local player,ShipType = SobGroup_OwnedBy(ProxyName), strlower(SobGroup_GetShipType(ProxyName))

  SobGroup_CreateIfNotExist("ProxyShips"..Depth)
  SobGroup_FillProximitySobGroup("ProxyShips"..Depth, "Player_Ships"..player, ProxyName, l_TargetFix__Storage.Ships[ShipType].ProximityToScan)
  SobGroup_FillSubstract("ProxyShips"..Depth, "ProxyShips"..Depth, "Player_Avoid")
  SobGroup_SobGroupAdd("Player_Avoid", "ProxyShips"..Depth)

  while (SobGroup_Empty("ProxyShips"..Depth)~= 1) do
    SobGroup_FillShipsByIndexRange("ProxyShips", "ProxyShips"..Depth, 0, 1)

    if (SobGroup_CountByScriptFlag("ProxyShips", l_TargetFix__ScriptFlag) > 0) then
      if (SobGroup_InStrikeGroup("ProxyShips")== 1) then
        local SobName,ShipID = TargetFix_GetShipID("ProxyShips")

        if (l_TargetFix__Storage[player + 1][ShipID].Parent == ParentGroup) then
          SobGroup_SobGroupAdd("StrikeGroup", "ProxyShips")
          SobGroup_Copy(SobName.."PRIMARY", ParentName.."PRIMARY")
          SobGroup_Copy(SobName.."TARGETS", ParentName.."TARGETS")

          l_TargetFix__Storage[player + 1][ShipID].Potential = { nil }

          TargetFix_ScanProximity(SobName, ParentName, (Depth + 1))
        end
        if (l_TargetFix__Storage[player + 1][ShipID].Parent ~= ParentGroup) then
          local ShipType = strlower(SobGroup_GetShipType(SobName))
          local JoinDelay = (1 / l_TargetFix__Interval) * l_TargetFix__Storage.Ships[ShipType].JoinStrikeGroupDelay

          l_TargetFix__Storage[player + 1][ShipID].Potential[ParentName]= l_TargetFix__Storage[player + 1][ShipID].Potential[ParentName] or 0
          l_TargetFix__Storage[player + 1][ShipID].Potential[ParentName]= l_TargetFix__Storage[player + 1][ShipID].Potential[ParentName] + 1

          if (l_TargetFix__Storage[player + 1][ShipID].Potential[ParentName] >= JoinDelay) then
            l_TargetFix__Storage[player + 1][ShipID].Parent = ParentName
          end
        end
      end
    end

    SobGroup_FillSubstract("ProxyShips"..Depth, "ProxyShips"..Depth, "ProxyShips")
  end
end


-- --EXTRA FUNCTIONS-- --

if (not SobGroup_Equal) then
  function SobGroup_Equal(sGroupA, sGroupB, Diff)  Diff = Diff or 0
    SobGroup_CreateIfNotExist("SobGroup_Equal")
    SobGroup_FillCompare("SobGroup_Equal", sGroupA, sGroupB)

    Diff = Diff -(SobGroup_Count(sGroupA)- SobGroup_Count("SobGroup_Equal"))
    Diff = Diff -(SobGroup_Count(sGroupB)- SobGroup_Count("SobGroup_Equal"))

    if (Diff >= 0) then return 1 end
  end
end

if (not SobGroup_IsAlive) then
  function SobGroup_IsAlive(sGroup)
    if (SobGroup_HealthPercentage(sGroup) > 0) then return 1 end
  end
end

if (not nrandom) then
  RandomSeed = { 763261, 214013, 2531011, 4294967296 }

  function nrandom(fVal1, fVal2)
    RandomSeed[1] = mod(RandomSeed[1] * RandomSeed[2] + RandomSeed[3], RandomSeed[4])
    RandomTemp = RandomSeed[1] / (RandomSeed[4] - 1)

    if (fVal2) then return floor(fVal1 + 0.5 + RandomTemp * (fVal2 - fVal1)) end
    if (fVal1) then return floor(RandomTemp * fVal1) + 1 end

    return RandomTemp
  end
end

if (not old__SobGroup_HealthPercentage and globals) then
  old__SobGroup_HealthPercentage = SobGroup_HealthPercentage
  rawset(globals(), "SobGroup_HealthPercentage",
    function (SobGroup)
      local SobHealth = old__SobGroup_HealthPercentage(SobGroup)

      if (not SobHealth or SobHealth < 0) then return 0 end
      if (SobHealth > 1) then return 1 end

      return SobHealth
    end
  )
end
