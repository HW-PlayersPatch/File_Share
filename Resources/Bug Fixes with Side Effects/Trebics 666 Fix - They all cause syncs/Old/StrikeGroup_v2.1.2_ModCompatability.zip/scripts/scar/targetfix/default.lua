--addTargetFix( "<ShipType>" ,<UniqueDetails> )
--  <UniqueDetails> is an optional table with current 2 keys
--    ProximityToScan       --The proximity to scan around this shiptype for strikegroup members (Default: 200)
--    JoinStrikeGroupDelay  --The delay in seconds before accepting to join a strikegroup (Default: 2)
--
-- Defaults can be changed in Scripts\SCaR\TargetFix.lua


--Hiigaran
addTargetFix("Hgn_Scout", { ProximityToScan = 200, JoinStrikeGroupDelay = 2 })
addTargetFix("Hgn_Interceptor", { ProximityToScan = 200 })
addTargetFix("Hgn_AttackBomber", { JoinStrikeGroupDelay = 2 })
addTargetFix("Hgn_AttackBomberElite", { JoinStrikeGroupDelay = 200, })

--Vaygr
addTargetFix("Vgr_Scout")
addTargetFix("Vgr_Interceptor")
addTargetFix("Vgr_Bomber")
addTargetFix("Vgr_LanceFighter")
addTargetFix("Vgr_LaserCorvette")

--Kushan
addTargetFix("Kus_Scout")
addTargetFix("Kus_Interceptor")
addTargetFix("Kus_CloakedFighter")
addTargetFix("Kus_AttackBomber")

--Taiidan
addTargetFix("Tai_Scout")
addTargetFix("Tai_Interceptor")
addTargetFix("Tai_AttackBomber")
