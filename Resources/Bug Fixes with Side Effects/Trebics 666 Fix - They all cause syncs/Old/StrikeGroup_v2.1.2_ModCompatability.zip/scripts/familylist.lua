function getn(kTable) local nCount = 0; for k,v in kTable do nCount = nCount + 1 end return nCount end

familyList = {}

function addToFamily(kFamilyName, kTable)
  local kFamily = familyList[kFamilyName] or {}
  local nCount = getn(kFamily)

  for k,v in kTable do
    nCount = nCount + 1
    kFamily[nCount]= v
  end

  local nCount,oTable = getn(kFamily), {}

  for index = 1, getn(kFamily) do
    local lKey,lVal = -1,-1

    for ak,av in kFamily do
      if ((lKey == -1 and lVal == -1) or (av.numParam and av.numParam < lVal)) then
        lVal = av.numParam
        lKey = ak
      end
    end

    oTable[index]= kFamily[lKey]
    kFamily[lKey]= nil
  end

  familyList[kFamilyName] = oTable

  if (kFamilyName == "buildFamily") then buildFamily = oTable end
  if (kFamilyName == "displayFamily") then displayFamily = oTable end
  if (kFamilyName == "attackFamily") then attackFamily = oTable end
  if (kFamilyName == "dockFamily") then dockFamily = oTable end
  if (kFamilyName == "avoidanceFamily") then avoidanceFamily = oTable end
  if (kFamilyName == "collisionFamily") then collisionFamily = oTable end
  if (kFamilyName == "collisionDamageFamily") then collisionDamageFamily = oTable end
  if (kFamilyName == "autoFormationFamily") then autoFormationFamily = oTable end
  if (kFamilyName == "armourFamily") then armourFamily = oTable end
  if (kFamilyName == "unitcapsFamily") then unitcapsFamily = oTable end
end

doscanpath("Data:Scripts\\FamilyLists","*.lua")
