
addStyleSheet("HW2StyleSheet", "DATA:\\UI\\NewUI\\Styles\\HWRMStyles.lua")

addFrontEndScreens({
  { name = "Background",           filename = "DATA:\\UI\\NewUI\\Main\\Background.lua" },
	{ name = "NewMainMenu",          filename = "DATA:\\UI\\NewUI\\Main\\NewMainMenu.lua",               type = "MainMenu" },
	{ name = "UserProfile",          filename = "DATA:\\UI\\NewUI\\SinglePlayer\\SPUserProfile.lua",     type = "UserProfile" },
	{ name = "NewProfile",           filename = "DATA:\\UI\\NewUI\\SinglePlayer\\SPNewProfile.lua",      type = "NewProfile" },
	{ name = "MissionSelect",        filename = "DATA:\\UI\\NewUI\\Shared\\MissionSelect.lua",           type = "SPMissionSelect" },
	{ name = "PlayerSetup",          filename = "DATA:\\UI\\NewUI\\Shared\\PlayerSetup.lua",             type = "PlayerSetup" },
	{ name = "EmblemSelect",         filename = "DATA:\\UI\\NewUI\\Shared\\EmblemSelect.lua",            type = "EmblemSelect" },
	{ name = "LobbyScreen",          filename = "DATA:\\UI\\NewUI\\GameRoom.lua",                        type = "LobbyScreen" },
	{ name = "GameTypeInfo",         filename = "DATA:\\UI\\NewUI\\Shared\\GameTypeInfo.lua",            type = "GameTypeInfo" },
	{ name = "CreateGameScreen",     filename = "DATA:\\UI\\NewUI\\Multiplayer\\CreateGameScreen.lua",   type = "CreateGameScreen" },
	{ name = "LobbyTitleRoom",       filename = "DATA:\\UI\\NewUI\\ServerLobby.lua",                     type = "LobbyTitleRoom" },
--{ name = "PasswordScreen",       filename = "DATA:\\UI\\NewUI\\Shared\\PasswordScreen.lua" },
	{ name = "Stats",                filename = "DATA:\\UI\\NewUI\\Stats.lua",                           type = "Statistics" },
	{ name = "GameSetup",            filename = "DATA:\\UI\\NewUI\\Shared\\GameSetup.lua",               type = "GameSetup" },
	{ name = "DirectConnection",     filename = "DATA:\\UI\\NewUI\\Multiplayer\\DirectConnection.lua",   type = "DirectConnectionScreen" },
	{ name = "IPConnect",            filename = "DATA:\\UI\\NewUI\\Multiplayer\\IPConnect.lua",          type = "UIDialog" },

	-- Warning: DirectConnection and IPConnect must be loaded before this screen
	{ name = "ConnectionType",       filename = "DATA:\\UI\\NewUI\\Multiplayer\\ConnectionType.lua",     type = "ConnectionType" },
	{ name = "BetaPopupScreen",      filename = "DATA:\\UI\\NewUI\\Multiplayer\\BetaPopupScreen.lua",    type = "BetaPopupScreen" },
--{ name = "StyleSheetTestScreen", filename = "DATA:\\UI\\NewUI\\Styles\\StyleSheetTestScreen.lua" },
	{ name = "FEGameOptions",        filename = "DATA:\\UI\\NewUI\\FEGameOptions.lua",                   type = "FEGameOptions" },
	{ name = "GameInfoScreen",       filename = "DATA:\\UI\\NewUI\\Multiplayer\\GameInfoScreen.lua",     type = "GameInfoScreen" },
	{ name = "GameFilterScreen",     filename = "DATA:\\UI\\NewUI\\Multiplayer\\GameFilterScreen.lua",   type = "GameFilterScreen" },
	{ name = "YesNoDialog",          filename = "DATA:\\UI\\NewUI\\YesNoDialog.lua",                     type = "UIDialog" },
	{ name = "ErrorMessage",         filename = "DATA:\\UI\\NewUI\\ErrorMessage.lua",                    type = "ErrorMessage" },
	{ name = "WaitMessage",          filename = "DATA:\\UI\\NewUI\\WaitMessage.lua",                     type = "WaitMessage" },
	{ name = "SaveLoadDialog",       filename = "DATA:\\UI\\NewUI\\Shared\\SaveLoadDialog.lua",          type = "SaveLoadDialog" },
	{ name = "SubtitleScreen",       filename = "DATA:\\UI\\NewUI\\Subtitle.lua",                        type = "SubtitleScreen" },
	{ name = "PlayMoviesScreen",     filename = "DATA:\\UI\\NewUI\\PlayMoviesScreen.lua",                type = "PlayMoviesScreen" },
	{ name = "PropertyEditorScreen", filename = "DATA:\\UI\\NewUI\\Developer\\PropertyEditorScreen.lua", type = "PropertyEditorScreen" },
	{ name = "FEChatScreen",         filename = "DATA:\\UI\\NewUI\\Multiplayer\\FEChatScreen.lua",       type = "FEChatScreen" },
})

addTransientScreens({
  { name = "LoadingScreen", filename = "DATA:\\UI\\NewUI\\LoadingScreen.lua" }
})

addGameScreens({
	{ name = "Pointer",               filename = "DATA:\\UI\\NewUI\\Pointer.lua",                        type = "Pointer", activated = 1 },
	{ name = "GenericScreen",         filename = "DATA:\\UI\\NewUI\\Generic.lua" },
--{ name = "ResourceStatsMenu",     filename = "DATA:\\UI\\NewUI\\Resource.lua" },
	{ name = "PlayerDestroyedScreen", filename = "DATA:\\UI\\NewUI\\PlayerDestroyedScreen.lua" },
	{ name = "UnitCapInfoPopup",      filename = "DATA:\\UI\\NewUI\\UnitCapInfoPopup.lua",               type = "UnitCapInfoPopup" },
	{ name = "UnitsMenu",             filename = "DATA:\\UI\\NewUI\\Units.lua" },
	{ name = "ObjectivesList",        filename = "DATA:\\UI\\NewUI\\ObjectivesList.lua",                 type = "ObjectivesList" },
	-- Build menu must be loaded before the research menu
	{ name = "NewBuildMenu",          filename = "DATA:\\UI\\NewUI\\Build\\FinalBuild.lua",              type = "FinalBuildMenu" },
	{ name = "NewLaunchMenu",         filename = "DATA:\\UI\\NewUI\\NewLaunch.lua",                      type = "NewLaunchMenu"  },
	{ name = "NewResearchMenu",       filename = "DATA:\\UI\\NewUI\\Research\\Research.lua",             type = "NewResearchMenu" },
	{ name = "BuildInfo",             filename = "DATA:\\UI\\NewUI\\Build\\BuildInfo.lua",               type = "BuildInfo" },
	{ name = "ResearchInfo",          filename = "DATA:\\UI\\NewUI\\Research\\ResearchInfo.lua",         type = "ResearchInfo" },
	{ name = "NewTaskbar",            filename = "DATA:\\UI\\NewUI\\NewTaskbar.lua",                     type = "NewTaskbar" },
	{ name = "NewTaskbarRecover",     filename = "DATA:\\UI\\NewUI\\NewTaskbar.lua" },
	{ name = "ResourceMenu",          filename = "DATA:\\UI\\NewUI\\Resource.lua",                       type = "ResourceMenu" },
	{ name = "EventsScreen",          filename = "DATA:\\UI\\NewUI\\EventsScreen.lua",                   type = "EventsScreen" },
	{ name = "RightClickMenu",        filename = "DATA:\\UI\\NewUI\\RightClickMenu.lua",                 type = "RightClickMenu" },
	{ name = "RightClickRadialMenu",  filename = "DATA:\\UI\\NewUI\\RightClickRadialMenu.lua",           type = "RightClickRadialMenu" },
	{ name = "DiplomacyScreen",       filename = "DATA:\\UI\\NewUI\\DiplomacyScreen.lua",                type = "DiplomacyScreen" },
	{ name = "InGameMenu",            filename = "DATA:\\UI\\NewUI\\InGameMenu.lua",                     type = "GameMenu" },
	{ name = "FleetMenu",             filename = "DATA:\\UI\\NewUI\\FleetMenu.lua" },
	{ name = "TacticsMenu",           filename = "DATA:\\UI\\NewUI\\TacticsMenu.lua" },
	{ name = "StrikeGroupsMenu",      filename = "DATA:\\UI\\NewUI\\StrikeGroupsMenu.lua" },
	{ name = "BuildQueueMenu",        filename = "DATA:\\UI\\NewUI\\BuildQueueMenu.lua",                 type = "BuildQueueMenu" },
	{ name = "ChatScreen",            filename = "DATA:\\UI\\NewUI\\ChatScreen.lua",                     type = "ChatScreen" },
	{ name = "ChatFloating",          filename = "DATA:\\UI\\NewUI\\ChatFloating.lua",                   activated = 1 },
	{ name = "PlayerLaggingScreen",   filename = "DATA:\\UI\\NewUI\\PlayerLaggingScreen.lua",            type = "PlayerLaggingScreen" },
	{ name = "SMFiltersMenu",        filename = "DATA:\\UI\\NewUI\\SMFiltersMenu.lua",                   type = "SMFiltersMenu" },
	{ name = "SpeechRecall",         filename = "DATA:\\UI\\NewUI\\SpeechRecall.lua",                    type = "SpeechRecall" },
	{ name = "PauseScreen",          filename = "DATA:\\UI\\NewUI\\Shared\\PauseScreen.lua" },
	{ name = "InGameOptions",        filename = "DATA:\\UI\\NewUI\\InGameOptions.lua",                   type = "InGameOptions" },
	{ name = "SaveLoadDialog",       filename = "DATA:\\UI\\NewUI\\Shared\\SaveLoadDialog.lua",          type = "SaveLoadDialog" },
	{ name = "GameOverScreen",       filename = "DATA:\\UI\\NewUI\\GameOverScreen.lua",                  type = "GameOverScreen" },
	{ name = "bentusidialog",        filename = "DATA:\\UI\\NewUI\\BentusiDialog.lua" },
	{ name = "PlaybackMenu",         filename = "DATA:\\UI\\NewUI\\Playback\\PlaybackMenu.lua",          type = "PlaybackMenu" },
	{ name = "NotForPublicDisplay",  filename = "DATA:\\UI\\NewUI\\NotForPublicDisplay.lua" },--,             type = "NotForPublicDisplay" },
	{ name = "SubtitleScreen",       filename = "DATA:\\UI\\NewUI\\Subtitle.lua",                        type = "SubtitleScreen" },
	{ name = "SubtitleInputScreen",  filename = "DATA:\\UI\\NewUI\\SubtitleInput.lua" },

	-- DIALOGS
	{ name = "YesNoDialog",          filename = "DATA:\\UI\\NewUI\\YesNoDialog.lua",                     type = "UIDialog" },
	{ name = "ErrorMessage",         filename = "DATA:\\UI\\NewUI\\ErrorMessage.lua",                    type = "ErrorMessage" },

	---- Debug Screens -----
	{ name = "DebugScreen",          filename = "DATA:\\UI\\NewUI\\Developer\\DebugScreen.lua" },
	{ name = "PropertyEditorScreen", filename = "DATA:\\UI\\NewUI\\Developer\\PropertyEditorScreen.lua", type = "PropertyEditorScreen" },
	{ name = "GameBalanceScreen",    filename = "DATA:\\UI\\NewUI\\Developer\\GameBalanceScreen.lua",    type = "GameBalanceScreen" },
	{ name = "DeveloperScreen",      filename = "DATA:\\UI\\NewUI\\Developer\\DeveloperScreen.lua",      type = "DeveloperScreen" },
	{ name = "InGameModScreen",      filename = "DATA:\\UI\\NewUI\\Modder\\InGameModScreen.lua",         type = "InGameModScreen" },
})
