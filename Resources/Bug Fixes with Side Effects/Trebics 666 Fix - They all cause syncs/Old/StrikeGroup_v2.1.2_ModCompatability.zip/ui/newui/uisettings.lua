
StyleSheets = {}

FrontEndScreensCount = 0
TransientScreensCount = 0
GameScreensCount = 0

FrontEndScreens = {}
TransientScreens = {}
GameScreens = {}


function addStyleSheet(StyleSheet, Filename)
  StyleSheets[StyleSheet]= { filename = Filename }
end

function addFrontEndScreens(Screens)
  for key,val in Screens do
    FrontEndScreensCount = FrontEndScreensCount + 1
    FrontEndScreens[FrontEndScreensCount]= val

    if (not val.activated) then
      FrontEndScreens[FrontEndScreensCount].activated = 0
    end
  end
end

function addTransientScreens(Screens)
  for key,val in Screens do
    TransientScreensCount = TransientScreensCount + 1
    TransientScreens[TransientScreensCount]= val

    if (not val.activated) then
      TransientScreens[TransientScreensCount].activated = 0
    end
  end
end

function addGameScreens(Screens)
  for key,val in Screens do
    GameScreensCount = GameScreensCount + 1
    GameScreens[GameScreensCount]= val

    if (not val.activated) then
      GameScreens[GameScreensCount].activated = 0
    end
  end
end

doscanpath("DATA:UI\\NewUI\\UISettings", "*.lua")
