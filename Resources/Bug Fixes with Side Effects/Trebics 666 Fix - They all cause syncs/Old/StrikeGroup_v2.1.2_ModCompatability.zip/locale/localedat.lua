DictionaryCount = 0
Dictionaries = {}

function addDictionaries(...)
  local dictionary,prefix = arg[1], nil

  if (arg[2]) then
    dictionary = arg[2]
    prefix = arg[1]
  end
  for key,val in dictionary do
    DictionaryCount = DictionaryCount + 1
    Dictionaries[DictionaryCount]= {name = val}

    if (prefix) then
      Dictionaries[DictionaryCount].mod = prefix
    end
  end
end


doscanpath("DATA:Locale\\LocaleDat", "*.lua")
