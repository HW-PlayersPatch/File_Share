
addDictionaries({
  "engine.dat",
  "ships.dat",
  "resource.dat",
  "ui.dat",
  "events.dat",
  "ATI.dat",
  "levelDesc.dat",
  "buildresearch.dat",
  "HW1ships.dat",
  "HW1buildresearch.dat"})
