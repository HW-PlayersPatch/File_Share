l_prefix = ""
l_storage = {}
l_proximity = 200

function StrikeGroupTargetFix()
  SobGroup_CreateIfNotExist("StrikeGroup")
  SobGroup_CreateIfNotExist("Player_Ships")
  SobGroup_CreateIfNotExist("ProxyAllAvoid")

  for player = 0, Universe_PlayerCount()- 1 do
    SobGroup_Copy("Player_Ships", "Player_Ships"..player)
    SobGroup_Clear("ProxyAllAvoid")

    if (not l_storage[player + 1]) then
      l_storage[player + 1]= { count = 0; nil }
    end

    while (SobGroup_Count("Player_Ships") > 0) do
      SobGroup_FillShipsByIndexRange("StrikeGroup", "Player_Ships", 0, 1)

      if (SobGroup_InStrikeGroup("StrikeGroup")~= 1) then
        local name,id = getID("StrikeGroup")

        SobGroup_Clear(name.."PRIMARY"); SobGroup_Clear(name.."TARGETS")

        l_storage[player + 1][id].parent = nil
        l_storage[player + 1][id].potential = { nil }
      end
      if (SobGroup_InStrikeGroup("StrikeGroup")== 1) then
        local name,id = getID("StrikeGroup")

        l_storage[player + 1][id].parent = nil
        l_storage[player + 1][id].potential = { nil }

        SobGroup_CreateIfNotExist("tempTARGETS")
        SobGroup_GetCommandTargets("tempTARGETS", name, COMMAND_Attack)

        if (SobGroup_Empty("tempTARGETS")== 1) then
          SobGroup_Clear(name.."PRIMARY")
          SobGroup_Clear(name.."TARGETS")
        end
        if (SobGroup_Empty("tempTARGETS")~= 1) then
          if (SobGroup_Equal(name.."PRIMARY", "tempTARGETS")~= 1) then
            if (SobGroup_IsAlive(name.."PRIMARY")== 1 or SobGroup_IsAlive(name.."TARGETS")~= 1) then
              SobGroup_Copy(name.."TARGETS", "tempTARGETS")
              getPRIMARY(name)
            end
            if (SobGroup_IsAlive(name.."PRIMARY")~= 1) then
              getPRIMARY(name)
            end
          end

          SobGroup_CreateIfNotExist("ProxyAvoid")
          SobGroup_Copy("ProxyAvoid", "ProxyAllAvoid")
          SobGroup_SobGroupAdd("ProxyAvoid", name)

          scanProximity(name, name)

          SobGroup_Attack(player, "StrikeGroup", name.."PRIMARY")
          SobGroup_FillSubstract("Player_Ships", "Player_Ships", "ProxyAllAvoid")
        end
      end

      SobGroup_FillSubstract("Player_Ships", "Player_Ships", "StrikeGroup")
    end
  end
end


function scanProximity(ProxyGroup, ParentGroup, Depth)  Depth = Depth or 0
  local player = SobGroup_OwnedBy(ProxyGroup)

  SobGroup_CreateIfNotExist("ProxyGroup")
  SobGroup_CreateIfNotExist("ProxyDepth"..Depth)

  SobGroup_FillProximitySobGroup("ProxyDepth"..Depth, "Player_Ships"..player, ProxyGroup, l_proximity)
  SobGroup_FillSubstract("ProxyDepth"..Depth, "ProxyDepth"..Depth, "ProxyAvoid")

  SobGroup_SobGroupAdd("ProxyAvoid", "ProxyDepth"..Depth)

  while (SobGroup_Count("ProxyDepth"..Depth) > 0) do
    SobGroup_FillShipsByIndexRange("ProxyGroup", "ProxyDepth"..Depth, 0, 1)

    if (SobGroup_InStrikeGroup("ProxyGroup")== 1) then
      local name,id = getID("ProxyGroup")

      if (l_storage[player + 1][id].parent == ParentGroup) then
        SobGroup_SobGroupAdd("StrikeGroup", "ProxyGroup")
        SobGroup_Copy(name.."PRIMARY", ParentGroup.."PRIMARY")
        SobGroup_Copy(name.."TARGETS", ParentGroup.."TARGETS")

        l_storage[player + 1][id].potential = { nil }

        scanProximity("ProxyGroup", ParentGroup,(Depth + 1))
      end
      if (l_storage[player + 1][id].parent ~= ParentGroup) then
        SobGroup_SobGroupAdd("ProxyAllAvoid", "ProxyGroup")

        l_storage[player + 1][id].potential[ParentGroup] = l_storage[player + 1][id].potential[ParentGroup] or 0
        l_storage[player + 1][id].potential[ParentGroup] = l_storage[player + 1][id].potential[ParentGroup] + 1

        if (l_storage[player + 1][id].potential[ParentGroup] >= 8) then
          l_storage[player + 1][id].parent = ParentGroup
        end
      end
    end

    SobGroup_FillSubstract("ProxyDepth"..Depth, "ProxyDepth"..Depth, "ProxyGroup")
  end
end


function getID(CustomGroup)
  local player = SobGroup_OwnedBy(CustomGroup)
  local id,limit = -1, l_storage[player + 1].count or 0

  if (limit > 0) then
    for l = 1, limit do
      local name = l_prefix..player.."_"..l

      if (SobGroup_Empty(name)== 1) then id = l end
      if (SobGroup_GroupInGroup(name, CustomGroup)== 1) then id = l; break end
    end
  end
  if (id == -1) then
    l_storage[player + 1].count = limit + 1
    id = l_storage[player + 1].count

    SobGroup_CreateIfNotExist(l_prefix..player.."_"..id)
  end


  local name = l_prefix..player.."_"..id

  if (SobGroup_GroupInGroup(name, CustomGroup)~= 1) then
    SobGroup_CreateIfNotExist(name.."PRIMARY"); SobGroup_Clear(name.."PRIMARY")
    SobGroup_CreateIfNotExist(name.."TARGETS"); SobGroup_Clear(name.."TARGETS")
    SobGroup_Copy(name, CustomGroup)

    l_storage[player + 1][id]={ parent = nil, potential = { nil }}
  end

  return name, id
end

function getPRIMARY(CustomGroup)
  SobGroup_CreateIfNotExist("tempPOTENTIAL")
  SobGroup_CreateIfNotExist("tempTARGETS")
  SobGroup_CreateIfNotExist("tempPRIMARY"); SobGroup_Clear("tempPRIMARY")

  SobGroup_Copy("tempTARGETS", CustomGroup.."TARGETS")


  while (SobGroup_Count("tempTARGETS") > 0) do
    SobGroup_FillShipsByIndexRange("tempPOTENTIAL", "tempTARGETS", 0, 1)

    if (SobGroup_HealthPercentage("tempPOTENTIAL") > 0) then
      SobGroup_SobGroupAdd("tempPRIMARY", "tempPOTENTIAL")
    end

    SobGroup_FillSubstract("tempTARGETS", "tempTARGETS", "tempPOTENTIAL")
  end

  if (SobGroup_Count("tempPRIMARY") > 0) then
    SobGroup_FillShipsByIndexRange(CustomGroup.."PRIMARY", "tempPRIMARY", (nrandom(0, SobGroup_Count("tempPRIMARY")- 1)), 1)
  end


  dofilepath("Player:PLAYERCFG.lua")

  if (Options.GameplayOptions.enableMilitary ~= 1) then
    SobGroup_Copy(CustomGroup.."TARGETS", CustomGroup.."PRIMARY")
  end
end
