l_TargetFix__Count = {}
l_TargetFix__Parent = {}
l_TargetFix__Proximity = 100        --less = lower chance of wrong units in strikegroup, increased chance of missing units from strikegroup
l_TargetFix__BreakDistance = 4000   --distance between strikegroup leader and target before auto switch target

function TargetFix_RULE()
  SobGroup_CreateIfNotExist("StrikeGroup")
  SobGroup_CreateIfNotExist("Player_Ships")

  for player = 0, Universe_PlayerCount()- 1 do
    SobGroup_Copy("Player_Ships", "Player_Ships"..player)

    while (SobGroup_Empty("Player_Ships")~= 1) do
      SobGroup_FillShipsByIndexRange("StrikeGroup", "Player_Ships", 0, 1)

      if (SobGroup_InStrikeGroup("StrikeGroup")== 1) then
        local CustomGroup, ShipId = TargetFix__getShipId("StrikeGroup")

        if (l_TargetFix__Parent[player + 1][ShipId]== nil) then
          SobGroup_CreateIfNotExist("StrikeTarget")
          SobGroup_GetCommandTargets("StrikeTarget", CustomGroup, COMMAND_Attack)

          if (SobGroup_Empty("StrikeTarget")== 1) then
            SobGroup_Clear(CustomGroup.."PRIMARY")
            SobGroup_Clear(CustomGroup.."TARGETS")
          end
          if (SobGroup_Empty("StrikeTarget")~= 1) then
            if (SobGroup_Equal(CustomGroup.."PRIMARY", "StrikeTarget")~= 1) then
              if (SobGroup_IsAlive(CustomGroup.."PRIMARY")== 1 or SobGroup_IsAlive(CustomGroup.."TARGETS")~= 1) then
                SobGroup_Copy(CustomGroup.."TARGETS", "StrikeTarget")
                TargetFix__getPrimary(CustomGroup)
              end
              if (SobGroup_IsAlive(CustomGroup.."PRIMARY")~= 1) then
                TargetFix__getPrimary(CustomGroup)
              end
              if (SobGroup_GetDistanceToSobGroup(CustomGroup, CustomGroup.."PRIMARY") > l_TargetFix__BreakDistance) then
                TargetFix__getPrimary(CustomGroup)
              end
            end

            SobGroup_CreateIfNotExist("ProxyAvoid")
            SobGroup_Copy("ProxyAvoid", CustomGroup)

            TargetFix__scanProximity(CustomGroup, CustomGroup)

            SobGroup_Attack(player, "StrikeGroup", CustomGroup.."PRIMARY")
          end
        end
        if (l_TargetFix__Parent[player + 1][ShipId]~= nil) then
          l_TargetFix__Parent[player + 1][ShipId]= nil

          SobGroup_Clear(CustomGroup.."PRIMARY")
          SobGroup_Clear(CustomGroup.."TARGETS")
        end
      end

      SobGroup_FillSubstract("Player_Ships", "Player_Ships", "StrikeGroup")
    end
  end
end


function TargetFix__getShipId(CustomGroup)
  local player = SobGroup_OwnedBy(CustomGroup)
  local ShipId, Max = -1, l_TargetFix__Count[player + 1] or 0

  if (Max > 0) then
    for k = 1, Max do
      if (SobGroup_Empty("l_TargetFix__"..player.."_"..k)== 1) then ShipId = k end
      if (SobGroup_GroupInGroup("l_TargetFix__"..player.."_"..k, CustomGroup)== 1) then ShipId = k; break end
    end
  end
  if (ShipId == -1) then
    l_TargetFix__Count[player + 1]= Max + 1
    ShipId = l_TargetFix__Count[player + 1]

    SobGroup_CreateIfNotExist("l_TargetFix__"..player.."_"..ShipId)
  end

  if (SobGroup_GroupInGroup("l_TargetFix__"..player.."_"..ShipId, CustomGroup)~= 1) then
    SobGroup_CreateIfNotExist("l_TargetFix__"..player.."_"..ShipId.."PRIMARY"); SobGroup_Clear("l_TargetFix__"..player.."_"..ShipId.."PRIMARY")
    SobGroup_CreateIfNotExist("l_TargetFix__"..player.."_"..ShipId.."TARGETS"); SobGroup_Clear("l_TargetFix__"..player.."_"..ShipId.."TARGETS")
    SobGroup_Copy("l_TargetFix__"..player.."_"..ShipId, CustomGroup)

    if (l_TargetFix__Parent[player + 1]== nil) then
      l_TargetFix__Parent[player + 1]= {}
    end

    l_TargetFix__Parent[player + 1][ShipId]= nil
  end

  return "l_TargetFix__"..player.."_"..ShipId, ShipId
end

--Choosing our primary target
function TargetFix__getPrimary(CustomGroup)
  SobGroup_CreateIfNotExist("tempPRIMARY")
  SobGroup_CreateIfNotExist("tempTARGETS")
  SobGroup_CreateIfNotExist("tempALIVELIST")

  SobGroup_Clear("tempALIVELIST")
  SobGroup_Copy("tempTARGETS", CustomGroup.."TARGETS")


  local int,max = 0, SobGroup_Count("tempTARGETS")- 1

  while (int <= max) do
    SobGroup_FillShipsByIndexRange("tempPRIMARY", "tempTARGETS", int, 1)

    if (SobGroup_IsAlive("tempPRIMARY")== 1) then
      SobGroup_SobGroupAdd("tempALIVELIST", "tempPRIMARY")
    end
    if (SobGroup_Count("tempPRIMARY") > 0) then
      int = int +(SobGroup_Count("tempPRIMARY")- 1)
    end

    int = int + 1
  end

  if (SobGroup_Count("tempALIVELIST") > 0) then
    SobGroup_FillShipsByIndexRange(CustomGroup.."PRIMARY", "tempALIVELIST", random(0, SobGroup_Count("tempALIVELIST")- 1), 1)
  end

  dofilepath("Player:PLAYERCFG.lua")

  if (Options.GameplayOptions.enableMilitary ~= 1) then
    SobGroup_Copy(CustomGroup.."TARGETS", CustomGroup.."PRIMARY")
  end
end

--How we capture a strikegroup
function TargetFix__scanProximity(CustomGroup, ParentGroup, Depth)  Depth = Depth or 0
  local player = SobGroup_OwnedBy(ParentGroup)

  SobGroup_CreateIfNotExist("ProxyScan")
  SobGroup_CreateIfNotExist("ProxyDepth"..Depth)

  SobGroup_FillProximitySobGroup("ProxyDepth"..Depth, "Player_Ships"..player, CustomGroup, l_TargetFix__Proximity)
  SobGroup_FillSubstract("ProxyDepth"..Depth, "ProxyDepth"..Depth, "ProxyAvoid")
  SobGroup_SobGroupAdd("ProxyAvoid", "ProxyDepth"..Depth)

  while (SobGroup_Empty("ProxyDepth"..Depth)~= 1) do
    SobGroup_FillShipsByIndexRange("ProxyScan", "ProxyDepth"..Depth, 0, 1)

    if (SobGroup_InStrikeGroup("ProxyScan")== 1) then
      local ProxyGroup, ShipId = TargetFix__getShipId("ProxyScan")

      SobGroup_CreateIfNotExist("ProxyTarget")
      SobGroup_GetCommandTargets("ProxyTarget", ProxyGroup, COMMAND_Attack)

      if (l_TargetFix__Parent[player + 1][ShipId]~= ParentGroup) then
        local squadronCount = SobGroup_CountBySquadrons("ProxyTarget")

        if (squadronCount > 1 and SobGroup_Equal(ParentGroup.."TARGETS", "ProxyTarget", 1)== 1) then
          l_TargetFix__Parent[player + 1][ShipId]= ParentGroup
        end
        if (squadronCount == 1 and l_TargetFix__Parent[player + 1][ShipId]== nil) then
          if (SobGroup_Equal(ParentGroup.."TARGETS", CustomGroup.."TARGETS", 1)== 1) then
            l_TargetFix__Parent[player + 1][ShipId]= ParentGroup
          end
          if (SobGroup_GroupInGroup(CustomGroup.."PRIMARY", ParentGroup.."TARGETS")== 1) then
            l_TargetFix__Parent[player + 1][ShipId]= ParentGroup
          end
        end

        if (SobGroup_Equal(ParentGroup.."TARGETS", ProxyGroup.."TARGETS", 1)== 1 or
            SobGroup_Equal(ParentGroup.."PRIMARY", ProxyGroup.."PRIMARY")== 1) then

          l_TargetFix__Parent[player + 1][ShipId]= ParentGroup
        end
      end
      if (l_TargetFix__Parent[player + 1][ShipId]== ParentGroup) then
        SobGroup_Copy(ProxyGroup.."PRIMARY", ParentGroup.."PRIMARY")
        SobGroup_Copy(ProxyGroup.."TARGETS", ParentGroup.."TARGETS")
        SobGroup_SobGroupAdd("StrikeGroup", ProxyGroup)

        TargetFix__scanProximity(ProxyGroup, ParentGroup,(Depth + 1))
      end
    end

    SobGroup_FillSubstract("ProxyDepth"..Depth, "ProxyDepth"..Depth, "ProxyScan")
  end
end
