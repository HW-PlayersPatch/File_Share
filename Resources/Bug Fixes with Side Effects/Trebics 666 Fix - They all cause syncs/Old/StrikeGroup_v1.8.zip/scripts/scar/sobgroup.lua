
if (not SobGroup_Equal) then
  function SobGroup_Equal(sGroupA, sGroupB, Diff)  Diff = Diff or 0
    SobGroup_CreateIfNotExist("SobGroup_Compare")
    SobGroup_FillCompare("SobGroup_Compare", sGroupA, sGroupB)

    Diff = Diff -(SobGroup_Count(sGroupA)- SobGroup_Count("SobGroup_Compare"))
    Diff = Diff -(SobGroup_Count(sGroupB)- SobGroup_Count("SobGroup_Compare"))

    if (Diff >= 0) then return 1 end
  end
end

if (not SobGroup_GetDistanceToSobGroup) then
  function SobGroup_GetDistanceToSobGroup(sGroupA, sGroupB)
    if (SobGroup_Empty(sGroupA)== 1 or SobGroup_Empty(sGroupB)== 1) then return 0 end

    local PosA,PosB = SobGroup_GetPosition(sGroupA), SobGroup_GetPosition(sGroupB)
    local X,Y,Z = (PosA[1]- PosB[1]), (PosA[2]- PosB[2]), (PosA[3]- PosB[3])

    return floor(sqrt(X * X + Y * Y + Z * Z))
  end
end

if (not SobGroup_IsAlive) then
  function SobGroup_IsAlive(sGroup)
    if (SobGroup_HealthPercentage(sGroup) > 0) then return 1 end
  end
end

if (not SobGroup_CountBySquadrons) then
  function SobGroup_CountBySquadrons(sGroupA)
    local squadCount = 0

    SobGroup_CreateIfNotExist("SobGroup_CountBySquadrons0")
    SobGroup_CreateIfNotExist("SobGroup_CountBySquadrons1")
    SobGroup_Copy("SobGroup_CountBySquadrons0", sGroupA)

    while (SobGroup_Empty("SobGroup_CountBySquadrons0")~= 1) do
      SobGroup_FillShipsByIndexRange("SobGroup_CountBySquadrons1", "SobGroup_CountBySquadrons0", 0, 1)

      if (SobGroup_Count("SobGroup_CountBySquadrons1") > 0) then
        squadCount = squadCount + 1
      end

      SobGroup_FillSubtract("SobGroup_CountBySquadrons0", "SobGroup_CountBySquadrons0", "SobGroup_CountBySquadrons1")
    end

    return squadCount
  end
end


if (not old__SobGroup_HealthPercentage and globals) then
  old__SobGroup_HealthPercentage = SobGroup_HealthPercentage
  rawset(globals(), "SobGroup_HealthPercentage",
    function (SobGroup)
      local SobHealth = old__SobGroup_HealthPercentage(SobGroup)

      if (not SobHealth or SobHealth < 0) then return 0 end
      if (SobHealth > 1) then return 1 end

      return SobHealth
    end
  )
end
