dofilepath("DATA:Scripts\\SCaR\\Functions.lua")


function TargetFix()
  if (Rule_Exists("TargetFix_RULE")~= 1) then
    LoadStrikeGroup()

    SobGroup_CreateIfNotExist("Proxy_Avoid")

    Rule_AddInterval("TargetFix_RULE", l__StrikeGroupInterval)
  end
end

function TargetFix_RULE()
  SobGroup_CreateIfNotExist("StrikeGroup")
  SobGroup_CreateIfNotExist("StrikeGroup0")
  SobGroup_CreateIfNotExist("StrikeGroup1")

  SobGroup_CreateIfNotExist("Player_Ships")

  for player = 0, Universe_PlayerCount()- 1 do
    SobGroup_Copy("Player_Ships", "Player_Ships"..player)
    SobGroup_Clear("Proxy_Avoid")

    while (SobGroup_Empty("Player_Ships")~= 1) do
      SobGroup_FillShipsByIndexRange("StrikeGroup", "Player_Ships", 0, 1)
      SobGroup_SobGroupAdd("Proxy_Avoid", "StrikeGroup")

      if (l__StrikeGroupStorage.Ships[strlower(SobGroup_GetShipType("StrikeGroup"))]) then
        local SobName,SobID = GetSobGroupId("StrikeGroup")

        if (SobGroup_InStrikeGroup("StrikeGroup")~= 1) then
          if (SobGroup_Exists(SobName.."PRIMARY")== 1) then SobGroup_Clear(SobName.."PRIMARY") end
          if (SobGroup_Exists(SobName.."TARGETS")== 1) then SobGroup_Clear(SobName.."TARGETS") end

        else
          GetTargetList(SobName)
          GatherStrikeGroup(SobName, "StrikeGroup")

          if (SobGroup_IsDoingAbility("StrikeGroup", AB_SpecialAttack)== 1) then
            SobGroup_Copy("StrikeGroup0", "StrikeGroup")

            while (SobGroup_Empty("StrikeGroup0")~= 1) do
              SobGroup_FillShipsByIndexRange("StrikeGroup1", "StrikeGroup0", 0, 1)
              SobGroup_FillSubstract("StrikeGroup0", "StrikeGroup0", "StrikeGroup1")

              if (SobGroup_CanDoAbility("StrikeGroup1", AB_UseSpecialWeaponsInNormalAttack)~= 1) then
                if (SobGroup_IsDoingAbility("StrikeGroup1", AB_SpecialAttack)== 1) then
                  SobGroup_FillSubstract("StrikeGroup", "StrikeGroup", "StrikeGroup1")
                end
              end
            end
          end

          SobGroup_Attack(player, "StrikeGroup", SobName.."PRIMARY")
        end
      end

      SobGroup_FillSubstract("Player_Ships", "Player_Ships", "Proxy_Avoid")
    end
  end
end
