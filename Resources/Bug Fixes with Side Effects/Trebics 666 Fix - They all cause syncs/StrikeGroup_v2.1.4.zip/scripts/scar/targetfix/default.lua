--addTargetFix( "<ShipType>" ,<UniqueDetails> )
--  <UniqueDetails> is an optional table with current 2 keys
--    ProximityToScan       --The proximity to scan around this shiptype for strikegroup members (Default: 200)
--    JoinStrikeGroupDelay  --The delay in seconds before accepting to join a strikegroup (Default: 2)
--
-- Defaults can be changed in Scripts\SCaR\TargetFix.lua


--Hiigaran
addStrikeGroup("Hgn_Scout", { ProximityToScan = 200, JoinStrikeGroupDelay = 2 })
addStrikeGroup("Hgn_Interceptor", { ProximityToScan = 200 })
addStrikeGroup("Hgn_AttackBomber", { JoinStrikeGroupDelay = 2 })
addStrikeGroup("Hgn_AttackBomberElite", { JoinStrikeGroupDelay = 200, })

--Vaygr
addStrikeGroup("Vgr_Scout")
addStrikeGroup("Vgr_Interceptor")
addStrikeGroup("Vgr_Bomber")
addStrikeGroup("Vgr_LanceFighter")
addStrikeGroup("Vgr_LaserCorvette")

--Kushan
addStrikeGroup("Kus_Scout")
addStrikeGroup("Kus_Interceptor")
addStrikeGroup("Kus_CloakedFighter")
addStrikeGroup("Kus_AttackBomber")

--Taiidan
addStrikeGroup("Tai_Scout")
addStrikeGroup("Tai_Interceptor")
addStrikeGroup("Tai_AttackBomber")
