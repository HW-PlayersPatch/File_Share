
RandomSeed = { 763261, 214013, 2531011, 4294967296 }

function nrandom(...)
  RandomSeed[1]= mod(RandomSeed[1]* RandomSeed[2]+ RandomSeed[3], RandomSeed[4])
  RandomTemp = RandomSeed[1] / (RandomSeed[4]- 1)

  if (arg[2]) then return floor(arg[1]+ 0.5 +RandomTemp *(arg[2]- arg[1])) end
  if (arg[1]) then return floor(RandomTemp * arg[1])+ 1 end

  return RandomTemp
end


l__SobGroupIDStorage = { Prefix = "l__Prefix"; nil }

function GetSobGroupId(CustomGroup)
  local player = SobGroup_OwnedBy(CustomGroup)

  if (not l__SobGroupIDStorage[player + 1]) then l__SobGroupIDStorage[player + 1] = { Count = 0; nil } end

  local SobGroupID,Limit = -1, l__SobGroupIDStorage[player + 1].Count or 0

  if (Limit > 0) then
    for l = 1, Limit do
      local Name = l__SobGroupIDStorage.Prefix..player.."_"..l

      if (SobGroup_Empty(Name)== 1) then SobGroupID = l end
      if (SobGroup_GroupInGroup(Name, CustomGroup)== 1) then SobGroupID = l; break end
    end
  end
  if (SobGroupID == -1) then
    l__SobGroupIDStorage[player + 1].Count = Limit + 1
    SobGroupID = l__SobGroupIDStorage[player + 1].Count

    SobGroup_CreateIfNotExist(l__SobGroupIDStorage.Prefix..player.."_"..SobGroupID)
  end

  local Name = l__SobGroupIDStorage.Prefix..player.."_"..SobGroupID

  if (SobGroup_GroupInGroup(Name, CustomGroup)~= 1) then
    SobGroup_CreateIfNotExist(Name.."PRIMARY"); SobGroup_Clear(Name.."PRIMARY")
    SobGroup_CreateIfNotExist(Name.."TARGETS"); SobGroup_Clear(Name.."PRIMARY")
    SobGroup_Copy(Name, CustomGroup)

    l__SobGroupIDStorage[player + 1][SobGroupID]= {Parent = nil, Potential = { nil }}
  end

  return Name, SobGroupID
end


l__StrikeGroupProximityToScan = 200
l__StrikeGroupJoinStrikeGroupDelay = 2

l__StrikeGroupStorage = { Ships = { nil }; nil }
l__StrikeGroupInterval = 0.25

function LoadStrikeGroup()
  l__StrikeGroupStorage = { Ships = { nil }; nil }
  doscanpath("DATA:Scripts\\SCaR\\TargetFix", "*.lua")
end

function addStrikeGroup(ShipType, UniqueDetails)
  ShipType = strlower(ShipType)
  UniqueDetails = UniqueDetials or { nil }

  l__StrikeGroupStorage.Ships[ShipType]=
  {
    ProximityToScan = UniqueDetails.ProximityToScan or l__StrikeGroupProximityToScan,
    JoinStrikeGroupDelay = UniqueDetails.JoinStrikeGroupDelay or l__StrikeGroupJoinStrikeGroupDelay,
  }
end

function GatherStrikeGroup(ProxyName, ParentName, Depth)  Depth = Depth or 0
  local player,ShipType = SobGroup_OwnedBy(ProxyName), strlower(SobGroup_GetShipType(ProxyName))

  SobGroup_CreateIfNotExist("ProxyShips")
  SobGroup_CreateIfNotExist("ProxyShips"..Depth)

  SobGroup_FillProximitySobGroup("ProxyShips"..Depth, "Player_Ships"..player, ProxyName, l__StrikeGroupStorage.Ships[ShipType].ProximityToScan)
  SobGroup_FillSubstract("ProxyShips"..Depth, "ProxyShips"..Depth, "Proxy_Avoid")
  SobGroup_SobGroupAdd("Proxy_Avoid", "ProxyShips"..Depth)

  while (SobGroup_Empty("ProxyShips"..Depth)~= 1) do
    SobGroup_FillShipsByIndexRange("ProxyShips", "ProxyShips"..Depth, 0, 1)

    if (l__StrikeGroupStorage.Ships[strlower(SobGroup_GetShipType("ProxyShips"))]) then
      if (SobGroup_InStrikeGroup("ProxyShips")== 1) then
        local SobName,SobID = GetSobGroupId("ProxyShips")

        if (l__SobGroupIDStorage[player + 1][SobID].Parent == ParentName) then
          SobGroup_SobGroupAdd("StrikeGroup", "ProxyShips")

          if (SobGroup_Exists(SobName.."PRIMARY")== 1 and SobGroup_Exists(ParentName.."PRIMARY")== 1) then
            SobGroup_Copy(SobName.."PRIMARY", ParentName.."PRIMARY")
          end
          if (SobGroup_Exists(SobName.."TARGETS")== 1 and SobGroup_Exists(ParentName.."TARGETS")== 1) then
            SobGroup_Copy(SobName.."TARGETS", ParentName.."TARGETS")
          end

          l__SobGroupIDStorage[player + 1][SobID].Potential = { nil }
          GatherStrikeGroup(SobName, ParentName, (Depth + 1))
        else
          local ShipType = strlower(SobGroup_GetShipType(SobName))
          local JoinDelay = (1 / l__StrikeGroupInterval) * l__StrikeGroupStorage.Ships[ShipType].JoinStrikeGroupDelay

          l__SobGroupIDStorage[player + 1][SobID].Potential[ParentName]= l__SobGroupIDStorage[player + 1][SobID].Potential[ParentName] or 0
          l__SobGroupIDStorage[player + 1][SobID].Potential[ParentName]= l__SobGroupIDStorage[player + 1][SobID].Potential[ParentName] + 1

          if (l__SobGroupIDStorage[player + 1][SobID].Potential[ParentName] >= JoinDelay) then
            l__SobGroupIDStorage[player + 1][SobID].Parent = ParentName
          end
        end
      end
    end

    SobGroup_FillSubstract("ProxyShips"..Depth, "ProxyShips"..Depth, "ProxyShips")
  end
end


function GetTargetList(CustomGroup)
  SobGroup_CreateIfNotExist("tempPRIMARY"); SobGroup_CreateIfNotExist(CustomGroup.."PRIMARY")
  SobGroup_CreateIfNotExist("tempTARGETS"); SobGroup_CreateIfNotExist(CustomGroup.."TARGETS")

  SobGroup_GetCommandTargets("tempTARGETS", CustomGroup, COMMAND_Attack)

  if (SobGroup_Empty("tempTARGETS")== 1) then
    SobGroup_Clear(CustomGroup.."PRIMARY")
    SobGroup_Clear(CustomGroup.."TARGETS")

  else
    if (SobGroup_Equal(CustomGroup.."PRIMARY", "tempTARGETS")~= 1) then
      dofilepath("PLAYER:PLAYERCFG.lua")

      if (SobGroup_IsAlive(CustomGroup.."PRIMARY")== 1 or SobGroup_IsAlive(CustomGroup.."TARGETS")~= 1 or
          Options.GameplayOptions.enableMilitary ~= 1) then
        SobGroup_Copy(CustomGroup.."TARGETS", "tempTARGETS")
      end

      GetAttackTarget(CustomGroup, CustomGroup.."PRIMARY", CustomGroup.."TARGETS")
    end
  end
end

function GetAttackTarget(CustomGroup, AttackGroup, TargetGroup, MaxDistance)
  SobGroup_CreateIfNotExist("tempTARGET"); SobGroup_Copy("tempTARGET", TargetGroup)
  SobGroup_FilterExclude("tempTARGET", "tempTARGET", "Health", "0")
  SobGroup_Clear(AttackGroup)

  if (MaxDistance) then
    SobGroup_FillProximitySobGroup("tempTARGET", "tempTARGET", CustomGroup, MaxDistance)
  end
  if (SobGroup_Count("tempTARGET") > 0) then
    -- Don't like this, but adding too much may affect performance
    SobGroup_FillShipsByIndexRange(AttackGroup, "tempTARGET", nrandom(0, SobGroup_Count("tempTARGET")- 1), 1)
  end
end


function SobGroup_CountBySquadrons(sGroup)
  local Count = 0

  SobGroup_CreateIfNotExist("tempCOUNT0")
  SobGroup_CreateIfNotExist("tempCOUNT1")
  SobGroup_Copy("tempCOUNT0", sGroup)

  while (SobGroup_Empty("tempCOUNT0")~= 1) do
    SobGroup_FillShipsByIndexRange("tempCOUNT1", "tempCOUNT0", 0, 1)
    SobGroup_FillSubstract("tempCOUNT0", "tempCOUNT0", "tempCOUNT1")

    Count = Count + 1
  end

  return Count
end

function SobGroup_Equal(sGroupA, sGroupB, Diff)  Diff = Diff or 0
  SobGroup_CreateIfNotExist("SobGroup_Equal")
  SobGroup_FillCompare("SobGroup_Equal", sGroupA, sGroupB)

  Diff = Diff -(SobGroup_Count(sGroupA)- SobGroup_Count("SobGroup_Equal"))
  Diff = Diff -(SobGroup_Count(sGroupB)- SobGroup_Count("SobGroup_Equal"))

  if (Diff >= 0) then return 1 end
end

function SobGroup_IsAlive(sGroup)
  local sHealth = SobGroup_HealthPercentage(sGroup)

  if (not sHealth or sHealth == 0) then
    return 0
  end

  return 1
end

function SobGroup_GetDistanceToSobGroup(sGroupA, sGroupB)
  if (SobGroup_Empty(sGroupA)== 0 and SobGroup_Empty(sGroupB)== 0) then
    return SobGroup_GetDistanceToPoint(sGroupA, SobGroup_GetPosition(sGroupB))
  end

  return 0
end

function SobGroup_GetDistanceToPoint(sGroupA, posB)
	if (SobGroup_Empty(sGroupA)== 0) then
    local posA = SobGroup_GetPosition(sGroupA)
    local x = (posA[1]- posB[1])*(posA[1]- posB[1])
    local y = (posA[2]- posB[2])*(posA[2]- posB[2])
    local z = (posA[3]- posB[3])*(posA[3]- posB[3])

    return floor(sqrt(x + y + z))
  end

	return 0
end
