--addStrikeGroup( "<ShipType>" ,<UniqueDetails> )
--  <UniqueDetails> is an optional table with current 2 keys
--    ProximityToScan       --The proximity to scan around this shiptype for strikegroup members (Default: 200)
--    JoinStrikeGroupDelay  --The delay in seconds before accepting to join a strikegroup (Default: 2)
--
-- Defaults can be changed in Scripts\SCaR\functions.lua
-- 
-- Examples:
-- addStrikeGroup("Hgn_Scout", { ProximityToScan = 190, JoinStrikeGroupDelay = 2 })
-- addStrikeGroup("Hgn_Interceptor", { ProximityToScan = 195 })
-- addStrikeGroup("Hgn_AttackBomber", { JoinStrikeGroupDelay = 3 })


--Hiigaran
addStrikeGroup("Hgn_Scout")
addStrikeGroup("Hgn_Interceptor")
addStrikeGroup("Hgn_AttackBomber")
addStrikeGroup("Hgn_AttackBomberElite")

--Vaygr
addStrikeGroup("Vgr_Scout")
addStrikeGroup("Vgr_Interceptor")
addStrikeGroup("Vgr_Bomber")
addStrikeGroup("Vgr_LanceFighter")
addStrikeGroup("Vgr_LaserCorvette")

--Kushan
addStrikeGroup("Kus_Scout")
addStrikeGroup("Kus_Interceptor")
addStrikeGroup("Kus_CloakedFighter")
addStrikeGroup("Kus_AttackBomber")

--Taiidan
addStrikeGroup("Tai_Scout")
addStrikeGroup("Tai_Interceptor")
addStrikeGroup("Tai_AttackBomber")
