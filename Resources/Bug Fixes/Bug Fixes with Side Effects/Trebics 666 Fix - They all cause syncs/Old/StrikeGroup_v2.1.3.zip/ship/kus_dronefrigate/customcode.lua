dofilepath("DATA:Scripts\\SCaR\\Functions.lua")

DroneAttackDistance = 2000
DroneAttackDistanceMax = 2400

DroneFormation = {
	kus_drone0  ={210,  0,   0}, kus_drone1  ={-210,   0,   0},
	kus_drone2  ={  0,210,   0}, kus_drone3  ={   0,-210,   0},
	kus_drone4  ={  0,  0, 210}, kus_drone5  ={   0,   0,-210},
	kus_drone6  ={120,120, 120}, kus_drone7  ={-120, 120, 120}, kus_drone8  ={120,-120, 120}, kus_drone9  ={-120,-120, 120},
	kus_drone10 ={120,120,-120}, kus_drone11 ={-120, 120,-120}, kus_drone12 ={120,-120,-120}, kus_drone13 ={-120,-120,-120},
}


function Create_DroneFrigate(CustomGroup, player, ShipID)
  SobGroup_CreateIfNotExist("tempDRONE0")
	SobGroup_SetSwitchOwnerFlag(CustomGroup, 0)

	for k = 0,13 do
		SobGroup_CreateIfNotExist("kus_drone"..ShipID..k)
	end
end

function Update_DroneFrigate(CustomGroup, player, ShipID)
	local SobName,Distance = CustomGroup..player.."_"..ShipID, 0

	if (Player_GetLevelOfDifficulty(player) > 0) then
  	local enemyNear = 0

  	for playerAI = 0, Universe_PlayerCount()- 1 do
    	if (Player_IsAlive(playerAI)== 1) then
      	if (SobGroup_FillProximitySobGroup("tempDRONE0", "Player_Ships"..playerAI, CustomGroup, 4000)== 1) then
        	if (AreAllied(player, playerAI)== 0) then enemyNear = 1 end
      	end
    	end
  	end

  	if (enemyNear == 1) then
    	if (SobGroup_IsDoingAbility(CustomGroup, AB_Custom)== 0) then
      	SobGroup_CustomCommand(CustomGroup)
      end
    end
  end

	SobGroup_CreateIfNotExist(SobName); SobGroup_Copy(SobName, CustomGroup)
	SobGroup_GetSobGroupBeingCapturedGroup(CustomGroup, "tempDRONE0")
	GetTargetList(SobName)

	if (SobGroup_Count(SobName.."PRIMARY") > 0) then
		Distance = SobGroup_GetDistanceToSobGroup(SobName, SobName.."PRIMARY")
		SobGroup_Attack(player, SobName, SobName.."PRIMARY")
		SobGroup_CreateIfNotExist(SobName.."SECONDY")

		if (Distance > DroneAttackDistanceMax) then
			if ((SobGroup_Count(SobName.."SECONDY") > 0 and SobGroup_GetDistanceToSobGroup(SobName, SobName.."SECONDY") > DroneAttackDistanceMax) or
			 		 SobGroup_Count(SobName.."SECONDY")== 0) then

				GetAttackTarget(SobName, SobName.."SECONDY", SobName.."TARGETS", DroneAttackDistance)
			end
		else
			SobGroup_Clear(SobName.."SECONDY")
		end
	end

	for k = 0,13 do
		local DroneName = "kus_drone"..ShipID..k

		if (SobGroup_Empty(DroneName)== 0 and SobGroup_IsDoingAbility(DroneName, AB_Dock)~= 1 and
				SobGroup_IsDockedSobGroup(DroneName, CustomGroup)== 0) then

			if (SobGroup_OwnedBy(DroneName)~= player or SobGroup_Count("tempDRONE0") > 0 or SobGroup_AreAllInRealSpace(CustomGroup)== 0 or
					SobGroup_IsDoingAbility(CustomGroup, AB_Hyperspace)== 1 or SobGroup_IsDoingAbility(CustomGroup, AB_HyperspaceViaGate)== 1 or
        	SobGroup_IsDoingAbility(CustomGroup, AB_Retire)== 1 or SobGroup_GetDistanceToSobGroup(CustomGroup, DroneName) > 950) then

      	SobGroup_TakeDamage(DroneName, 1)
			else
				SobGroup_AbilityActivate(DroneName, AB_Targeting, 1)

				if (SobGroup_Count(SobName.."PRIMARY") > 0) then
					SobGroup_CreateIfNotExist("tempTARGETS")
					SobGroup_GetCommandTargets("tempTARGETS", DroneName, COMMAND_Attack)

					if (SobGroup_Count(SobName.."SECONDY") > 0) then
						if (SobGroup_Equal("tempTARGETS", SobName.."SECONDY")~= 1 and SobGroup_IsDoingAbility(CustomGroup, AB_Move)~= 1) then
							SobGroup_Attack(player, DroneName, SobName.."SECONDY")
						end
					end
					if (SobGroup_Count(SobName.."SECONDY")== 0) then
						if (SobGroup_Equal("tempTARGETS", SobName.."PRIMARY")~= 1) then
							SobGroup_Attack(player, DroneName, SobName.."PRIMARY")
						end
					end
				end

				DronePosition(player, CustomGroup, DroneName, DroneFormation)
			end
		end
	end
end

function Destroy_DroneFrigate(CustomGroup, player, ShipID)
	for k = 0,13 do
    local DroneName = "kus_drone"..ShipID..k

		if (SobGroup_Empty(DroneName)== 0) then
			SobGroup_TakeDamage(DroneName, 1)
		end
	end
end

--------------------------------------------------------------------------------

function DronePosition(player, CustomGroup, DroneGroup, DroneFormation, Radius)
	local ShipPosition = DroneFormation[strlower(SobGroup_GetShipType(DroneGroup))]
	local VolPosition = SobGroup_GetPosition(CustomGroup)
	local IsMoveRequired = 0

	Radius = Radius or 1

	VolPosition[1]= VolPosition[1]+ ShipPosition[1]
	VolPosition[2]= VolPosition[2]+ ShipPosition[2]
	VolPosition[3]= VolPosition[3]+ ShipPosition[3]

	Volume_AddSphere("vol"..DroneGroup, VolPosition, Radius)
		if (SobGroup_IsInVolume(DroneGroup, "vol"..DroneGroup)~= 1) then
			SobGroup_Move(player, DroneGroup, "vol"..DroneGroup)
		end
	Volume_Delete("vol"..DroneGroup)
end
