
function Start_DroneFrigate(CustomGroup, player, ShipID)
	SobGroup_SetSpeed(CustomGroup, 0.9)
  FX_StartEvent(CustomGroup, "droneretract_sfx"..random(1,6))
end

function Do_DroneFrigate(CustomGroup, player, ShipID)
  SobGroup_CreateIfNotExist("tempDRONE0"); SobGroup_CreateIfNotExist("tempDRONE1")
  SobGroup_CreateIfNotExist("tempDRONE2"); SobGroup_Clear("tempDRONE2")

  SobGroup_GetSobGroupBeingCapturedGroup(CustomGroup, "tempDRONE2")

	for k = 0,13 do
    local DroneName = "kus_drone"..ShipID..k

		SobGroup_CreateIfNotExist(DroneName)
		SobGroup_Clear("tempDRONE0"); SobGroup_Clear("tempDRONE1")

		SobGroup_GetSobGroupDockedWithGroup(CustomGroup, "tempDRONE0")
		SobGroup_FillShipsByType("tempDRONE1", "tempDRONE0", "kus_drone"..k)
		SobGroup_SobGroupAdd(DroneName, "tempDRONE1")

		if (SobGroup_Count(DroneName)== 0 and SobGroup_AreAllInRealSpace(CustomGroup)== 1 and SobGroup_Count("tempDRONE2")== 0 and
        SobGroup_IsDoingAbility(CustomGroup, AB_HyperspaceViaGate)== 0 and SobGroup_IsDoingAbility(CustomGroup, AB_Hyperspace)== 0 and
				SobGroup_IsDoingAbility(CustomGroup, AB_Dock)== 0 and SobGroup_IsDoingAbility(CustomGroup, AB_Retire)== 0) then

			SobGroup_SobGroupAdd(DroneName, SobGroup_CreateShip(CustomGroup, "kus_drone"..k))

			if (k == 0 or k == 4 or k == 8 or k == 12) then FX_StartEvent(CustomGroup, "dronelaunch1") end
			if (k == 1 or k == 5 or k == 9 or k == 13) then FX_StartEvent(CustomGroup, "dronelaunch2") end
			if (k == 2 or k == 6 or k == 10) then FX_StartEvent(CustomGroup, "dronelaunch3") end
			if (k == 3 or k == 7 or k == 11) then FX_StartEvent(CustomGroup, "dronelaunch4") end

			break
		else
			if (SobGroup_IsDockedSobGroup(DroneName, CustomGroup)== 1 and SobGroup_AreAllInRealSpace(CustomGroup)== 1 and SobGroup_Count("tempDRONE2")== 0 and
          SobGroup_IsDoingAbility(CustomGroup, AB_HyperspaceViaGate)== 0 and SobGroup_IsDoingAbility(CustomGroup, AB_Hyperspace)== 0 and
          SobGroup_IsDoingAbility(CustomGroup, AB_Dock)== 0 and SobGroup_IsDoingAbility(CustomGroup, AB_Retire)== 0) then

				SobGroup_Launch(DroneName, CustomGroup)

  			if (k == 0 or k == 4 or k == 8 or k == 12) then FX_StartEvent(CustomGroup, "dronelaunch1") end
  			if (k == 1 or k == 5 or k == 9 or k == 13) then FX_StartEvent(CustomGroup, "dronelaunch2") end
  			if (k == 2 or k == 6 or k == 10) then FX_StartEvent(CustomGroup, "dronelaunch3") end
  			if (k == 3 or k == 7 or k == 11) then FX_StartEvent(CustomGroup, "dronelaunch4") end

  			break
			end
		end
	end
end

function Finish_DroneFrigate(CustomGroup, player, ShipID)
	SobGroup_SetSpeed(CustomGroup, 1)
  FX_StartEvent(CustomGroup, "droneretract_sfx"..random(1,6))

	for k = 0,13 do
    local DroneName = "kus_drone"..ShipID..k

		if (SobGroup_Empty(DroneName)== 0) then
      SobGroup_DockSobGroupAndStayDocked(DroneName, CustomGroup)
			SobGroup_AbilityActivate(DroneName, AB_Targeting, 0)
			SobGroup_AbilityActivate(DroneName, AB_Attack, 0)
		end
	end
end
