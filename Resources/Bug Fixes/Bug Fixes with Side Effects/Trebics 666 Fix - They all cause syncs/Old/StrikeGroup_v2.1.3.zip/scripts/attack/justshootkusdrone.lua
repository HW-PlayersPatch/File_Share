

AttackStyleName = MoveToTargetAndShoot
--DogFight*  --AttackRun  --FlyRound*  --JustShoot  --FaceTarget*  --CircleStrafe*  --FollowLeader  --Kamikaze*  --MoveToTargetAndShoot

Data =
{
	-- when approaching the target use this method to split the formation and transition in to the attack style
	howToBreakFormation = BreakImmediately,

    -- face the target horizontaly only, don't tilt up or down
    faceTargetHorizontal = 1,
    faceTargetVertical = 1,

-- --- --
  tryToFaceTarget = 0,
-- --- --

	-- done at the end of every sim frame
	RandomActions =
	{
		{
			Type = InterpolateTarget,
			Weighting = 10,
			minParam = 0.5,
			maxParam = 0.5,
			heatCost = 5,
 			heatThresh = 0,
		},
		{
			Type = PickNewTarget,
			Weighting = 10,
		},
		{
			Type = NoAction,
			Weighting = 200,
		},
	},
	BeingAttackedActions =
	{
	},
	FiringActions =
	{
	},
}
