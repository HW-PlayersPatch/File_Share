dofilepath("Data:Scripts\\SCaR\\SobGroup.lua")
dofilepath("Data:Scripts\\SCaR\\StrikeGroup.lua")

function SPRestrict()
  for player = 0, Universe_PlayerCount()- 1 do
    SPRestrictOptions(player)
  end

  Rule_AddInterval("TargetFix_RULE", 0.25)
end

function MPRestrict()
  for player = 0, Universe_PlayerCount()- 1 do
    RestrictOptions(player)

    if (Player_GetLevelOfDifficulty(player)== 0) then
      SPRestrictOptions(player)
    end
  end

  Rule_AddInterval("TargetFix_RULE", 0.25)
end


function SPRestrictOptions(player)
	Player_RestrictResearchOption(player, PlayerRace_GetString(player, "generic_sp_research_restrict", ""))
	Player_RestrictBuildOption(player, PlayerRace_GetString(player, "generic_sp_build_restrict", ""))
end

function RestrictOptions(player)
	Player_RestrictResearchOption(player, PlayerRace_GetString(player, "generic_mp_research_restrict", ""))
	Player_RestrictBuildOption(player, PlayerRace_GetString(player, "generic_mp_build_restrict", ""))
end
