PersistantData = {
  StrikeGroups = {
    {
      name = "tortoise",
      Squadrons = {
      },
    },
  },
  Research = {
    [1] = {
      name = "SensorsDowngrade1",
      progress = 1,
    },
    [2] = {
      name = "SensorsDowngrade2",
      progress = 1,
    },
    [3] = {
      name = "SensorsDowngrade3",
      progress = 1,
    },
    [4] = {
      name = "AssaultCorvetteEliteWeaponUpgrade",
      progress = 1,
    },
    [5] = {
      name = "AttackBomberEliteWeaponUpgrade",
      progress = 1,
    },
    [6] = {
      name = "InterceptorMAXSPEEDUpgrade1",
      progress = 1,
    },
    [7] = {
      name = "SensorsBackToNormal1",
      progress = 1,
    },
    [8] = {
      name = "SensorsBackToNormal2",
      progress = 1,
    },
    [9] = {
      name = "SensorsBackToNormal3",
      progress = 1,
    },
    [10] = {
      name = "AttackBomberMAXSPEEDUpgrade1",
      progress = 1,
    },
  },
  TeamColours = {
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Soban.tga",
      baseColour = {
        0,
        0,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Soban.tga",
      baseColour = {
        0,
        0,
        0,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        0.49400,
        0,
      },
      stripeColour = {
        1,
        0.49400,
        0,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.75200,
        0.69400,
        0.55600,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
  },
  Squadrons = {
    {
      tactic = 2,
      type = "Hgn_MotherShip",
      subsystems = {
        {
          index = 0,
          name = "HGN_MS_PRODUCTION_FIGHTER",
        },
        {
          index = 0,
          name = "HGN_MS_PRODUCTION_CORVETTE",
        },
        {
          index = 0,
          name = "HGN_MS_MODULE_RESEARCH",
        },
        {
          index = 0,
          name = "HGN_MS_INNATE_ENGINE",
        },
        {
          index = 0,
          name = "HGN_MS_INNATE_RESOURCE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 0,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomberElite",
          hotkey = 0,
          teamColourHandle = 12,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomberElite",
          hotkey = 0,
          teamColourHandle = 13,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvetteElite",
          hotkey = 0,
          teamColourHandle = 14,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvetteElite",
          hotkey = 67108864,
          teamColourHandle = 15,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 4,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 0,
          teamColourHandle = 0,
          size = 1,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 4,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 4,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 4,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 4,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 4,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108896,
          teamColourHandle = 11,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
      },
      name = "Hgn_MotherShip",
      teamColourHandle = 0,
      hotkey = 0,
    },
  },
  PendingResearch = {
    {
      name = "MothershipHealthUpgrade1",
    },
    {
      name = "MothershipMAXSPEEDUpgrade1",
    },
    {
      name = "ResourceCollectorHealthUpgrade1",
    },
    {
      name = "AssaultCorvetteHealthUpgrade1",
    },
    {
      name = "AssaultCorvetteMAXSPEEDUpgrade1",
    },
    {
      name = "PulsarCorvetteHealthUpgrade1",
    },
    {
      name = "PulsarCorvetteMAXSPEEDUpgrade1",
    },
  },
  RUs = 4440,
}
