PersistantData = {
  StrikeGroups = {
    {
      name = "Fighter Screen",
      Squadrons = {
      },
    },
  },
  Research = {
    [1] = {
      name = "SensorsDowngrade1",
      progress = 1,
    },
    [2] = {
      name = "SensorsDowngrade2",
      progress = 1,
    },
    [3] = {
      name = "SensorsDowngrade3",
      progress = 1,
    },
    [4] = {
      name = "AssaultCorvetteEliteWeaponUpgrade",
      progress = 1,
    },
    [5] = {
      name = "AttackBomberEliteWeaponUpgrade",
      progress = 1,
    },
    [6] = {
      name = "InterceptorMAXSPEEDUpgrade1",
      progress = 1,
    },
    [7] = {
      name = "SensorsBackToNormal1",
      progress = 1,
    },
    [8] = {
      name = "SensorsBackToNormal2",
      progress = 1,
    },
    [9] = {
      name = "SensorsBackToNormal3",
      progress = 1,
    },
    [10] = {
      name = "AttackBomberMAXSPEEDUpgrade1",
      progress = 1,
    },
    [11] = {
      name = "AssaultCorvetteHealthUpgrade1",
      progress = 1,
    },
    [12] = {
      name = "AssaultCorvetteMAXSPEEDUpgrade1",
      progress = 1,
    },
    [13] = {
      name = "PulsarCorvetteHealthUpgrade1",
      progress = 1,
    },
    [14] = {
      name = "PulsarCorvetteMAXSPEEDUpgrade1",
      progress = 1,
    },
    [15] = {
      name = "RepairAbility",
      progress = 1,
    },
    [16] = {
      name = "MothershipMAXSPEEDUpgrade1",
      progress = 1,
    },
    [17] = {
      name = "ResourceCollectorHealthUpgrade1",
      progress = 1,
    },
    [18] = {
      name = "InstaAdvancedFrigateTech",
      progress = 1,
    },
  },
  TeamColours = {
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Soban.tga",
      baseColour = {
        0,
        0,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Soban.tga",
      baseColour = {
        0,
        0,
        0,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        0.49400,
        0,
      },
      stripeColour = {
        1,
        0.49400,
        0,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.75200,
        0.69400,
        0.55600,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
  },
  Squadrons = {
    {
      tactic = 2,
      type = "Hgn_MotherShip",
      subsystems = {
        {
          index = 0,
          name = "HGN_MS_PRODUCTION_FIGHTER",
        },
        {
          index = 0,
          name = "HGN_MS_PRODUCTION_CORVETTE",
        },
        {
          index = 0,
          name = "HGN_MS_MODULE_RESEARCH",
        },
        {
          index = 0,
          name = "HGN_MS_INNATE_ENGINE",
        },
        {
          index = 0,
          name = "HGN_MS_INNATE_RESOURCE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 0,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 201326656,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 1,
          tactic = 2,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBERELITE",
          hotkey = 67108881,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 134217736,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 17,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108881,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvetteElite",
          hotkey = 134217760,
          teamColourHandle = 14,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 16,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ASSAULTCORVETTE",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvetteElite",
          hotkey = 67108896,
          teamColourHandle = 15,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108881,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 16,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ASSAULTCORVETTE",
          hotkey = 201326624,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBERELITE",
          hotkey = 17,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 17,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 16,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 134217745,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 17,
          teamColourHandle = 0,
          size = 5,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvette",
          hotkey = 201326624,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 134217745,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvette",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 1,
        },
      },
      name = "Hgn_MotherShip",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 1,
      type = "Hgn_ResourceController",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 1,
      type = "Hgn_Carrier",
      subsystems = {
        {
          index = 0,
          name = "HGN_C_PRODUCTION_FRIGATE",
        },
        {
          index = 0,
          name = "HGN_C_MODULE_RESEARCHADVANCED",
        },
        {
          index = 0,
          name = "HGN_C_ENGINE",
        },
        {
          index = 0,
          name = "HGN_C_INNATE_RESOURCE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 67108864,
    },
    {
      tactic = 1,
      type = "Hgn_AssaultFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 201326720,
    },
    {
      tactic = 1,
      type = "Hgn_AssaultFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 67108992,
    },
  },
  PendingResearch = {
    {
      name = "SensDisProbe",
    },
    {
      name = "MothershipHealthUpgrade1",
    },
    {
      name = "ResourceControllerHealthUpgrade1",
    },
    {
      name = "ResourceCollectorHealthUpgrade2",
    },
    {
      name = "AttackBomberImprovedBombs",
    },
    {
      name = "InterceptorMAXSPEEDUpgrade2",
    },
    {
      name = "AttackBomberMAXSPEEDUpgrade2",
    },
    {
      name = "AssaultFrigateHealthUpgrade1",
    },
    {
      name = "AssaultFrigateMAXSPEEDUpgrade1",
    },
  },
  RUs = 15420,
}
