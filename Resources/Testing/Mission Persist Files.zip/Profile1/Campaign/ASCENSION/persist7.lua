PersistantData = {
  StrikeGroups = {
  },
  Research = {
    [1] = {
      name = "InstaAdvancedFrigateTech",
      progress = 1,
    },
    [2] = {
      name = "SensorsDowngrade1",
      progress = 1,
    },
    [3] = {
      name = "SensorsDowngrade2",
      progress = 1,
    },
    [4] = {
      name = "SensorsDowngrade3",
      progress = 1,
    },
    [5] = {
      name = "AssaultCorvetteEliteWeaponUpgrade",
      progress = 1,
    },
    [6] = {
      name = "AttackBomberEliteWeaponUpgrade",
      progress = 1,
    },
    [7] = {
      name = "InterceptorMAXSPEEDUpgrade1",
      progress = 1,
    },
    [8] = {
      name = "SensorsBackToNormal1",
      progress = 1,
    },
    [9] = {
      name = "SensorsBackToNormal2",
      progress = 1,
    },
    [10] = {
      name = "SensorsBackToNormal3",
      progress = 1,
    },
    [11] = {
      name = "AttackBomberMAXSPEEDUpgrade1",
      progress = 1,
    },
    [12] = {
      name = "AssaultCorvetteHealthUpgrade1",
      progress = 1,
    },
    [13] = {
      name = "AssaultCorvetteMAXSPEEDUpgrade1",
      progress = 1,
    },
    [14] = {
      name = "PulsarCorvetteHealthUpgrade1",
      progress = 1,
    },
    [15] = {
      name = "PulsarCorvetteMAXSPEEDUpgrade1",
      progress = 1,
    },
    [16] = {
      name = "RepairAbility",
      progress = 1,
    },
    [17] = {
      name = "MothershipMAXSPEEDUpgrade1",
      progress = 1,
    },
    [18] = {
      name = "ResourceCollectorHealthUpgrade1",
      progress = 1,
    },
    [19] = {
      name = "AttackBomberImprovedBombs",
      progress = 1,
    },
    [20] = {
      name = "AttackBomberMAXSPEEDUpgrade2",
      progress = 1,
    },
    [21] = {
      name = "InterceptorMAXSPEEDUpgrade2",
      progress = 1,
    },
    [22] = {
      name = "MothershipHealthUpgrade1",
      progress = 1,
    },
    [23] = {
      name = "GraviticAttractionMines",
      progress = 1,
    },
    [24] = {
      name = "AssaultFrigateHealthUpgrade1",
      progress = 1,
    },
    [25] = {
      name = "AssaultFrigateMAXSPEEDUpgrade1",
      progress = 1,
    },
    [26] = {
      name = "TorpedoFrigateHealthUpgrade1",
      progress = 1,
    },
    [27] = {
      name = "TorpedoFrigateMAXSPEEDUpgrade1",
      progress = 1,
    },
    [28] = {
      name = "ResourceCollectorHealthUpgrade2",
      progress = 1,
    },
    [29] = {
      name = "ResourceControllerHealthUpgrade1",
      progress = 1,
    },
    [30] = {
      name = "SensDisProbe",
      progress = 1,
    },
    [31] = {
      name = "CarrierHealthUpgrade1",
      progress = 1,
    },
    [32] = {
      name = "CarrierMAXSPEEDUpgrade1",
      progress = 1,
    },
    [33] = {
      name = "ScoutPingAbility",
      progress = 1,
    },
    [34] = {
      name = "ImprovedTorpedo",
      progress = 1,
    },
    [35] = {
      name = "AssaultCorvetteHealthUpgrade2",
      progress = 1,
    },
    [36] = {
      name = "AssaultCorvetteMAXSPEEDUpgrade2",
      progress = 1,
    },
    [37] = {
      name = "PulsarCorvetteHealthUpgrade2",
      progress = 1,
    },
    [38] = {
      name = "PulsarCorvetteMAXSPEEDUpgrade2",
      progress = 1,
    },
    [39] = {
      name = "IonCannonFrigateHealthUpgrade1",
      progress = 1,
    },
    [40] = {
      name = "IonCannonFrigateMAXSPEEDUpgrade1",
      progress = 1,
    },
    [41] = {
      name = "ECMProbe",
      progress = 1,
    },
    [42] = {
      name = "ScoutEMPAbility",
      progress = 1,
    },
    [43] = {
      name = "DefenseFieldFrigateShield",
      progress = 1,
    },
    [44] = {
      name = "MothershipHealthUpgrade2",
      progress = 1,
    },
    [45] = {
      name = "MothershipMAXSPEEDUpgrade2",
      progress = 1,
    },
    [46] = {
      name = "MothershipBUILDSPEEDUpgrade1",
      progress = 1,
    },
    [47] = {
      name = "CarrierHealthUpgrade2",
      progress = 1,
    },
    [48] = {
      name = "CarrierMAXSPEEDUpgrade2",
      progress = 1,
    },
    [49] = {
      name = "CarrierBUILDSPEEDUpgrade1",
      progress = 1,
    },
    [50] = {
      name = "ResourceControllerHealthUpgrade2",
      progress = 1,
    },
    [51] = {
      name = "DamageMoverTech",
      progress = 1,
    },
  },
  TeamColours = {
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0,
        0.92500,
        0.52100,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0,
        0.92500,
        0.52100,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0,
        0.92500,
        0.52100,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0,
        0.92500,
        0.52100,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Tri.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Soban.tga",
      baseColour = {
        0,
        0,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Soban.tga",
      baseColour = {
        0,
        0,
        0,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        0.49400,
        0,
      },
      stripeColour = {
        1,
        0.49400,
        0,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.75200,
        0.69400,
        0.55600,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        0,
        0,
        0,
      },
    },
  },
  Squadrons = {
    {
      tactic = 2,
      type = "Vgr_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "VGR_DES_ENGINE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "Vgr_Destroyer",
      teamColourHandle = 0,
      hotkey = 256,
    },
    {
      tactic = 2,
      type = "Hgn_MotherShip",
      subsystems = {
        {
          index = 0,
          name = "HGN_MS_PRODUCTION_FIGHTER",
        },
        {
          index = 0,
          name = "HGN_MS_PRODUCTION_CORVETTE",
        },
        {
          index = 0,
          name = "HGN_MS_PRODUCTION_FRIGATE",
        },
        {
          index = 0,
          name = "HGN_MS_PRODUCTION_CAPSHIP",
        },
        {
          index = 0,
          name = "HGN_MS_MODULE_RESEARCH",
        },
        {
          index = 0,
          name = "HGN_MS_MODULE_RESEARCHADVANCED",
        },
        {
          index = 0,
          name = "HGN_MS_SENSORS_ADVANCEDARRAY",
        },
        {
          index = 0,
          name = "HGN_MS_INNATE_ENGINE",
        },
        {
          index = 0,
          name = "HGN_MS_INNATE_RESOURCE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 4,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_PULSARCORVETTE",
          hotkey = 64,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ASSAULTCORVETTE",
          hotkey = 134217760,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_PULSARCORVETTE",
          hotkey = 134217792,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_PULSARCORVETTE",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 201326608,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 16,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 134217792,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 4096,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvette",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 4096,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ASSAULTCORVETTE",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 2,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 4,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 201326608,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvette",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 4,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 2,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 134217736,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "HGN_ASSAULTCORVETTE",
          hotkey = 201326624,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvette",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_PULSARCORVETTE",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 2,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 1,
          tactic = 1,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 64,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ASSAULTCORVETTE",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_PulsarCorvette",
          hotkey = 134217792,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvette",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ASSAULTCORVETTE",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_AssaultCorvette",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ASSAULTCORVETTE",
          hotkey = 201326624,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_PULSARCORVETTE",
          hotkey = 67108928,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ASSAULTCORVETTE",
          hotkey = 67108896,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_PULSARCORVETTE",
          hotkey = 201326656,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_ATTACKBOMBER",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 201326600,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_INTERCEPTOR",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 0,
        },
        {
          index = 0,
          type = "HGN_PULSARCORVETTE",
          hotkey = 64,
          teamColourHandle = 0,
          size = 3,
          tactic = 0,
        },
      },
      name = "Hgn_MotherShip",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 1,
      type = "Hgn_ResourceController",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 1,
      type = "Hgn_Carrier",
      subsystems = {
        {
          index = 0,
          name = "HGN_C_PRODUCTION_FIGHTER",
        },
        {
          index = 0,
          name = "HGN_C_PRODUCTION_CORVETTE",
        },
        {
          index = 0,
          name = "HGN_C_PRODUCTION_FRIGATE",
        },
        {
          index = 0,
          name = "HGN_C_MODULE_RESEARCHADVANCED",
        },
        {
          index = 0,
          name = "HGN_C_SENSORS_ADVANCEDARRAY",
        },
        {
          index = 0,
          name = "HGN_C_ENGINE",
        },
        {
          index = 0,
          name = "HGN_C_INNATE_RESOURCE",
        },
      },
      buildjobs = {
        [0] = {
          [0] = {
            name = "Hgn_Interceptor",
            rusSpent = 371.37891,
          },
          [1] = {
            name = "Hgn_Interceptor",
            rusSpent = 0,
          },
        },
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 0,
      type = "Hgn_TorpedoFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 1,
      type = "Hgn_MarineFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 2048,
    },
    {
      tactic = 1,
      type = "Hgn_MarineFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 2048,
    },
    {
      tactic = 0,
      type = "Hgn_TorpedoFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 0,
      type = "Hgn_TorpedoFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 134217856,
    },
    {
      tactic = 1,
      type = "Hgn_MarineFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 2048,
    },
    {
      tactic = 1,
      type = "Hgn_MarineFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 2048,
    },
    {
      tactic = 0,
      type = "Hgn_TorpedoFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 134217856,
    },
    {
      tactic = 0,
      type = "Hgn_IonCannonFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 0,
      type = "Hgn_IonCannonFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 0,
      type = "Hgn_IonCannonFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 0,
      type = "Hgn_IonCannonFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 0,
      type = "Hgn_IonCannonFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 0,
      type = "Hgn_TorpedoFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 134217856,
    },
    {
      tactic = 0,
      type = "Hgn_IonCannonFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 0,
      type = "Hgn_TorpedoFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 134217856,
    },
    {
      tactic = 0,
      type = "Hgn_IonCannonFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 0,
      type = "Hgn_TorpedoFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 134217856,
    },
    {
      tactic = 0,
      type = "Hgn_IonCannonFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
    {
      tactic = 0,
      type = "Hgn_TorpedoFrigate",
      subsystems = {
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
      },
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
  },
  PendingResearch = {
  },
  RUs = 77633,
}
