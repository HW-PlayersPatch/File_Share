PersistantData = {
  StrikeGroups = {
    {
      name = "Fighter Screen",
      Squadrons = {
      },
    },
  },
  Research = {
    [1] = {
      name = "SensorsDowngrade1",
      progress = 1,
    },
    [2] = {
      name = "SensorsDowngrade2",
      progress = 1,
    },
    [3] = {
      name = "SensorsDowngrade3",
      progress = 1,
    },
  },
  TeamColours = {
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      stripeColour = {
        0.80000,
        0.80000,
        0.80000,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        1,
        0.49400,
        0,
      },
      stripeColour = {
        1,
        0.49400,
        0,
      },
    },
    {
      trailColour = {
        0.36500,
        0.55300,
        0.66700,
      },
      badgeTexName = "DATA:Badges/Hiigaran.tga",
      baseColour = {
        0.75200,
        0.69400,
        0.55600,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.92100,
        0.75000,
        0.41900,
      },
      badgeTexName = "DATA:Badges/Vaygr.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
  },
  Squadrons = {
    {
      tactic = 2,
      type = "Hgn_MotherShip",
      subsystems = {
        {
          index = 0,
          name = "HGN_MS_PRODUCTION_FIGHTER",
        },
        {
          index = 0,
          name = "HGN_MS_MODULE_RESEARCH",
        },
        {
          index = 0,
          name = "HGN_MS_INNATE_ENGINE",
        },
        {
          index = 0,
          name = "HGN_MS_INNATE_RESOURCE",
        },
      },
      buildjobs = {
      },
      size = 1,
      shiphold = {
        {
          index = 0,
          type = "Hgn_ResourceCollector",
          hotkey = 67108864,
          teamColourHandle = 0,
          size = 1,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_AttackBomber",
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 67108872,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 8,
          teamColourHandle = 0,
          size = 5,
          tactic = 2,
        },
        {
          index = 0,
          type = "Hgn_Interceptor",
          hotkey = 8,
          teamColourHandle = 0,
          size = 4,
          tactic = 2,
        },
      },
      name = "Hgn_MotherShip",
      teamColourHandle = 0,
      hotkey = 134217728,
    },
  },
  PendingResearch = {
  },
  RUs = 650,
}
