PersistantData = {
  Research = {
    [1] = {
      name = "FighterDrive",
      progress = 1,
    },
    [2] = {
      name = "FighterChassis",
      progress = 1,
    },
    [3] = {
      name = "CorvetteDrive",
      progress = 1,
    },
    [4] = {
      name = "CorvetteChassis",
      progress = 1,
    },
    [5] = {
      name = "HeavyCorvetteUpgrade",
      progress = 1,
    },
    [6] = {
      name = "CapitalShipDrive",
      progress = 1,
    },
    [7] = {
      name = "CapitalShipChassis",
      progress = 1,
    },
    [8] = {
      name = "IonCannons",
      progress = 1,
    },
    [9] = {
      name = "PlasmaBombLauncher",
      progress = 1,
    },
    [10] = {
      name = "DefenderSubSystems",
      progress = 1,
    },
    [11] = {
      name = "SuperCapitalShipDrive",
      progress = 1,
    },
    [12] = {
      name = "DroneTechnology",
      progress = 1,
    },
  },
  TeamColours = {
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Kushan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Kushan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Turanic.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.17647,
        1,
        0.58431,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
  },
  Squadrons = {
    {
      tactic = 2,
      type = "Kus_Mothership",
      subsystems = {
        {
          index = 0,
          name = "KUS_MOTHERSHIPENGINE",
        },
        {
          index = 0,
          name = "KUS_MOTHERSHIPRESOURCE",
        },
      },
      stance = 2,
      shiphold = {
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 1024,
          teamColourHandle = 0,
          size = 0,
          tactic = 1,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 1024,
          teamColourHandle = 0,
          size = 0,
          tactic = 1,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 2048,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 2048,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 2048,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 2048,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 2048,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 1024,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 67109888,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 67109888,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_RepairCorvette",
          stance = 2,
          hotkey = 67109888,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 67110912,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 67108880,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_LightCorvette",
          stance = 0,
          hotkey = 16,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_DroneFrigate",
          stance = 2,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 1,
        },
        {
          index = 0,
          type = "Kus_ResearchShip",
          stance = 2,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_ResourceCollector",
          stance = 2,
          hotkey = 67112960,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_ResourceCollector",
          stance = 2,
          hotkey = 4096,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
      },
      name = "NIS_Squad",
      teamColourHandle = 0,
      buildjobs = {
        [0] = {
          [0] = {
            name = "Kus_DroneFrigate",
            rusSpent = 190.90625,
          },
        },
      },
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },
    {
      tactic = 2,
      type = "Kus_ResourceController",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 64,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 64,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 64,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 64,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 64,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 64,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },
    {
      tactic = 2,
      type = "Kus_IonCannonFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 64,
    },
    {
      tactic = 2,
      type = "Kus_SupportFrigate",
      subsystems = {
        {
          index = 0,
          name = "KUS_SUPPORTGUN",
        },
      },
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 512,
    },    
	{
      tactic = 2,
      type = "Kus_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION1",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION2",
        },
        {
          index = 0,
          name = "KUS_DESTROYERENGINE",
        },
      },
      stance = 0,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
	{
      tactic = 2,
      type = "Kus_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION1",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION2",
        },
        {
          index = 0,
          name = "KUS_DESTROYERENGINE",
        },
      },
      stance = 0,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },
	{
      tactic = 2,
      type = "Kus_Destroyer",
      subsystems = {
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERGUN",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION1",
        },
        {
          index = 0,
          name = "KUS_DESTROYERION2",
        },
        {
          index = 0,
          name = "KUS_DESTROYERENGINE",
        },
      },
      stance = 0,
      name = "",
      teamColourHandle = 0,
      hotkey = 128,
    },	
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 0,
      name = "",
      teamColourHandle = 0,
      hotkey = 32,
    },
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 32,
    },
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
    {
      tactic = 2,
      type = "Kus_DroneFrigate",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
	{
      tactic = 2,
      type = "Kus_SensorArray",
      stance = 2,
      name = "",
      teamColourHandle = 0,
      hotkey = 0,
    },
  },
  PendingResearch = {
  },
  RUs = 19936,
}
