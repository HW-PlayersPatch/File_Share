PersistantData = {
  Research = {
    [1] = {
      name = "FighterDrive",
      progress = 1,
    },
    [2] = {
      name = "FighterChassis",
      progress = 1,
    },
  },
  TeamColours = {
    {
      trailColour = {
        0.02353,
        0.91373,
        1,
      },
      badgeTexName = "DATA:badges/Kushan.tga",
      baseColour = {
        0.02353,
        0.91373,
        1,
      },
      stripeColour = {
        0,
        0,
        1,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Kushan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      badgeTexName = "DATA:Badges/Vaygr_Outline_Steel.tga",
      baseColour = {
        0.90000,
        0.90000,
        0.90000,
      },
      stripeColour = {
        0.10000,
        0.10000,
        0.10000,
      },
    },
    {
      trailColour = {
        1,
        0.82353,
        0,
      },
      badgeTexName = "DATA:Badges/Kushan.tga",
      baseColour = {
        1,
        0.82353,
        0,
      },
      stripeColour = {
        1,
        0,
        0,
      },
    },
    {
      trailColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      badgeTexName = "",
      baseColour = {
        0.50000,
        0.50000,
        0.50000,
      },
      stripeColour = {
        0.50000,
        0.50000,
        0.50000,
      },
    },
    {
      trailColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        1,
        1,
        1,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        1,
        1,
        1,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      badgeTexName = "DATA:Badges/Taiidan.tga",
      baseColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
    {
      trailColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      badgeTexName = "DATA:Badges/Hiigaran_Border.tga",
      baseColour = {
        0.55686,
        0.62353,
        0.63137,
      },
      stripeColour = {
        1,
        1,
        1,
      },
    },
  },
  Squadrons = {
    {
      tactic = 2,
      type = "Kus_Mothership",
      subsystems = {
        {
          index = 0,
          name = "KUS_MOTHERSHIPENGINE",
        },
        {
          index = 0,
          name = "KUS_MOTHERSHIPRESOURCE",
        },
      },
      stance = 2,
      shiphold = {
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_SalvageCorvette",
          stance = 2,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_Scout",
          stance = 0,
          hotkey = 8,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_ResourceCollector",
          stance = 2,
          hotkey = 4096,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_ResourceCollector",
          stance = 2,
          hotkey = 4096,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
        {
          index = 0,
          type = "Kus_ResearchShip",
          stance = 2,
          hotkey = 0,
          teamColourHandle = 0,
          size = 0,
          tactic = 2,
        },
      },
      name = "NIS_Squad",
      teamColourHandle = 0,
      hotkey = 0,
    },
  },
  PendingResearch = {
  },
  RUs = 1200,
}
