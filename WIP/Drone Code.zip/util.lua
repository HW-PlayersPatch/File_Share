-- Calculate the distance between two points
function GetDistanceBetweenPoints(pointA, pointB)
	return floor(sqrt((pointA[1] - pointB[1]) * (pointA[1] - pointB[1]) + (pointA[2] - pointB[2]) * (pointA[2] - pointB[2]) + (pointA[3] - pointB[3]) * (pointA[3] - pointB[3])))
end